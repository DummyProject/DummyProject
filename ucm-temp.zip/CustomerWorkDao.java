package indi;

import indi.ucm.jdbc.entry.CustomerWork;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_ONE_CUSTOMER_WORK_POSTFIX = " (customer_work_ID, customer_ID, work_status, assigned_staff_user, schedule_start_date, schedule_end_date, schedule_start_time, schedule_end_time, work_repeat_interval, work_time_duration, work_location_type, work_description, work_documents_ID, work_billable, wrok_billing_rate, billing_currency_ID, work_reminder_notify_staff, work_reminder_notify_staff_time, work_reminder_notify_staff_method, work_reminder_notify_customer, work_reminder_notify_customer_time, work_reminder_notify_customer_method, work_reminder_message, actual_complete_date, actual_complete_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /**
     * create customer work
     * 
     * @param StaffUser
     */
    public void createStaffUser(final CustomerWork customerWork, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_work_" + masterUserId + CustomerWorkDao.SQL_INSERT_ONE_CUSTOMER_WORK_POSTFIX,
            customerWork.getCustomerWorkId(), customerWork.getCustomerId(), customerWork.getWorkStatus(),
            customerWork.getAssignedStaffUser(), customerWork.getScheduleStartDate(), customerWork.getScheduleEndDate(),
            customerWork.getScheduleStartTime(), customerWork.getScheduleEndTime(), customerWork.getWorkRepeatInterval(),
            customerWork.getWorkTimeDuration(), customerWork.getWorkLocationType(), customerWork.getWorkDescription(),
            customerWork.getWorkDocumentsId(), customerWork.getWorkBillable(), customerWork.getWorkBillingRate(),
            customerWork.getBillingCurrencyId(), customerWork.getWorkReminderNotifyStaff(),
            customerWork.getWorkReminderNotifyStaffTime(), customerWork.getWorkReminderNotifyStaffMethod(),
            customerWork.getWorkReminderNotifyCustomer(), customerWork.getWorkReminderNotifyCustomerTime(),
            customerWork.getWorkReminderNotifyCustomerMethod(), customerWork.getWorkReminderMessage(),
            customerWork.getActualCompleteDate(), customerWork.getActualCompleteTime());
    }

    /**
     * create customer_work_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_work_ID` bigint NOT NULL,");
        sb.append("`customer_ID` bigint NOT NULL,");
        sb.append("`work_status` tinyint  NOT NULL,");
        sb.append("`assigned_staff_user` int  NOT NULL,");
        sb.append("`schedule_start_date` date  NOT NULL,");
        sb.append("`schedule_end_date` date  NOT NULL,");
        sb.append("`schedule_start_time` time  NOT NULL,");
        sb.append("`schedule_start_time` time  NOT NULL,");
        sb.append("`schedule_start_time` tinyint  NOT NULL,");
        sb.append("`work_time_duration` tinyint  NOT NULL,");
        sb.append("`work_location_type` tinyint  NOT NULL,");
        sb.append("`work_description` varchar(2000)  NOT NULL,");
        sb.append("`work_documents_ID` bigint  NOT NULL,");
        sb.append("`work_billable` tinyint  NOT NULL,");
        sb.append("`wrok_billing_rate` smallint  NOT NULL,");
        sb.append("`billing_currency_ID` smallint  NOT NULL,");
        sb.append("`work_reminder_notify_staff` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_staff_time` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_staff_method` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_customer` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_customer_time` int  NOT NULL,");
        sb.append("`work_reminder_notify_customer_method` int  NOT NULL,");
        sb.append("`work_reminder_message` varchar(1000)  NOT NULL,");
        sb.append("`actual_complete_date` date  NOT NULL,");
        sb.append("`actual_complete_time` time  NOT NULL,");
        sb.append("PRIMARY KEY (`customer_work_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
