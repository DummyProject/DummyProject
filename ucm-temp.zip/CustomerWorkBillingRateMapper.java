package indi;

import indi.ucm.jdbc.entry.CustomerWorkBillingRate;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerWorkBillingRateMapper implements RowMapper<CustomerWorkBillingRate> {

    public CustomerWorkBillingRate mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerWorkBillingRate cwbr = new CustomerWorkBillingRate();
        cwbr.setWorkBillingRateId(rs.getInt("work_billing_rate_ID"));
        cwbr.setWorkTimeDurationId(rs.getInt("work_time_duration_ID"));
        cwbr.setBillingRate(rs.getDouble("billing_rate"));
        cwbr.setBillingRateComment(rs.getString("billing_rate_comment"));
        return cwbr;
    }

}
