package indi;

import indi.ucm.jdbc.entry.WorkRepeatInterval;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class WorkRepeatIntervalMapper implements RowMapper<WorkRepeatInterval> {

    public WorkRepeatInterval mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        WorkRepeatInterval wri = new WorkRepeatInterval();
        wri.setWorkRepeatIntervalId(rs.getInt("work_repeat_interval_ID"));
        wri.setRepeatIntervalName(rs.getString("repeat_Interval_name"));
        wri.setRepeatIntervalMinutes(rs.getInt("repeat_Interval_minutes"));
        return wri;
    }

}
