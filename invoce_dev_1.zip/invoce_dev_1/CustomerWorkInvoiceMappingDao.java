package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerWorkInvoiceMapping;
import indi.ucm.jdbc.mapper.CustomerWorkInvoiceMappingMapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkInvoiceMappingDao extends JdbcDaoSupport {
    private final String SQL_INSERT_CUSTOMER_WORK_INVOICE_MAPPING_POSTFIX = " (customer_work_invoice_ID,customer_work_ID) VALUES (?,?)";
    private final String SQL_PROCESS_WORK_INVOICE_MAPPING_BY_INVOICE_ID_POSTFIX = " where customer_work_invoice_ID = ?";
    private final String SQL_PROCESS_WORK_INVOICE_MAPPING_BY_WORK_ID_POSTFIX = " where customer_work_ID = ?";
    private final String SQL_SELECT_CUSTOMER_WORK_INVOICE_MAPPING_PREFIX = "SELECT * FROM customer_work_invoice_mapping_";

    public void createCustomerAccountInvoiceMapping(final long invoiceId, final long workId, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_work_invoice_mapping_" + masterUserId + this.SQL_INSERT_CUSTOMER_WORK_INVOICE_MAPPING_POSTFIX,
            invoiceId, workId);
    }

    public void deleteCustomerAccountInvoiceMappingByWorkId(final long workId, final int masterUserId) {
        this.getJdbcTemplate().update(
            "DELETE from customer_work_invoice_mapping_" + masterUserId + this.SQL_PROCESS_WORK_INVOICE_MAPPING_BY_WORK_ID_POSTFIX,
            workId);
    }

    public void deleteCustomerAccountInvoiceMappingByInvoiceId(final long invoiceId, final int masterUserId) {
        this.getJdbcTemplate().update(
            "DELETE from customer_work_invoice_mapping_" + masterUserId
                + this.SQL_PROCESS_WORK_INVOICE_MAPPING_BY_INVOICE_ID_POSTFIX, invoiceId);
    }

    public List<Long> getCustomerWorkIdsByInvoiceId(final long invoiceId, final int masterUserId) {
        List<CustomerWorkInvoiceMapping> cwims = this.getJdbcTemplate().query(
            this.SQL_SELECT_CUSTOMER_WORK_INVOICE_MAPPING_PREFIX + masterUserId
                + this.SQL_PROCESS_WORK_INVOICE_MAPPING_BY_INVOICE_ID_POSTFIX, new Object[] {invoiceId},
            new CustomerWorkInvoiceMappingMapper());

        List<Long> workIds = new ArrayList();
        for (int i = 0; i < cwims.size(); i++) {
            CustomerWorkInvoiceMapping cwim = (CustomerWorkInvoiceMapping) cwims.get(i);
            Long workId = (long) cwim.getCustomerWorkId();
            workIds.add(workId);
        }

        return workIds;
    }

    /**
     * create customer_work_invoice_mapping_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_work_invoice_ID` bigint NOT NULL,");
        sb.append("`customer_work_ID` bigint NOT NULL,");
        sb.append("PRIMARY KEY (`customer_work_ID`))character set = utf8;");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
