package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerWorkInvoice;
import indi.ucm.jdbc.mapper.CustomerWorkInvoiceMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkInvoiceDao extends JdbcDaoSupport {
    private final String SQL_INSERT_CUSTOMER_WORK_INVOICE_POSTFIX = " (customer_work_invoice_ID, customer_ID,"
        + "customer_name,invoice_date,invoice_total_amount,billing_address_street"
        + "billing_address_room_number,billing_address_city,billing_address_state_province"
        + "billing_addresss_country,user_note,invoice_status,received_payment_ID)"
        + " VALUES (?, ?,?,?,?,'TBC','TBC','TBC','TBC',0,'TBC',0,0)";
    private final String SQL_SELECT_CUSTOMER_WORK_INVOICE_PREFIX = "SELECT * FROM customer_work_invoice_";
    private final String SQL_PROCESS_WORK_INVOICE_BY_ID_POSTFIX = " where customer_work_invoice_ID = ?";
    private final String SQL_SELECT_WORK_INVOICE_BY_CUSTOMER_ID_POSTFIX = " where customer_ID = ?";

    public void createCustomerAccountInvoice(final CustomerWorkInvoice customerWorkInvoice, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_work_invoice_" + masterUserId + this.SQL_INSERT_CUSTOMER_WORK_INVOICE_POSTFIX,
            customerWorkInvoice.getCustomerWorkInvoiceId(), customerWorkInvoice.getCustomerId(),
            customerWorkInvoice.getCustomerName(), customerWorkInvoice.getInvoiceDate(),
            customerWorkInvoice.getInvoiceTotalAmount());
    }


    public CustomerWorkInvoice getInvoiceByID(final int invoiceID, final int masterUserId) {
        CustomerWorkInvoice customerWorkInvoice = this.getJdbcTemplate().queryForObject(
            this.SQL_SELECT_CUSTOMER_WORK_INVOICE_PREFIX + masterUserId + this.SQL_PROCESS_WORK_INVOICE_BY_ID_POSTFIX,
            new Object[] {invoiceID}, new CustomerWorkInvoiceMapper());

        return customerWorkInvoice;
    }

    public List<CustomerWorkInvoice> getInvoiceByCustomerId(final int customerId, final int masterUserId) {
        List<CustomerWorkInvoice> customerWorkInvoices = this.getJdbcTemplate().query(
            this.SQL_SELECT_CUSTOMER_WORK_INVOICE_PREFIX + masterUserId + this.SQL_SELECT_WORK_INVOICE_BY_CUSTOMER_ID_POSTFIX,
            new Object[] {customerId}, new CustomerWorkInvoiceMapper());

        return customerWorkInvoices;
    }

    public void deleteCustomerAccountInvoice(final int invoiceID, final int masterUserId) {
        this.getJdbcTemplate().update(
            "DELETE from customer_work_invoice_" + masterUserId + this.SQL_PROCESS_WORK_INVOICE_BY_ID_POSTFIX, invoiceID);
    }

    /**
     * create CUSTOMER_WORK_STATUS_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_work_invoice_ID` bigint NOT NULL,");
        sb.append("`customer_ID` bigint NOT NULL,");
        sb.append("`customer_name` varchar(200) NOT NULL,");
        sb.append("`invoice_date` date NOT NULL,");
        sb.append("`invoice_total_amount` double NOT NULL,");
        sb.append("`billing_address_street` varchar(100),");
        sb.append("`billing_address_room_number` varchar(100),");
        sb.append("`billing_address_city` varchar(100),");
        sb.append("`billing_address_state_province` varchar(100),");
        sb.append("`billing_addresss_country` tinyint,");
        sb.append("`user_note` varchar(2000),");
        sb.append("`invoice_status` tinyint NOT NULL,");
        sb.append("`received_payment_ID` bigint,");
        sb.append("PRIMARY KEY (`customer_work_invoice_ID`))character set = utf8;");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


}
