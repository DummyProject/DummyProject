package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerAccountStatusDao;
import indi.ucm.jdbc.dao.CustomerAccountTypeDao;
import indi.ucm.jdbc.dao.CustomerBusinessDao;
import indi.ucm.jdbc.dao.CustomerEmailGroupDao;
import indi.ucm.jdbc.dao.CustomerNotificationPreferenceDao;
import indi.ucm.jdbc.dao.MasterUserBusinessDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.MasterUserBusiness;
import indi.ucm.jdbc.entry.MasterUserList;
import indi.ucm.security.common.EncryptionDecryption;
import indi.ucm.security.common.GenerateRandomIdHelper;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SignUpRestController {

    // Service which will do all data retrieval/manipulation work
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    MasterUserListDao masterUserListDao;
    @Autowired
    MasterUserBusinessDao masterUsreBusinessDao;
    @Autowired
    StaffUserDao staffUserDao;
    @Autowired
    CustomerAccountDao customerAccountDao;
    @Autowired
    CustomerAccountTypeDao customerAccountTypeDao;
    @Autowired
    CustomerAccountStatusDao customerAccountStatusDao;
    @Autowired
    CustomerNotificationPreferenceDao customerNotificationPreferenceDao;
    @Autowired
    CustomerEmailGroupDao customerEmailGroupDao;
    @Autowired
    CustomerBusinessDao customerBusinessDao;

    // -------------------Sign up a master user-----------------------
    @RequestMapping(value = "/SignUp", method = RequestMethod.POST)
    public ResponseEntity<String> signUpMasterUser(final HttpServletRequest request) {
        // store data from request
        try {
            storeParameters(request);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>("Duplicated user name", HttpStatus.SERVICE_UNAVAILABLE);
        }

        return new ResponseEntity<String>("Sign Up Successfully", HttpStatus.OK);
    }

    // -------------------Get all business types-----------------------
    @RequestMapping(value = "/getBusinessTypes", method = RequestMethod.GET)
    public ResponseEntity<List> getBusinessTypes() {
        // store data from request
        List bts = this.masterUserListDao.getBusinessTypes();

        return new ResponseEntity<List>(bts, HttpStatus.OK);
    }

    // -------------------Get all countries-----------------------
    @RequestMapping(value = "/getCountries", method = RequestMethod.GET)
    public ResponseEntity<List> getCountries() {
        // store data from request
        List cs = this.masterUserListDao.getCountries();

        return new ResponseEntity<List>(cs, HttpStatus.OK);
    }

    // -------------------Get all timezones-----------------------
    @RequestMapping(value = "/getTimezones", method = RequestMethod.GET)
    public ResponseEntity<List> getTimezones() {
        // store data from request
        List tzs = this.masterUserListDao.getTimeZones();

        return new ResponseEntity<List>(tzs, HttpStatus.OK);
    }

    /**
     * retrieve data from request
     * 
     * @param request
     * @throws Exception
     */
    private void storeParameters(final HttpServletRequest request) throws Exception {
        Boolean isUniqueUserName = this.masterUserListDao.isUniqueUserName(request.getParameter("userName"));
        if (isUniqueUserName) {
            // 1.store basic info for master user
            int masterUserId = updateMasterUserList(request);

            // 2.create a set of tables belong to master user
            createTableSet(masterUserId);
            
            // 3.store info of master user from request
            stroeMasterUserInfo(request, masterUserId);
            
            
            //
        } else {
            throw new Exception("Duplicated user name");
        }

    }

    //create a set of tables belong to master user
    private void createTableSet(int masterUserId) {
    	masterUsreBusinessDao.createTable("master_user_business_" + masterUserId);
    	staffUserDao.createTable("staff_user_" + masterUserId);
    	masterUserDao.createTable("master_user_" + masterUserId);
    	customerAccountDao.createTable("customer_account_" + masterUserId);
    	customerAccountTypeDao.createTable("customer_account_type_" + masterUserId);
        customerAccountStatusDao.createTable("customer_account_status_" + masterUserId);
        customerNotificationPreferenceDao.createTable("customer_notification_preference_" + masterUserId);
        customerEmailGroupDao.createTable("customer_email_group_" + masterUserId);
        customerBusinessDao.createTable("customer_business_" + masterUserId);
	}

	/**
     * store basic info for master user
     * 
     * @param request
     * @return
     * 
     */
    private int updateMasterUserList(final HttpServletRequest request) {
        // 1.generate master user ID
        int masterUserId = generateMasterUserId();

        MasterUserList masterUserList = new MasterUserList();
        masterUserList.setMasterUserId(masterUserId);
        masterUserList.setUserName(request.getParameter("userName"));
        this.masterUserListDao.createMasterUserList(masterUserList);

        return masterUserId;
    }

    /**
     * generate master user ID
     * 
     * @return
     */
    private int generateMasterUserId() {
        // generate a 8 digit number as Master User ID
        int masterUserId = 0;
        boolean isUnique = false;
        while (!isUnique) {
            masterUserId = GenerateRandomIdHelper.generateRandomNumber(8);
            isUnique = isMasterUserIdUniqueId(masterUserId);
        }
        return masterUserId;
    }

    /**
     * generate master user business ID
     * 
     * @param masterUserId
     * 
     * @return
     */
    private int generateMasterUserBusinessId(final int masterUserId) {
        // generate a 8 digit number as Master User ID
        int masterUserBusinessId = 0;
        boolean isUnique = false;
        while (!isUnique) {
            masterUserBusinessId = GenerateRandomIdHelper.generateRandomNumber(8);
            isUnique = isMasterUserBusinessIdUniqueId(masterUserBusinessId, masterUserId);
        }
        return masterUserBusinessId;
    }

    /**
     * verify whether the master user ID is unique
     * 
     * @param masterUserId
     * @return
     */
    private boolean isMasterUserIdUniqueId(final int masterUserId) {
        MasterUserList masterUserList = this.masterUserListDao.getMasterUserList(masterUserId);
        if (masterUserList == null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * verify whether the master user business ID is unique
     * 
     * @param masterUserId
     * 
     * @param masterUserId
     * @return
     */
    private boolean isMasterUserBusinessIdUniqueId(final int masterUserBusinessId, final int masterUserId) {
        MasterUserBusiness masterUserBusiness = this.masterUsreBusinessDao
            .getMasterUserBusiness(masterUserBusinessId, masterUserId);
        if (masterUserBusiness == null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * store info of master user business from request
     * 
     * @param request
     * @param tableName
     * @throws Exception
     */
    private void stroeMasterUserInfo(final HttpServletRequest request, final int masterUserId) throws Exception {
      
        MasterUserBusiness masterUserBusiness = new MasterUserBusiness();
        int masterUserBusinessId = generateMasterUserBusinessId(masterUserId);
        masterUserBusiness.setMasterUserBusinessId(masterUserBusinessId);
        masterUserBusiness.setBusinessName(request.getParameter("businessName"));
        masterUserBusiness.setBusinessTypeId(Integer.parseInt(request.getParameter("businessTypeId")));
        masterUserBusiness.setBusinessTimeZoneId(Integer.parseInt(request.getParameter("businessTimeZoneId")));
        masterUserBusiness.setBusinessEMail(request.getParameter("businessEMail"));
        masterUserBusiness.setBusinessPhoneNumber(request.getParameter("businessPhoneNumber"));
        masterUserBusiness.setBusineseFaxNumber(request.getParameter("busineseFaxNumber"));
        masterUserBusiness.setBusinessAddressStreet(request.getParameter("businessAddressStreet"));
        masterUserBusiness.setBusinessRoomNumber(request.getParameter("businessRoomNumber"));
        masterUserBusiness.setBusinessAddressCity(request.getParameter("businessAddressCity"));
        masterUserBusiness.setBusinessAddressStateProvince(request.getParameter("businessAddressStateProvince"));
        masterUserBusiness.setBusinessCountryId(Integer.parseInt(request.getParameter("businessCountryId")));
        masterUserBusiness.setBusinessDescription(request.getParameter("businessDescription"));
        this.masterUsreBusinessDao.createMasterUserBusiness(masterUserBusiness, masterUserId);

        MasterUser masterUser = new MasterUser();
        masterUser.setMasterUserId(masterUserId);
        masterUser.setUerName(request.getParameter("userName"));
        masterUser.setHashedPassword(EncryptionDecryption.encryptStr(request.getParameter("hashedPassword")));
        masterUser.setSecurityQuestion(request.getParameter("securityQuestion"));
        masterUser.setSecurityQuestionAnswer(EncryptionDecryption.encryptStr(request.getParameter("securityQuestionAnswer")));
        masterUser.setFirstName(request.getParameter("firstName"));
        masterUser.setLastName(request.getParameter("lastName"));
        masterUser.seteMailAddress(request.getParameter("eMailAddress"));
        masterUser.setPhoneNumber(request.getParameter("phoneNumber"));
        masterUser.setOtherPhone(request.getParameter("otherPhone"));
        masterUser.setEnable2FactorAuthenticationLogin(Integer.parseInt(request.getParameter("enable2FactorAuthenticationLogin")));
        masterUser.setSendPasscodeToDeviceId(Integer.parseInt(request.getParameter("sendPasscodeToDeviceId")));
        masterUser.setMasterUserBusinessId(masterUserBusinessId);

        this.masterUserDao.creatMasterUser(masterUser);

    }
}
