package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.mapper.CustomerAccountMapper;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerAccountDao extends JdbcDaoSupport {
	private final static String SQL_INSERT_ONE_CUSTOMER_ACCOUNT_POSTFIX = " (customer_ID, customer_business_ID, customer_account_type, customer_account_status, assigned_staff_user, first_name, last_name, contact_first_name, contact_last_name, email_address, mobile_phone,  mailing_address_street, mailing_address_room_number, mailing_address_city, mailing_address_state_province, mailing_addresss_country, billing_address_street, billing_address_room_number, billing_address_city, billing_address_state_province, billing_addresss_country, customer_note, email_group, notification_preference, enable_client_portal, client_portal_username, hashed_password, security_question, security_question_answer, enable_2_factor_authentication_login, send_passcode_to_device_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private final static String SQL_SELECT_ONE_CUSTOMER_ACCOUNT_POSTFIX = " where customer_ID = ?";
	private final static String SQL_SELECT_ONE_CUSTOMER_ACCOUNT_BY_BUSINESS_ID_POSTFIX = " where customer_business_ID = ?";
	private final static String SQL_SELECT_CUSTOMER_ACCOUNT_PREFIX = "SELECT * FROM customer_account_";
	private final static String SQL_UPDATE_CUSTOMER_ACCOUNT_POSTFIX = " set customer_account_status = ?, assigned_staff_user = ?, first_name = ?, last_name = ?, contact_first_name = ?, contact_last_name = ?, email_address = ?, mobile_phone = ?,  mailing_address_street = ?, mailing_address_city = ?, mailing_address_state_province = ?, mailing_addresss_country = ?, billing_address_street = ?, billing_address_city = ?, billing_address_state_province = ?, billing_addresss_country = ?, customer_note = ?, notification_preference = ?, enable_client_portal = ? where customer_ID = ?";
	
	public CustomerAccount getCustomerAccount(final long customerId,
			int masterUserId) {
		try {
			CustomerAccount ca = this
					.getJdbcTemplate()
					.queryForObject(
							"SELECT * FROM customer_account_"
									+ masterUserId
									+ CustomerAccountDao.SQL_SELECT_ONE_CUSTOMER_ACCOUNT_POSTFIX,
							new Object[] { customerId },
							new CustomerAccountMapper());
			return ca;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<CustomerAccount> getCustomerAccounts(final int masterUserId) {
		List<CustomerAccount> cas = this.getJdbcTemplate().query(
				SQL_SELECT_CUSTOMER_ACCOUNT_PREFIX
						+ masterUserId, new Object[] {},
				new CustomerAccountMapper());

		return cas;
	}
	/**
	 * create customer account
	 * 
	 * @param CustomerAccount
	 */
	public void createCustomerAccount(final CustomerAccount CustomerAccount,
			int masterUserId) {
		this.getJdbcTemplate()
				.update("INSERT INTO customer_account_"
						+ masterUserId
						+ CustomerAccountDao.SQL_INSERT_ONE_CUSTOMER_ACCOUNT_POSTFIX,
						CustomerAccount.getCustomerId(),
						CustomerAccount.getCustomerBusinessId(),
						CustomerAccount.getCustomerAccountType(),
						CustomerAccount.getCustomerAccountStatus(),
						CustomerAccount.getAssignedStaffUser(),
						CustomerAccount.getFirstName(),
						CustomerAccount.getLastName(),
						CustomerAccount.getcFirstName(),
						CustomerAccount.getcLastName(),
						CustomerAccount.getEmailAddress(),
						CustomerAccount.getMobilePhone(),
						CustomerAccount.getMailingAddressStreet(),
						CustomerAccount.getMailingAddressRoomNumber(),
						CustomerAccount.getMailingAddressCity(),
						CustomerAccount.getMailingAddressStateProvince(),
						CustomerAccount.getMailingAddressCountry(),
						CustomerAccount.getBillingAddressStreet(),
						CustomerAccount.getBillingAddressRoomNumber(),
						CustomerAccount.getBillingAddressCity(),
						CustomerAccount.getBillingAddressStateProvince(),
						CustomerAccount.getBillingAddressCountry(),
						CustomerAccount.getCustomerNote(),
						CustomerAccount.getEmailGroup(),
						CustomerAccount.getNotificationPreference(),
						CustomerAccount.getEnableClientPortal(),
						CustomerAccount.getClientPortalUserName(),
						CustomerAccount.getHashedPassword(),
						CustomerAccount.getSecurityQuestion(),
						CustomerAccount.getSecurityQuestionAnswer(),
						CustomerAccount.getEnable2FactorAuthenticationLogin(),
						CustomerAccount.getSendPasscodeToDeviceId());
	}
	
	public void modifyCustomerAccount(final CustomerAccount CustomerAccount,
			int masterUserId){
		this.getJdbcTemplate()
		.update("UPDATE customer_account_"
				+ masterUserId
				+ SQL_UPDATE_CUSTOMER_ACCOUNT_POSTFIX,
				CustomerAccount.getCustomerAccountStatus(),
				CustomerAccount.getAssignedStaffUser(),
				CustomerAccount.getFirstName(),
				CustomerAccount.getLastName(),
				CustomerAccount.getcFirstName(),
				CustomerAccount.getcLastName(),
				CustomerAccount.getEmailAddress(),
				CustomerAccount.getMobilePhone(),
				CustomerAccount.getMailingAddressStreet(),
				CustomerAccount.getMailingAddressCity(),
				CustomerAccount.getMailingAddressStateProvince(),
				CustomerAccount.getMailingAddressCountry(),
				CustomerAccount.getBillingAddressStreet(),
				CustomerAccount.getBillingAddressCity(),
				CustomerAccount.getBillingAddressStateProvince(),
				CustomerAccount.getBillingAddressCountry(),
				CustomerAccount.getCustomerNote(),
				CustomerAccount.getNotificationPreference(),
				CustomerAccount.getEnableClientPortal(),
				CustomerAccount.getCustomerId());
	}

	/**
	 * create CUSTOMER_ACCOUNT_[postfix] table
	 * 
	 * @param tableName
	 */
	public void createTable(final String tableName) {
		StringBuffer sb = new StringBuffer("");
		sb.append("CREATE TABLE `" + tableName + "` (");
		sb.append("`customer_ID` bigint NOT NULL,");
		sb.append("`customer_business_ID` bigint NOT NULL,");
		sb.append("`customer_account_type` tinyint  NOT NULL,");
		sb.append("`customer_account_status` tinyint  NOT NULL,");
		sb.append("`assigned_staff_user` int  NOT NULL,");
		sb.append("`first_name` varchar(100)  ,");
		sb.append("`last_name` varchar(100)  ,");
		sb.append("`contact_first_name` varchar(100)  NOT NULL,");
		sb.append("`contact_last_name` varchar(100)  NOT NULL,");
		sb.append("`email_address` varchar(254)  NOT NULL,");
		sb.append("`mobile_phone` varchar(50)  NOT NULL,");
		sb.append("`mailing_address_street` varchar(100)  NOT NULL,");
		sb.append("`mailing_address_room_number` varchar(100)  NOT NULL,");
		sb.append("`mailing_address_city` varchar(100)  NOT NULL,");
		sb.append("`mailing_address_state_province` varchar(100)  NOT NULL,");
		sb.append("`mailing_addresss_country` int  NOT NULL,");
		sb.append("`billing_address_street` varchar(100)  NOT NULL,");
		sb.append("`billing_address_room_number` varchar(100)  NOT NULL,");
		sb.append("`billing_address_city` varchar(100)  NOT NULL,");
		sb.append("`billing_address_state_province` varchar(100)  NOT NULL,");
		sb.append("`billing_addresss_country` int  NOT NULL,");
		sb.append("`customer_note` varchar(1000)  ,");
		sb.append("`email_group` smallint  NOT NULL,");
		sb.append("`notification_preference` tinyint  NOT NULL,");
		sb.append("`enable_client_portal` tinyint  NOT NULL,");
		sb.append("`client_portal_username` varchar(100)  NOT NULL,");
		sb.append("`hashed_password` varchar(100)  NOT NULL,");
		sb.append("`security_question` varchar(100)  NOT NULL,");
		sb.append("`security_question_answer` varchar(100)  NOT NULL,");
		sb.append("`enable_2_factor_authentication_login` tinyint  NOT NULL,");
		sb.append("`send_passcode_to_device_ID` tinyint  NOT NULL,");
		sb.append("PRIMARY KEY (`customer_ID`))");
		try {
			this.getJdbcTemplate().update(sb.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public CustomerAccount getCustomerAccountByBusinessId(
			long customerBusinessId, int masterUserId) {
		try {
			CustomerAccount su = this
					.getJdbcTemplate()
					.queryForObject(
							"SELECT * FROM customer_account_"
									+ masterUserId
									+ CustomerAccountDao.SQL_SELECT_ONE_CUSTOMER_ACCOUNT_BY_BUSINESS_ID_POSTFIX,
							new Object[] { customerBusinessId },
							new CustomerAccountMapper());
			return su;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

}
