package indi.ucm.jdbc.entry;

public class CustomerInfo {
	private long customerId;
    private long customerBusinessId;
    private int customerAccountType;
    private int customerAccountStatus;
    private int assignedStaffUser;
    private String firstName;
    private String lastName;
    private String businessName;
    private String cFirstName;
    private String cLastName;
    private String emailAddress;
    private String mobilePhone;
    private String mailingAddressStreet;
    private String mailingAddressCity;
    private String mailingAddressStateProvince;
    private int mailingAddressCountry;
    private String billingAddressStreet;
    private String billingAddressCity;
    private String billingAddressStateProvince;
    private int billingAddressCountry;
    private String customerNote;
    private int notificationPreference;
    private int enableClientPortal;
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public long getCustomerBusinessId() {
		return customerBusinessId;
	}
	public void setCustomerBusinessId(long customerBusinessId) {
		this.customerBusinessId = customerBusinessId;
	}
	public int getCustomerAccountType() {
		return customerAccountType;
	}
	public void setCustomerAccountType(int customerAccountType) {
		this.customerAccountType = customerAccountType;
	}
	public int getCustomerAccountStatus() {
		return customerAccountStatus;
	}
	public void setCustomerAccountStatus(int customerAccountStatus) {
		this.customerAccountStatus = customerAccountStatus;
	}
	public int getAssignedStaffUser() {
		return assignedStaffUser;
	}
	public void setAssignedStaffUser(int assignedStaffUser) {
		this.assignedStaffUser = assignedStaffUser;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getcFirstName() {
		return cFirstName;
	}
	public void setcFirstName(String cFirstName) {
		this.cFirstName = cFirstName;
	}
	public String getcLastName() {
		return cLastName;
	}
	public void setcLastName(String cLastName) {
		this.cLastName = cLastName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public String getMailingAddressStreet() {
		return mailingAddressStreet;
	}
	public void setMailingAddressStreet(String mailingAddressStreet) {
		this.mailingAddressStreet = mailingAddressStreet;
	}
	public String getMailingAddressCity() {
		return mailingAddressCity;
	}
	public void setMailingAddressCity(String mailingAddressCity) {
		this.mailingAddressCity = mailingAddressCity;
	}
	public String getMailingAddressStateProvince() {
		return mailingAddressStateProvince;
	}
	public void setMailingAddressStateProvince(String mailingAddressStateProvince) {
		this.mailingAddressStateProvince = mailingAddressStateProvince;
	}
	public int getMailingAddressCountry() {
		return mailingAddressCountry;
	}
	public void setMailingAddressCountry(int mailingAddressCountry) {
		this.mailingAddressCountry = mailingAddressCountry;
	}
	public String getBillingAddressStreet() {
		return billingAddressStreet;
	}
	public void setBillingAddressStreet(String billingAddressStreet) {
		this.billingAddressStreet = billingAddressStreet;
	}
	public String getBillingAddressCity() {
		return billingAddressCity;
	}
	public void setBillingAddressCity(String billingAddressCity) {
		this.billingAddressCity = billingAddressCity;
	}
	public String getBillingAddressStateProvince() {
		return billingAddressStateProvince;
	}
	public void setBillingAddressStateProvince(String billingAddressStateProvince) {
		this.billingAddressStateProvince = billingAddressStateProvince;
	}
	public int getBillingAddressCountry() {
		return billingAddressCountry;
	}
	public void setBillingAddressCountry(int billingAddressCountry) {
		this.billingAddressCountry = billingAddressCountry;
	}
	public String getCustomerNote() {
		return customerNote;
	}
	public void setCustomerNote(String customerNote) {
		this.customerNote = customerNote;
	}
	public int getNotificationPreference() {
		return notificationPreference;
	}
	public void setNotificationPreference(int notificationPreference) {
		this.notificationPreference = notificationPreference;
	}
	public int getEnableClientPortal() {
		return enableClientPortal;
	}
	public void setEnableClientPortal(int enableClientPortal) {
		this.enableClientPortal = enableClientPortal;
	}
    
    
}
