/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package indi.ucm.jdbc.entry;

/**
 * <p>
 * <b> TODO : Insert description of the class's responsibility/role. </b>
 * </p>
 */
public class CustomerAccount {
    private long customerId;
    private long customerBusinessId;
    private int customerAccountType;
    private int customerAccountStatus;
    private int assignedStaffUser;
    private String firstName;
    private String lastName;
    private String cFirstName;
    private String cLastName;
    private String emailAddress;
    private String mobilePhone;
    private String mailingAddressStreet;
    private String mailingAddressRoomNumber;
    private String mailingAddressCity;
    private String mailingAddressStateProvince;
    private int mailingAddressCountry;
    private String billingAddressStreet;
    private String billingAddressRoomNumber;
    private String billingAddressCity;
    private String billingAddressStateProvince;
    private int billingAddressCountry;
    private String customerNote;
    private int emailGroup;
    private int notificationPreference;
    private int enableClientPortal;
    private String clientPortalUserName;
    private String hashedPassword;
    private String securityQuestion;
    private String securityQuestionAnswer;
    private int enable2FactorAuthenticationLogin;
    private int sendPasscodeToDeviceId;

    /**
     * @return the customerId
     */
    public long getCustomerId() {
        return this.customerId;
    }

    /**
     * @param customerId
     *            the customerId to set
     */
    public void setCustomerId(final long customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the customerBusinessId
     */
    public long getCustomerBusinessId() {
        return this.customerBusinessId;
    }

    /**
     * @param customerBusinessId
     *            the customerBusinessId to set
     */
    public void setCustomerBusinessId(final long customerBusinessId) {
        this.customerBusinessId = customerBusinessId;
    }

    /**
     * @return the customerAccountType
     */
    public int getCustomerAccountType() {
        return this.customerAccountType;
    }

    /**
     * @param customerAccountType
     *            the customerAccountType to set
     */
    public void setCustomerAccountType(final int customerAccountType) {
        this.customerAccountType = customerAccountType;
    }

    /**
     * @return the customerAccountStatus
     */
    public int getCustomerAccountStatus() {
        return this.customerAccountStatus;
    }

    /**
     * @param customerAccountStatus
     *            the customerAccountStatus to set
     */
    public void setCustomerAccountStatus(final int customerAccountStatus) {
        this.customerAccountStatus = customerAccountStatus;
    }

    /**
     * @return the assignedStaffUser
     */
    public int getAssignedStaffUser() {
        return this.assignedStaffUser;
    }

    /**
     * @param assignedStaffUser
     *            the assignedStaffUser to set
     */
    public void setAssignedStaffUser(final int assignedStaffUser) {
        this.assignedStaffUser = assignedStaffUser;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return this.firstName;
    }

    /**
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return this.lastName;
    }

    /**
     * @param lastName
     *            the lastName to set
     */
    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    
    public String getcFirstName() {
		return cFirstName;
	}

	public void setcFirstName(String cFirstName) {
		this.cFirstName = cFirstName;
	}

	public String getcLastName() {
		return cLastName;
	}

	public void setcLastName(String cLastName) {
		this.cLastName = cLastName;
	}

	/**
     * @return the emailAddress
     */
    public String getEmailAddress() {
        return this.emailAddress;
    }

    /**
     * @param emailAddress
     *            the emailAddress to set
     */
    public void setEmailAddress(final String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * @return the mobilePhone
     */
    public String getMobilePhone() {
        return this.mobilePhone;
    }

    /**
     * @param mobilePhone
     *            the mobilePhone to set
     */
    public void setMobilePhone(final String mobilePhone) {
        this.mobilePhone = mobilePhone;
    }

    /**
     * @return the mailingAddressStreet
     */
    public String getMailingAddressStreet() {
        return this.mailingAddressStreet;
    }

    /**
     * @param mailingAddressStreet
     *            the mailingAddressStreet to set
     */
    public void setMailingAddressStreet(final String mailingAddressStreet) {
        this.mailingAddressStreet = mailingAddressStreet;
    }

    /**
     * @return the mailingAddressRoomNumber
     */
    public String getMailingAddressRoomNumber() {
        return this.mailingAddressRoomNumber;
    }

    /**
     * @param mailingAddressRoomNumber
     *            the mailingAddressRoomNumber to set
     */
    public void setMailingAddressRoomNumber(final String mailingAddressRoomNumber) {
        this.mailingAddressRoomNumber = mailingAddressRoomNumber;
    }

    /**
     * @return the mailingAddressCity
     */
    public String getMailingAddressCity() {
        return this.mailingAddressCity;
    }

    /**
     * @param mailingAddressCity
     *            the mailingAddressCity to set
     */
    public void setMailingAddressCity(final String mailingAddressCity) {
        this.mailingAddressCity = mailingAddressCity;
    }

    /**
     * @return the mailingAddressStateProvince
     */
    public String getMailingAddressStateProvince() {
        return this.mailingAddressStateProvince;
    }

    /**
     * @param mailingAddressStateProvince
     *            the mailingAddressStateProvince to set
     */
    public void setMailingAddressStateProvince(final String mailingAddressStateProvince) {
        this.mailingAddressStateProvince = mailingAddressStateProvince;
    }

    /**
     * @return the mailingAddressCountry
     */
    public int getMailingAddressCountry() {
        return this.mailingAddressCountry;
    }

    /**
     * @param mailingAddressCountry
     *            the mailingAddressCountry to set
     */
    public void setMailingAddressCountry(final int mailingAddressCountry) {
        this.mailingAddressCountry = mailingAddressCountry;
    }

    /**
     * @return the billingAddressStreet
     */
    public String getBillingAddressStreet() {
        return this.billingAddressStreet;
    }

    /**
     * @param billingAddressStreet
     *            the billingAddressStreet to set
     */
    public void setBillingAddressStreet(final String billingAddressStreet) {
        this.billingAddressStreet = billingAddressStreet;
    }

    /**
     * @return the billingAddressRoomNumber
     */
    public String getBillingAddressRoomNumber() {
        return this.billingAddressRoomNumber;
    }

    /**
     * @param billingAddressRoomNumber
     *            the billingAddressRoomNumber to set
     */
    public void setBillingAddressRoomNumber(final String billingAddressRoomNumber) {
        this.billingAddressRoomNumber = billingAddressRoomNumber;
    }

    /**
     * @return the billingAddressCity
     */
    public String getBillingAddressCity() {
        return this.billingAddressCity;
    }

    /**
     * @param billingAddressCity
     *            the billingAddressCity to set
     */
    public void setBillingAddressCity(final String billingAddressCity) {
        this.billingAddressCity = billingAddressCity;
    }

    /**
     * @return the billingAddressStateProvince
     */
    public String getBillingAddressStateProvince() {
        return this.billingAddressStateProvince;
    }

    /**
     * @param billingAddressStateProvince
     *            the billingAddressStateProvince to set
     */
    public void setBillingAddressStateProvince(final String billingAddressStateProvince) {
        this.billingAddressStateProvince = billingAddressStateProvince;
    }

    /**
     * @return the billingAddressCountry
     */
    public int getBillingAddressCountry() {
        return this.billingAddressCountry;
    }

    /**
     * @param billingAddressCountry
     *            the billingAddressCountry to set
     */
    public void setBillingAddressCountry(final int billingAddressCountry) {
        this.billingAddressCountry = billingAddressCountry;
    }

    /**
     * @return the customerNote
     */
    public String getCustomerNote() {
        return this.customerNote;
    }

    /**
     * @param customerNote
     *            the customerNote to set
     */
    public void setCustomerNote(final String customerNote) {
        this.customerNote = customerNote;
    }

    /**
     * @return the emailGroup
     */
    public int getEmailGroup() {
        return this.emailGroup;
    }

    /**
     * @param emailGroup
     *            the emailGroup to set
     */
    public void setEmailGroup(final int emailGroup) {
        this.emailGroup = emailGroup;
    }

    /**
     * @return the notificationPreference
     */
    public int getNotificationPreference() {
        return this.notificationPreference;
    }

    /**
     * @param notificationPreference
     *            the notificationPreference to set
     */
    public void setNotificationPreference(final int notificationPreference) {
        this.notificationPreference = notificationPreference;
    }

    /**
     * @return the enableClientPortal
     */
    public int getEnableClientPortal() {
        return this.enableClientPortal;
    }

    /**
     * @param enableClientPortal
     *            the enableClientPortal to set
     */
    public void setEnableClientPortal(final int enableClientPortal) {
        this.enableClientPortal = enableClientPortal;
    }

    /**
     * @return the clientPortalUserName
     */
    public String getClientPortalUserName() {
        return this.clientPortalUserName;
    }

    /**
     * @param clientPortalUserName
     *            the clientPortalUserName to set
     */
    public void setClientPortalUserName(final String clientPortalUserName) {
        this.clientPortalUserName = clientPortalUserName;
    }

    /**
     * @return the hashedPassword
     */
    public String getHashedPassword() {
        return this.hashedPassword;
    }

    /**
     * @param hashedPassword
     *            the hashedPassword to set
     */
    public void setHashedPassword(final String hashedPassword) {
        this.hashedPassword = hashedPassword;
    }

    /**
     * @return the securityQuestion
     */
    public String getSecurityQuestion() {
        return this.securityQuestion;
    }

    /**
     * @param securityQuestion
     *            the securityQuestion to set
     */
    public void setSecurityQuestion(final String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    /**
     * @return the securityQuestionAnswer
     */
    public String getSecurityQuestionAnswer() {
        return this.securityQuestionAnswer;
    }

    /**
     * @param securityQuestionAnswer
     *            the securityQuestionAnswer to set
     */
    public void setSecurityQuestionAnswer(final String securityQuestionAnswer) {
        this.securityQuestionAnswer = securityQuestionAnswer;
    }

    /**
     * @return the enable2FactorAuthenticationLogin
     */
    public int getEnable2FactorAuthenticationLogin() {
        return this.enable2FactorAuthenticationLogin;
    }

    /**
     * @param enable2FactorAuthenticationLogin
     *            the enable2FactorAuthenticationLogin to set
     */
    public void setEnable2FactorAuthenticationLogin(final int enable2FactorAuthenticationLogin) {
        this.enable2FactorAuthenticationLogin = enable2FactorAuthenticationLogin;
    }

    /**
     * @return the sendPasscodeToDeviceId
     */
    public int getSendPasscodeToDeviceId() {
        return this.sendPasscodeToDeviceId;
    }

    /**
     * @param sendPasscodeToDeviceId
     *            the sendPasscodeToDeviceId to set
     */
    public void setSendPasscodeToDeviceId(final int sendPasscodeToDeviceId) {
        this.sendPasscodeToDeviceId = sendPasscodeToDeviceId;
    }
}
