package indi.ucm.jdbc.entry;

// Info of group notification email attachment
public class GroupNotificationEmailAttachment {
    private long emailAttachmentId;
    private long documentNameId;

    /**
     * @return the emailAttachmentId
     */
    public long getEmailAttachmentId() {
        return this.emailAttachmentId;
    }

    /**
     * @param emailAttachmentId
     *            the emailAttachmentId to set
     */
    public void setEmailAttachmentId(final long emailAttachmentId) {
        this.emailAttachmentId = emailAttachmentId;
    }

    /**
     * @return the documentNameId
     */
    public long getDocumentNameId() {
        return this.documentNameId;
    }

    /**
     * @param documentNameId
     *            the documentNameId to set
     */
    public void setDocumentNameId(final long documentNameId) {
        this.documentNameId = documentNameId;
    }
}
