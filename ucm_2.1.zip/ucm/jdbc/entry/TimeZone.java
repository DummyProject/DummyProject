package indi.ucm.jdbc.entry;

public class TimeZone {
	private int timeZoneId;
	private String timeZoneLocation;
	private String gmt;
	private int offset;
	
	public int getTimeZoneId() {
		return timeZoneId;
	}
	public void setTimeZoneId(int timeZoneId) {
		this.timeZoneId = timeZoneId;
	}
	public String getTimeZoneLocation() {
		return timeZoneLocation;
	}
	public void setTimeZoneLocation(String timeZoneLocation) {
		this.timeZoneLocation = timeZoneLocation;
	}
	public String getGmt() {
		return gmt;
	}
	public void setGmt(String gmt) {
		this.gmt = gmt;
	}
	public int getOffset() {
		return offset;
	}
	public void setOffset(int offset) {
		this.offset = offset;
	}	
}
