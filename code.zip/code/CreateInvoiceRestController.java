package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerBusinessDao;
import indi.ucm.jdbc.dao.CustomerInvoiceStatusDao;
import indi.ucm.jdbc.dao.CustomerWorkBillingRateDao;
import indi.ucm.jdbc.dao.CustomerWorkDao;
import indi.ucm.jdbc.dao.CustomerWorkInvoiceDao;
import indi.ucm.jdbc.dao.CustomerWorkInvoiceMappingDao;
import indi.ucm.jdbc.dao.CustomerWorkStatusDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.SendMailRequestDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.dao.WorkLocationTypeDao;
import indi.ucm.jdbc.dao.WorkReminderNotifyTimeDao;
import indi.ucm.jdbc.dao.WorkRepeatIntervalDao;
import indi.ucm.jdbc.dao.WorkTimeDurationDao;
import indi.ucm.jdbc.entry.BillingCurrency;
import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.entry.CustomerBusiness;
import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.CustomerWorkInvoice;
import indi.ucm.jdbc.entry.InvoiceInfo;
import indi.ucm.jdbc.entry.WorkInfoForInvoice;
import indi.ucm.security.common.GenerateCurrencySymbolHelper;

import java.lang.reflect.Type;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@RestController
public class CreateInvoiceRestController {
    @Autowired
    CustomerWorkDao customerWorkDao;
    @Autowired
    MasterUserListDao masterUserListDao;
    @Autowired
    CustomerWorkStatusDao customerWorkStatusDao;
    @Autowired
    WorkRepeatIntervalDao workRepeatIntervalDao;
    @Autowired
    WorkTimeDurationDao workTimeDurationDao;
    @Autowired
    CustomerWorkBillingRateDao customerWorkBillingRateDao;
    @Autowired
    CustomerInvoiceStatusDao customerInvoiceStatusDao;
    @Autowired
    CustomerWorkInvoiceDao customerWorkInvoiceDao;
    @Autowired
    CustomerWorkInvoiceMappingDao customerWorkInvoiceMappingDao;
    @Autowired
    WorkReminderNotifyTimeDao workReminderNotifyTimeDao;
    @Autowired
    WorkLocationTypeDao workLocationTypeDao;
    @Autowired
    CustomerAccountDao customerAccountDao;
    @Autowired
    StaffUserDao staffUserDao;
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    CustomerBusinessDao customerBusinessDao;
    @Autowired
    SendMailRequestDao sendMailRequestDao;

    @RequestMapping(value = "/getNotInvoicedWorks/{userName}/{businessId}/{clientId}", method = RequestMethod.GET)
    public ResponseEntity<List> getNotInvoicedWorks(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("clientId") final String clientId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);
        int staffID = -1;
        if (businessId != null && businessId.length() > 1) {
            staffID = this.staffUserDao.getStaffUserByName(userName, masterUserId).getStaffUserId();
        }
        List<CustomerWork> customerWorks = this.customerWorkDao.getNotInvoicedWorks(masterUserId, staffID, clientId);

        List<WorkInfoForInvoice> workInfoForInvoices = new ArrayList<WorkInfoForInvoice>();
        for (int i = 0; i < customerWorks.size(); i++) {

            int workStatusID = customerWorks.get(i).getWorkStatus();
            String workStatus = this.customerWorkStatusDao.getStatusByID(workStatusID, masterUserId);

            String client = "";
            CustomerAccount customerAccount = this.customerAccountDao.getCustomerAccount(customerWorks.get(i).getCustomerId(),
                masterUserId);
            if (customerAccount != null) {
                if (customerAccount.getCustomerAccountType() == 1) {
                    client = customerAccount.getFirstName() + " " + customerAccount.getLastName();
                } else {
                    CustomerBusiness customerBusiness = this.customerBusinessDao.getCustomerBusinessByBusinessId(
                        customerAccount.getCustomerBusinessId(), masterUserId);
                    client = customerBusiness.getBusinessName();
                }
            }


            BillingCurrency bc = this.masterUserListDao.getBillingCurrency(1);
            String formalBillingRate = GenerateCurrencySymbolHelper.generateCurrencySymbol(
                String.valueOf(customerWorks.get(i).getWorkBillingRate()), bc);
            int workTimeDurationID = customerWorks.get(i).getWorkTimeDuration();
            String workTimeDuration = this.workTimeDurationDao.getworkTimeDurationByID(workTimeDurationID, masterUserId)
                .getWorkTimeDuration();
            double totalAmount = (double) customerWorks.get(i).getWorkBillingRate() / 60
                * this.workTimeDurationDao.getworkTimeDurationByID(workTimeDurationID, masterUserId).getWorkTimeDurationMinutes();
            String formalSubTotal = GenerateCurrencySymbolHelper.generateCurrencySymbol(String.valueOf(totalAmount), bc);

            WorkInfoForInvoice workInfoForInvoice = new WorkInfoForInvoice();
            workInfoForInvoice.setCustomerWorkId(customerWorks.get(i).getCustomerWorkId());
            workInfoForInvoice.setWorkName(customerWorks.get(i).getWorkName());
            workInfoForInvoice.setCustomerId(customerWorks.get(i).getCustomerId());
            workInfoForInvoice.setClient(client);
            workInfoForInvoice.setWorkStatus(workStatus);
            workInfoForInvoice.setScheduleStartDate(customerWorks.get(i).getScheduleStartDate());
            workInfoForInvoice.setScheduleStartTime(customerWorks.get(i).getScheduleStartTime());
            workInfoForInvoice.setWorkTimeDuration(workTimeDuration);
            workInfoForInvoice.setWorkDescription(customerWorks.get(i).getWorkDescription());
            workInfoForInvoice.setFormalWorkBillingRate(formalBillingRate);
            workInfoForInvoice.setSubTotal(totalAmount);
            workInfoForInvoice.setFormalSubTotal(formalSubTotal);

            workInfoForInvoices.add(workInfoForInvoice);
        }

        return new ResponseEntity<List>(workInfoForInvoices, HttpStatus.OK);
    }

    @RequestMapping(value = "/createNewInvoice", method = RequestMethod.POST)
    public ResponseEntity<String> createNewInvoice(final HttpServletRequest request) {
        String userName = request.getParameter("userName");
        String businessId = request.getParameter("businessId");
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);
        int invoiceId = Integer.parseInt(request.getParameter("invoiceId"));
        int customerId = Integer.parseInt(request.getParameter("customerId"));
        String customerName = request.getParameter("client");
        Date invoiceDate = Date.valueOf(request.getParameter("invoiceDate"));
        double totalAmount = Double.parseDouble(request.getParameter("totalAmount"));

        CustomerWorkInvoice cwi = new CustomerWorkInvoice();
        cwi.setCustomerWorkInvoiceId(invoiceId);
        cwi.setCustomerId(customerId);
        cwi.setCustomerName(customerName);
        cwi.setInvoiceDate(invoiceDate);
        cwi.setInvoiceTotalAmount(totalAmount);

        this.customerWorkInvoiceDao.createCustomerAccountInvoice(cwi, masterUserId);

        try {
            String invoiceJsonData = request.getParameter("invoiceJsonData");
            InvoiceInfo invoiceInfo;
            Type listType = new TypeToken<ArrayList<InvoiceInfo>>() {}.getType();
            Gson gson = new Gson();
            List<InvoiceInfo> invoiceInfoList = (List<InvoiceInfo>) gson.fromJson(invoiceJsonData, listType);

            for (int i = 0; i < invoiceInfoList.size(); i++) {
                invoiceInfo = invoiceInfoList.get(i);

                long workId = invoiceInfo.getCustomerWorkId();
                this.customerWorkInvoiceMappingDao.createCustomerAccountInvoiceMapping(invoiceId, workId, masterUserId);
                this.customerWorkDao.markAsInvoiced(workId, masterUserId);

            }
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>("Create new invoices fail", HttpStatus.OK);
        }
        return new ResponseEntity<String>("Create new invoices Successfully", HttpStatus.OK);
    }

    @RequestMapping(value = "/getAmountWithCurrency", method = RequestMethod.POST)
    public ResponseEntity<String> getAmountWithCurrency(final HttpServletRequest request) {
        String amount = request.getParameter("amount");
        int currencyId = Integer.parseInt(request.getParameter("currencyId"));

        String amountWithCurreny = null;
        BillingCurrency bc = this.masterUserListDao.getBillingCurrency(currencyId);
        amountWithCurreny = GenerateCurrencySymbolHelper.generateCurrencySymbol(amount, bc);

        return new ResponseEntity<String>(amountWithCurreny, HttpStatus.OK);
    }
}
