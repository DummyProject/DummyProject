package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerWorkInvoiceMapping;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerWorkInvoiceMappingMapper implements RowMapper<CustomerWorkInvoiceMapping> {

    public CustomerWorkInvoiceMapping mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerWorkInvoiceMapping cwm = new CustomerWorkInvoiceMapping();
        cwm.setCustomerWorkId(rs.getLong("customer_work_ID"));
        cwm.setCustomerWorkInvoiceId(rs.getLong("customer_work_invoice_ID"));

        return cwm;
    }

}
