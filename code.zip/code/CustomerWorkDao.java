package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.mapper.CustomerWorkMapper;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;


public class CustomerWorkDao extends JdbcDaoSupport {

    private final String SQL_INSERT_ONE_CUSTOMER_WORK_POSTFIX = " (work_name," + " customer_work_ID," + " customer_ID, "
        + "work_status," + " assigned_staff_user, " + "schedule_start_date, " + "schedule_end_date, " + "schedule_start_time, "
        + "schedule_end_time, " + "work_repeat_interval, " + "work_time_duration, " + "work_location_type, " + "work_description,"
        + "work_billable," + " wrok_billing_rate," + " billing_currency_ID, " + "work_reminder_notify_staff,"
        + " work_reminder_notify_staff_time," + " work_reminder_notify_staff_method, " + "work_reminder_notify_customer, "
        + "work_reminder_notify_customer_time," + "work_reminder_notify_customer_method, " + "work_reminder_message) "
        // + "actual_complete_date, "+ "actual_complete_time) "
        // Ã¦Å¡â€šÃ¦â€”Â¶Ã¤Â¸ï¿½Ã§â€�Â¨
        + "VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private final String SQL_SELECT_CUSTOMER_WORK_PREFIX = " select work_name," + " customer_work_ID," + " customer_ID, "
        + "work_status," + " assigned_staff_user, " + "schedule_start_date, " + "schedule_end_date, " + "schedule_start_time, "
        + "schedule_end_time, " + "work_repeat_interval, " + "work_time_duration, " + "work_location_type, " + "work_description,"
        + "work_billable," + " wrok_billing_rate," + " billing_currency_ID, " + "work_reminder_notify_staff,"
        + " work_reminder_notify_staff_time," + " work_reminder_notify_staff_method, " + "work_reminder_notify_customer, "
        + "work_reminder_notify_customer_time," + "work_reminder_notify_customer_method, " + "work_reminder_message, "
        + "actual_complete_date, " + "actual_complete_time" + " from  customer_work_";
    private final String SQL_SELECT_CUSTOMER_WORK_POSTFIX = " where customer_work_ID = ?";

    private final String SQL_UPDATE_CUSTOMER_WORK_POSTFIX = " set work_name = ?," + "work_status = ?," + " customer_ID = ?,"
        + " assigned_staff_user = ? , " + "schedule_start_date = ?, " + "schedule_end_date = ?, " + "schedule_start_time = ?, "
        + "schedule_end_time = ?, " + "work_repeat_interval = ?, " + "work_time_duration = ?, " + "work_location_type = ?, "
        + "work_description = ?," + "work_billable = ?," + " wrok_billing_rate = ?," + " billing_currency_ID = ?, "
        + "work_reminder_notify_staff = ?," + " work_reminder_notify_staff_time = ?," + " work_reminder_notify_staff_method = ?, "
        + "work_reminder_notify_customer = ?, " + "work_reminder_notify_customer_time = ?,"
        + "work_reminder_notify_customer_method = ?, " + "work_reminder_message = ?";


    private final String SQL_DELETE_WORK_PREFIX = "delete from customer_work_";

    private final String SQL_UPDATE_WORK_INVOICE_STATUS = " set invoice_status = ?";

    /**
     * create customer work
     * 
     * @param StaffUser
     */
    public void createCustomerWork(final CustomerWork customerWork, final int masterUserId) {
        this.getJdbcTemplate().update("INSERT INTO customer_work_" + masterUserId + this.SQL_INSERT_ONE_CUSTOMER_WORK_POSTFIX,
            customerWork.getWorkName(), customerWork.getCustomerWorkId(), customerWork.getCustomerId(),
            customerWork.getWorkStatus(), customerWork.getAssignedStaffUser(), customerWork.getScheduleStartDate(),
            customerWork.getScheduleEndDate(), customerWork.getScheduleStartTime(), customerWork.getScheduleEndTime(),
            customerWork.getWorkRepeatInterval(), customerWork.getWorkTimeDuration(), customerWork.getWorkLocationType(),
            customerWork.getWorkDescription(), customerWork.getWorkBillable(), customerWork.getWorkBillingRate(),
            customerWork.getBillingCurrencyId(), customerWork.getWorkReminderNotifyStaff(),
            customerWork.getWorkReminderNotifyStaffTime(), customerWork.getWorkReminderNotifyStaffMethod(),
            customerWork.getWorkReminderNotifyCustomer(), customerWork.getWorkReminderNotifyCustomerTime(),
            customerWork.getWorkReminderNotifyCustomerMethod(), customerWork.getWorkReminderMessage());
    }


    public void modifyWork(final CustomerWork customerWork, final int masterUserId) {
        // TODO
        this.getJdbcTemplate().update(
            "UPDATE customer_work_" + masterUserId + this.SQL_UPDATE_CUSTOMER_WORK_POSTFIX + this.SQL_SELECT_CUSTOMER_WORK_POSTFIX,
            customerWork.getWorkName(), customerWork.getWorkStatus(), customerWork.getCustomerId(),
            customerWork.getAssignedStaffUser(), customerWork.getScheduleStartDate(), customerWork.getScheduleEndDate(),
            customerWork.getScheduleStartTime(), customerWork.getScheduleEndTime(), customerWork.getWorkRepeatInterval(),
            customerWork.getWorkTimeDuration(), customerWork.getWorkLocationType(), customerWork.getWorkDescription(),
            customerWork.getWorkBillable(), customerWork.getWorkBillingRate(), customerWork.getBillingCurrencyId(),
            customerWork.getWorkReminderNotifyStaff(), customerWork.getWorkReminderNotifyStaffTime(),
            customerWork.getWorkReminderNotifyStaffMethod(), customerWork.getWorkReminderNotifyCustomer(),
            customerWork.getWorkReminderNotifyCustomerTime(), customerWork.getWorkReminderNotifyCustomerMethod(),
            customerWork.getWorkReminderMessage(), customerWork.getCustomerWorkId());
    }

    public List<CustomerWork> getAllWorkItems(final int masterUserId, final int staffId) {
        List<CustomerWork> customerWorks = null;
        if (staffId == -1) {
            customerWorks = this.getJdbcTemplate().query(this.SQL_SELECT_CUSTOMER_WORK_PREFIX + masterUserId, new Object[] {},
                new CustomerWorkMapper());
        } else {
            customerWorks = this.getJdbcTemplate().query(
                this.SQL_SELECT_CUSTOMER_WORK_PREFIX + masterUserId + " cw WHERE EXISTS (select 1 from customer_account_"
                    + masterUserId + " ca where ca.customer_ID = cw.customer_ID and ca.assigned_staff_user = ?)",
                new Object[] {staffId}, new CustomerWorkMapper());
        }

        return customerWorks;
    }

    public void deleteWork(final String workId, final int masterUserId) {
        this.getJdbcTemplate().update(this.SQL_DELETE_WORK_PREFIX + masterUserId + this.SQL_SELECT_CUSTOMER_WORK_POSTFIX,
            new Object[] {workId});
    }

    /**
     * create customer_work_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`work_name` varchar(100) NOT NULL,");
        sb.append("`customer_work_ID` bigint NOT NULL,");
        sb.append("`customer_ID` bigint NOT NULL,");
        sb.append("`work_status` tinyint  NOT NULL,");
        sb.append("`assigned_staff_user` int  NOT NULL,");
        sb.append("`schedule_start_date` date  NOT NULL,");
        sb.append("`schedule_end_date` date  NOT NULL,");
        sb.append("`schedule_start_time` time  NOT NULL,");
        sb.append("`schedule_end_time` time  NOT NULL,");
        sb.append("`work_repeat_interval` tinyint  NOT NULL,");
        sb.append("`work_time_duration` tinyint  NOT NULL,");
        sb.append("`work_location_type` tinyint  NOT NULL,");
        sb.append("`work_description` varchar(2000)  NOT NULL,");
        sb.append("`work_billable` tinyint  NOT NULL,");
        sb.append("`wrok_billing_rate` smallint  NOT NULL,");
        sb.append("`billing_currency_ID` smallint,");
        sb.append("`work_reminder_notify_staff` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_staff_time` tinyint,");
        sb.append("`work_reminder_notify_staff_method` tinyint,");
        sb.append("`work_reminder_notify_customer` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_customer_time` int,");
        sb.append("`work_reminder_notify_customer_method` int,");
        sb.append("`work_reminder_message` varchar(1000)  NOT NULL,");
        sb.append("`actual_complete_date` date  ,");
        sb.append("`actual_complete_time` time  ,");
        sb.append("`invoice_status` smallint  default 0,");
        sb.append("PRIMARY KEY (`customer_work_ID`))character set = utf8;");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public CustomerWork getWorkByID(final int customerWorkID, final int masterUserId) {
        try {
            CustomerWork customerWork = this.getJdbcTemplate().queryForObject(
                this.SQL_SELECT_CUSTOMER_WORK_PREFIX + masterUserId + this.SQL_SELECT_CUSTOMER_WORK_POSTFIX,
                new Object[] {customerWorkID}, new CustomerWorkMapper());
            return customerWork;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }


    public List<CustomerWork> getNotInvoicedWorks(final int masterUserId, final int staffId, final String clientId) {
        List<CustomerWork> customerWorks = null;
        if (staffId == -1) {
            customerWorks = this.getJdbcTemplate().query(
                this.SQL_SELECT_CUSTOMER_WORK_PREFIX + masterUserId + " where customer_ID = " + clientId, new Object[] {},
                new CustomerWorkMapper());
        } else {
            customerWorks = this.getJdbcTemplate().query(
                this.SQL_SELECT_CUSTOMER_WORK_PREFIX + masterUserId + " cw WHERE EXISTS (select 1 from customer_account_"
                    + masterUserId
                    + " ca where ca.customer_ID = cw.customer_ID and ca.assigned_staff_user = ? and cw.customer_ID = " + clientId
                    + ")", new Object[] {staffId}, new CustomerWorkMapper());
        }

        return customerWorks;
    }

    public void markAsInvoiced(final long workId, final int masterUserId) {
        updateInvoiceStatus(workId, masterUserId, 1);
    }

    public void markAsNotInvoiced(final long workId, final int masterUserId) {
        updateInvoiceStatus(workId, masterUserId, 0);
    }

    public void updateInvoiceStatus(final long workId, final int masterUserId, final int status) {
        this.getJdbcTemplate().update("UPDATE customer_work_" + masterUserId + this.SQL_UPDATE_WORK_INVOICE_STATUS, status);
    }
}
