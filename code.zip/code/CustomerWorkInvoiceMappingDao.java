package indi.ucm.jdbc.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkInvoiceMappingDao extends JdbcDaoSupport {
    private final String SQL_INSERT_CUSTOMER_WORK_INVOICE_MAPPING_POSTFIX = " (customer_work_invoice_ID,customer_work_ID) VALUES (?,?)";

    public void createCustomerAccountInvoiceMapping(final long invoiceId, final long workId, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_work_invoice_mapping_" + masterUserId + this.SQL_INSERT_CUSTOMER_WORK_INVOICE_MAPPING_POSTFIX,
            invoiceId, workId);
    }

    /**
     * create customer_work_invoice_mapping_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_work_invoice_ID` bigint NOT NULL,");
        sb.append("`customer_work_ID` bigint NOT NULL,");
        sb.append("PRIMARY KEY (`customer_work_invoice_ID`))character set = utf8;");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
