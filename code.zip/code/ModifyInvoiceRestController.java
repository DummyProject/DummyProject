package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerWorkInvoiceDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.CustomerWorkInvoice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class ModifyInvoiceRestController {
    @Autowired
    MasterUserListDao masterUserListDao;
    @Autowired
    StaffUserDao staffUserDao;
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    CustomerAccountDao customerAccountDao;
    @Autowired
    CustomerWorkInvoiceDao customerWorkInvoiceDao;

    // -------------------Retrieve invoices---------------
    @RequestMapping(value = "/invoices/{userName}/{businessId}/{clientId}", method = RequestMethod.GET)
    public ResponseEntity<List> getInvoices(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("clientId") final String clientId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);

        List<CustomerWorkInvoice> cwis = this.customerWorkInvoiceDao.getInvoiceByCustomerId(Integer.parseInt(clientId),
            masterUserId);

        return new ResponseEntity<List>(cwis, HttpStatus.OK);
    }


}
