package indi.ucm.jdbc.entry;

public class WorkInfoForInvoice {
    private long customerWorkId;
    private String workName;
    private long customerId;
    private String client;
    private String workStatus;
    private String scheduleStartDate;
    private String scheduleStartTime;
    private String workTimeDuration;
    private String workDescription;
    private String formalWorkBillingRate;
    private double subTotal;
    private String formalSubTotal;


    /**
     * @return the client
     */
    public String getClient() {
        return this.client;
    }

    /**
     * @param client
     *            the client to set
     */
    public void setClient(final String client) {
        this.client = client;
    }


    /**
     * @param workTimeDuration
     *            the workTimeDuration to set
     */
    public void setWorkTimeDuration(final String workTimeDuration) {
        this.workTimeDuration = workTimeDuration;
    }

    /**
     * @return the customerWorkId
     */
    public long getCustomerWorkId() {
        return this.customerWorkId;
    }

    /**
     * @param customerWorkId
     *            the customerWorkId to set
     */
    public void setCustomerWorkId(final long customerWorkId) {
        this.customerWorkId = customerWorkId;
    }

    /**
     * @return the workName
     */
    public String getWorkName() {
        return this.workName;
    }

    /**
     * @param workName
     *            the workName to set
     */
    public void setWorkName(final String workName) {
        this.workName = workName;
    }

    /**
     * @return the customerId
     */
    public long getCustomerId() {
        return this.customerId;
    }

    /**
     * @param customerId
     *            the customerId to set
     */
    public void setCustomerId(final long customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the workStatus
     */
    public String getWorkStatus() {
        return this.workStatus;
    }

    /**
     * @param workStatus
     *            the workStatus to set
     */
    public void setWorkStatus(final String workStatus) {
        this.workStatus = workStatus;
    }

    /**
     * @return the scheduleStartDate
     */
    public String getScheduleStartDate() {
        return this.scheduleStartDate;
    }

    /**
     * @param scheduleStartDate
     *            the scheduleStartDate to set
     */
    public void setScheduleStartDate(final String scheduleStartDate) {
        this.scheduleStartDate = scheduleStartDate;
    }

    /**
     * @return the scheduleStartTime
     */
    public String getScheduleStartTime() {
        return this.scheduleStartTime;
    }

    /**
     * @param scheduleStartTime
     *            the scheduleStartTime to set
     */
    public void setScheduleStartTime(final String scheduleStartTime) {
        this.scheduleStartTime = scheduleStartTime;
    }

    /**
     * @return the workTimeDuration
     */
    public String getWorkTimeDuration() {
        return this.workTimeDuration;
    }

    /**
     * @return the workDescription
     */
    public String getWorkDescription() {
        return this.workDescription;
    }

    /**
     * @param workDescription
     *            the workDescription to set
     */
    public void setWorkDescription(final String workDescription) {
        this.workDescription = workDescription;
    }

    /**
     * @return the formalWorkBillingRate
     */
    public String getFormalWorkBillingRate() {
        return this.formalWorkBillingRate;
    }

    /**
     * @param formalWorkBillingRate
     *            the formalWorkBillingRate to set
     */
    public void setFormalWorkBillingRate(final String formalWorkBillingRate) {
        this.formalWorkBillingRate = formalWorkBillingRate;
    }

    /**
     * @return the subTotal
     */
    public double getSubTotal() {
        return this.subTotal;
    }

    /**
     * @param subTotal
     *            the subTotal to set
     */
    public void setSubTotal(final double subTotal) {
        this.subTotal = subTotal;
    }

    /**
     * @return the formalSubTotal
     */
    public String getFormalSubTotal() {
        return this.formalSubTotal;
    }

    /**
     * @param formalSubTotal
     *            the formalSubTotal to set
     */
    public void setFormalSubTotal(final String formalSubTotal) {
        this.formalSubTotal = formalSubTotal;
    }


}
