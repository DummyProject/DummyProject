package indi.ucm.controller.rest;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Controller
public class UploadRestController {

    @RequestMapping(value = "/uploadLogo")
	@ResponseBody
	public ResponseEntity<String> upload(final HttpServletRequest request) {
		String userName = request.getParameter("userName");

		// å°†å½“å‰�ä¸Šä¸‹æ–‡åˆ�å§‹åŒ–ç»™ CommonsMutipartResolver ï¼ˆå¤šéƒ¨åˆ†è§£æž�å™¨ï¼‰
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());
		// æ£€æŸ¥formä¸­æ˜¯å�¦æœ‰enctype="multipart/form-data"
		if (multipartResolver.isMultipart(request)) {
			// å°†requestå�˜æˆ�å¤šéƒ¨åˆ†request
			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			// èŽ·å�–multiRequest ä¸­æ‰€æœ‰çš„æ–‡ä»¶å��
			Iterator iter = multiRequest.getFileNames();

			while (iter.hasNext()) {
				// ä¸€æ¬¡é��åŽ†æ‰€æœ‰æ–‡ä»¶
				MultipartFile file = multiRequest.getFile(iter.next()
						.toString());
				if (file != null) {
					String path = "C:\\UCM\\" + userName;
					File targetFile = new File(path, file.getOriginalFilename());
					if (!targetFile.exists()) {
						targetFile.mkdirs();
					}

					System.out.println(path);
					// ä¸Šä¼ 
					try {
						System.out.println("begin");
						file.transferTo(targetFile);
						System.out.println("end");
					} catch (IllegalStateException | IOException e) {
						e.printStackTrace();
					}
				}

			}

		}

		return new ResponseEntity<String>("uploaded", HttpStatus.OK);
	}
}
