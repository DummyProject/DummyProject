package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.StaffUserBaseInfo;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StaffUserBaseInfoMapper implements RowMapper<StaffUserBaseInfo> {

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet,
     * int)
     */
    public StaffUserBaseInfo mapRow(final ResultSet rs, final int num) throws SQLException {
        StaffUserBaseInfo subi = new StaffUserBaseInfo();
        subi.setStaffUserId(rs.getInt("staff_user_ID"));
        subi.setStaffUserName(rs.getString("username"));
        return subi;
    }

}
