package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerAccount;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerAccountMapper implements RowMapper<CustomerAccount>{

	@Override
	public CustomerAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerAccount ca = new CustomerAccount();
		ca.setCustomerId(rs.getInt("customer_ID"));
		ca.setCustomerBusinessId(rs.getInt("customer_business_ID"));
		ca.setCustomerAccountType(rs.getInt("customer_account_type"));
		ca.setCustomerAccountStatus(rs.getInt("customer_account_status"));
		ca.setAssignedStaffUser(rs.getInt("assigned_staff_user"));
		ca.setFirstName(rs.getString("first_name"));
		ca.setLastName(rs.getString("last_name"));
		ca.setEmailAddress(rs.getString("email_address"));
		ca.setMobilePhone(rs.getString("mobile_phone"));
		ca.setMailingAddressStreet(rs.getString("mailing_address_street"));
		ca.setMailingAddressRoomNumber(rs.getString("mailing_address_room_number"));
		ca.setMailingAddressCity(rs.getString("mailing_address_city"));
		ca.setMailingAddressStateProvince(rs.getString("mailing_address_state_province"));
		ca.setMailingAddressCountry(rs.getInt("mailing_addresss_country"));
		ca.setBillingAddressStreet(rs.getString("billing_address_street"));
		ca.setBillingAddressRoomNumber(rs.getString("billing_address_room_number"));
		ca.setBillingAddressCity(rs.getString("billing_address_city"));
		ca.setBillingAddressStateProvince(rs.getString("billing_address_state_province"));
		ca.setBillingAddressCountry(rs.getInt("billing_addresss_country"));
		ca.setCustomerNote(rs.getString("customer_note"));
		ca.setEmailGroup(rs.getInt("email_group"));
		ca.setNotificationPreference(rs.getInt("notification_preference"));
		ca.setEnableClientPortal(rs.getInt("client_portal_username"));
		ca.setClientPortalUserName(rs.getString("client_portal_username"));
		ca.setHashedPassword(rs.getString("hashed_password"));
		ca.setSecurityQuestion(rs.getString("security_question"));
		ca.setSecurityQuestionAnswer(rs.getString("security_question_answer"));
		ca.setEnable2FactorAuthenticationLogin(rs.getInt("enable_2_factor_authentication_login"));
		ca.setSendPasscodeToDeviceId(rs.getShort("send_passcode_to_device_ID"));
		return ca;
	}

}
