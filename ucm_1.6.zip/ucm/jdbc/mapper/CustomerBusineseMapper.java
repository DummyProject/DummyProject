package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerBusinese;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerBusineseMapper implements RowMapper<CustomerBusinese> {

    @Override
    public CustomerBusinese mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerBusinese mb = new CustomerBusinese();
        mb.setCustomerBusineseId(rs.getLong("master_user_businese_ID"));
        mb.setCustomerId(rs.getLong(""));
        mb.setBusineseName(rs.getString("businese_name"));
        mb.setBusineseType(rs.getInt("businese_type_ID"));
        mb.setBusineseTimeZone(rs.getShort("businese_time_zone_ID"));
        mb.setBusinesePhoneNumber(rs.getString("businese_phone_number"));
        mb.setBusineseFaxNumber(rs.getString("businese_fax_number"));
        mb.setBusineseAddressStreet(rs.getString("businese_address_street"));
        mb.setBusineseAddressRoomNumber(rs.getString("businese_address_room_number"));
        mb.setBusineseAddressCity(rs.getString("businese_address_city"));
        mb.setBusineseAddressStateProvince(rs.getString("businese_address_state_province"));
        mb.setBusineseAddressCountry(rs.getInt("businese_addresss_country_ID"));
        mb.setBusineseDescription(rs.getString("businese_description"));
        return mb;
    }

}
