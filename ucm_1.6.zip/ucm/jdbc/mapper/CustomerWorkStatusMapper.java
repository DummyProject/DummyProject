package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerWorkStatus;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerWorkStatusMapper implements RowMapper<CustomerWorkStatus> {

    public CustomerWorkStatus mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerWorkStatus cws = new CustomerWorkStatus();
        cws.setWorkStatusId(rs.getInt("work_status_ID"));
        cws.setWorkStatusName(rs.getString("work_status_name"));
        return cws;
    }

}
