package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerWork;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerWorkMapper implements RowMapper<CustomerWork> {

    public CustomerWork mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerWork cw = new CustomerWork();
        cw.setCustomerWorkId(rs.getLong("customer_work_ID"));
        cw.setCustomerId(rs.getLong("customer_ID"));
        cw.setWorkStatus(rs.getInt("work_status"));
        cw.setAssignedStaffUser(rs.getInt("assigned_staff_user"));
        cw.setScheduleStartDate(rs.getDate("schedule_start_date"));
        cw.setScheduleEndDate(rs.getDate("schedule_end_date"));
        cw.setScheduleStartTime(rs.getTime("schedule_start_time"));
        cw.setScheduleEndTime(rs.getTime("schedule_end_time"));
        cw.setWorkRepeatInterval(rs.getInt("work_repeat_interval"));
        cw.setWorkTimeDuration(rs.getInt("work_time_duration"));
        cw.setWorkLocationType(rs.getInt("work_location_type"));
        cw.setWorkDescription(rs.getString("work_description"));
        cw.setWorkDocumentsId(rs.getLong("work_documents_ID"));
        cw.setWorkBillable(rs.getInt("work_billable"));
        cw.setWorkBillingRate(rs.getInt("wrok_billing_rate"));
        cw.setBillingCurrencyId(rs.getInt("billing_currency_ID"));
        cw.setWorkReminderNotifyStaff(rs.getInt("work_reminder_notify_staff"));
        cw.setWorkReminderNotifyStaffTime(rs.getInt("work_reminder_notify_staff_time"));
        cw.setWorkReminderNotifyStaffMethod(rs.getInt("work_reminder_notify_staff_method"));
        cw.setWorkReminderNotifyCustomer(rs.getInt("work_reminder_notify_customer"));
        cw.setWorkReminderNotifyCustomerTime(rs.getInt("work_reminder_notify_customer_time"));
        cw.setWorkReminderNotifyCustomerMethod(rs.getInt("work_reminder_notify_customer_method"));
        cw.setWorkReminderMessage(rs.getString("work_reminder_message"));
        cw.setActualCompleteDate(rs.getDate("actual_complete_date"));
        cw.setActualCompleteTime(rs.getTime("actual_complete_time"));
        return cw;
    }

}
