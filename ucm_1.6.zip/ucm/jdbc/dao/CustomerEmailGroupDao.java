package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerEmailGroup;
import indi.ucm.jdbc.mapper.CustomerEmailGroupMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerEmailGroupDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_CUSTOMER_EMAIL_GROUP_POSTFIX = " (email_group_ID, email_group_name, email_group_description) VALUES (?, ?, ?)";
    private final static String SQL_SELECT_CUSTOMER_EMAIL_GROUP_PREFIX = "SELECT * FROM customer_email_group_";

    /**
     * create customer account
     * 
     * @param CustomerEmailGroup
     */
    public void createCustomerEmailGroup(final CustomerEmailGroup CustomerEmailGroup, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_email_group_" + masterUserId + CustomerEmailGroupDao.SQL_INSERT_CUSTOMER_EMAIL_GROUP_POSTFIX,
            CustomerEmailGroup.getEmailGroupId(), CustomerEmailGroup.getEmailGroupName(),
            CustomerEmailGroup.getEmailGroupDescription());
    }

    public List<CustomerEmailGroup> getCustomerEmailGroups(final int masterUserId) {
        List<CustomerEmailGroup> cegs = this.getJdbcTemplate().query(
            CustomerEmailGroupDao.SQL_SELECT_CUSTOMER_EMAIL_GROUP_PREFIX + masterUserId, new Object[] {},
            new CustomerEmailGroupMapper());

        return cegs;
    }

    /**
     * create customer_email_group[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`email_group_ID` tinyint NOT NULL,");
        sb.append("`email_group_name` varchar(100) NOT NULL,");
        sb.append("`email_group_description` varchar(500) NOT NULL,");
        sb.append("PRIMARY KEY (`email_group_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        insertEmailGroup(tableName);
    }


    private void insertEmailGroup(String tableName) {
    	String sql = "insert into "+tableName+" (email_group_ID, email_group_name,email_group_description) VALUES (1, 'Email group1',''),(2, 'Email group2',''),(3, 'Email group3','')";
        this.getJdbcTemplate().update(sql);
    }
}
