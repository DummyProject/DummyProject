package indi.ucm.jdbc.entry;

//Info of account status for master user
public class MasterUserAccountStatus {
	private int accountStatusId;
	private String accountStatus;
	
	public int getAccountStatusId() {
		return accountStatusId;
	}
	public void setAccountStatusId(int accountStatusId) {
		this.accountStatusId = accountStatusId;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
}
