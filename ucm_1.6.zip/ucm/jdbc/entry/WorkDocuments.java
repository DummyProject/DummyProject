package indi.ucm.jdbc.entry;

import java.sql.Timestamp;

// Info of work documents
public class WorkDocuments {
    private long workDocumentsId;
    private String fileName;
    private String fileStoragePath;
    private String description;
    private Timestamp firstUploadDateTime;
    private long uploadUser;
    private int shareWithClient;
    private Timestamp modifyDateTime;
    private Timestamp deleteDateTime;

    /**
     * @return the workDocumentsId
     */
    public long getWorkDocumentsId() {
        return this.workDocumentsId;
    }

    /**
     * @param workDocumentsId
     *            the workDocumentsId to set
     */
    public void setWorkDocumentsId(final long workDocumentsId) {
        this.workDocumentsId = workDocumentsId;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return this.fileName;
    }

    /**
     * @param fileName
     *            the fileName to set
     */
    public void setFileName(final String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the fileStoragePath
     */
    public String getFileStoragePath() {
        return this.fileStoragePath;
    }

    /**
     * @param fileStoragePath
     *            the fileStoragePath to set
     */
    public void setFileStoragePath(final String fileStoragePath) {
        this.fileStoragePath = fileStoragePath;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return this.description;
    }

    /**
     * @param description
     *            the description to set
     */
    public void setDescription(final String description) {
        this.description = description;
    }

    /**
     * @return the firstUploadDateTime
     */
    public Timestamp getFirstUploadDateTime() {
        return this.firstUploadDateTime;
    }

    /**
     * @param firstUploadDateTime
     *            the firstUploadDateTime to set
     */
    public void setFirstUploadDateTime(final Timestamp firstUploadDateTime) {
        this.firstUploadDateTime = firstUploadDateTime;
    }

    /**
     * @return the uploadUser
     */
    public long getUploadUser() {
        return this.uploadUser;
    }

    /**
     * @param uploadUser
     *            the uploadUser to set
     */
    public void setUploadUser(final long uploadUser) {
        this.uploadUser = uploadUser;
    }

    /**
     * @return the shareWithClient
     */
    public int getShareWithClient() {
        return this.shareWithClient;
    }

    /**
     * @param shareWithClient
     *            the shareWithClient to set
     */
    public void setShareWithClient(final int shareWithClient) {
        this.shareWithClient = shareWithClient;
    }

    /**
     * @return the modifyDateTime
     */
    public Timestamp getModifyDateTime() {
        return this.modifyDateTime;
    }

    /**
     * @param modifyDateTime
     *            the modifyDateTime to set
     */
    public void setModifyDateTime(final Timestamp modifyDateTime) {
        this.modifyDateTime = modifyDateTime;
    }

    /**
     * @return the deleteDateTime
     */
    public Timestamp getDeleteDateTime() {
        return this.deleteDateTime;
    }

    /**
     * @param deleteDateTime
     *            the deleteDateTime to set
     */
    public void setDeleteDateTime(final Timestamp deleteDateTime) {
        this.deleteDateTime = deleteDateTime;
    }
}
