package indi.ucm.jdbc.entry;

// Info of customer email group
public class CustomerEmailGroup {
    private int emailGroupId;
    private String emailGroupName;
    private String emailGroupDescription;

    /**
     * @return the emailGroupId
     */
    public int getEmailGroupId() {
        return this.emailGroupId;
    }

    /**
     * @param emailGroupId
     *            the emailGroupId to set
     */
    public void setEmailGroupId(final int emailGroupId) {
        this.emailGroupId = emailGroupId;
    }

    /**
     * @return the emailGroupName
     */
    public String getEmailGroupName() {
        return this.emailGroupName;
    }

    /**
     * @param emailGroupName
     *            the emailGroupName to set
     */
    public void setEmailGroupName(final String emailGroupName) {
        this.emailGroupName = emailGroupName;
    }

    /**
     * @return the emailGroupDescription
     */
    public String getEmailGroupDescription() {
        return this.emailGroupDescription;
    }

    /**
     * @param emailGroupDescription
     *            the emailGroupDescription to set
     */
    public void setEmailGroupDescription(final String emailGroupDescription) {
        this.emailGroupDescription = emailGroupDescription;
    }
}
