package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.MasterUserBusiness;
import indi.ucm.jdbc.mapper.MasterUserBusinessMapper;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class MasterUserBusinessDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_ONE_MASTER_USER_BUSINESS_POSTFIX = " (master_user_business_ID, business_name, business_type_ID, business_time_zone_ID, business_email, business_phone_number, business_fax_number, business_address_street, business_address_room_number, business_address_city, business_address_state_province, business_addresss_country_ID, business_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private final static String SQL_SELECT_ONE_MASTER_USER_BUSINESS_POSTFIX = " where master_user_business_ID = ?";

    public MasterUserBusiness getMasterUserBusiness(final int masterUserrBusinessId, final int masterUserId) {
        try {
            MasterUserBusiness mub = this.getJdbcTemplate().queryForObject(
                "SELECT * FROM master_user_business_" + masterUserId
                    + MasterUserBusinessDao.SQL_SELECT_ONE_MASTER_USER_BUSINESS_POSTFIX, new Object[] {masterUserrBusinessId},
                new MasterUserBusinessMapper());
            return mub;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public void createMasterUserBusiness(final MasterUserBusiness masterUserBusiness, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO master_user_business_" + masterUserId + MasterUserBusinessDao.SQL_INSERT_ONE_MASTER_USER_BUSINESS_POSTFIX,
            masterUserBusiness.getMasterUserBusinessId(), masterUserBusiness.getBusinessName(),
            masterUserBusiness.getBusinessTypeId(), masterUserBusiness.getBusinessTimeZoneId(),
            masterUserBusiness.getBusinessEMail(), masterUserBusiness.getBusinessPhoneNumber(),
            masterUserBusiness.getBusineseFaxNumber(), masterUserBusiness.getBusinessAddressStreet(),
            masterUserBusiness.getBusinessRoomNumber(), masterUserBusiness.getBusinessAddressCity(),
            masterUserBusiness.getBusinessAddressStateProvince(), masterUserBusiness.getBusinessCountryId(),
            masterUserBusiness.getBusinessDescription());
    }

    /**
     * create master_user_business_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`master_user_business_ID` int NOT NULL,");
        sb.append("`business_name` varchar(200)  NOT NULL,");
        sb.append("`business_type_ID` smallint  NOT NULL,");
        sb.append("`business_time_zone_ID` tinyint  NOT NULL,");
        sb.append("`business_email` varchar(254)  NOT NULL,");
        sb.append("`business_phone_number` varchar(50)  NOT NULL,");
        sb.append("`business_fax_number` varchar(50),");
        sb.append("`business_address_street` varchar(100)  NOT NULL,");
        sb.append("`business_address_room_number` varchar(100),");
        sb.append("`business_address_city` varchar(100)  NOT NULL,");
        sb.append("`business_address_state_province` varchar(100),");
        sb.append("`business_addresss_country_ID` tinyint  NOT NULL,");
        sb.append("`business_description` varchar(1000)  NOT NULL,");
        sb.append("PRIMARY KEY (`master_user_business_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
