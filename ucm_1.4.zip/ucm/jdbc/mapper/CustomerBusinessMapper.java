package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerBusiness;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerBusinessMapper implements RowMapper<CustomerBusiness> {

    @Override
    public CustomerBusiness mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerBusiness mb = new CustomerBusiness();
        mb.setCustomerBusinessId(rs.getLong("master_user_Business_ID"));
        mb.setCustomerId(rs.getLong(""));
        mb.setBusinessName(rs.getString("Business_name"));
        mb.setBusinessType(rs.getInt("Business_type_ID"));
        mb.setBusinessTimeZone(rs.getShort("Business_time_zone_ID"));
        mb.setPhoneNumber(rs.getString("Business_phone_number"));
        mb.setBusinessFaxNumber(rs.getString("Business_fax_number"));
        mb.setBusinessAddressStreet(rs.getString("Business_address_street"));
        mb.setBusinessAddressRoomNumber(rs.getString("Business_address_room_number"));
        mb.setBusinessAddressCity(rs.getString("Business_address_city"));
        mb.setBusinessAddressStateProvince(rs.getString("Business_address_state_province"));
        mb.setBusinessAddressCountry(rs.getInt("Business_addresss_country_ID"));
        mb.setBusinessDescription(rs.getString("Business_description"));
        return mb;
    }

}
