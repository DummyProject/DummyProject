package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.MasterUserBusiness;

import org.springframework.jdbc.core.RowMapper;

public class MasterUserBusinessMapper implements RowMapper<MasterUserBusiness>{

	@Override
	public MasterUserBusiness mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		MasterUserBusiness mub = new MasterUserBusiness();
		mub.setMasterUserBusinessId(rs.getLong("master_user_business_ID"));
		mub.setBusinessName(rs.getString("business_name"));
		mub.setBusinessTypeId(rs.getInt("business_type_ID"));
		mub.setBusinessTimeZoneId(rs.getShort("business_time_zone_ID"));
		mub.setBusinessEMail(rs.getString("business_email"));
		mub.setBusinessPhoneNumber(rs.getString("business_phone_number"));
		mub.setBusineseFaxNumber(rs.getString("business_fax_number"));
		mub.setBusinessAddressStreet(rs.getString("business_address_street"));
		mub.setBusinessRoomNumber(rs.getString("business_address_room_number"));
		mub.setBusinessAddressCity(rs.getString("business_address_city"));
		mub.setBusinessAddressStateProvince(rs.getString("business_address_state_province"));
		mub.setBusinessCountryId(rs.getInt("business_addresss_country_ID"));
		mub.setBusinessDescription(rs.getString("business_description"));
		return mub;
	}

}
