package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerEmailGroup;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerEmailGroupMapper implements RowMapper<CustomerEmailGroup> {

    @Override
    public CustomerEmailGroup mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerEmailGroup ceg = new CustomerEmailGroup();
        ceg.setEmailGroupId(rs.getInt("email_group_ID"));
        ceg.setEmailGroupName(rs.getString("email_group_ID"));
        ceg.setEmailGroupDescription(rs.getString("email_group_description"));
        return ceg;
    }

}
