package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.MasterUserServicePlan;

import org.springframework.jdbc.core.RowMapper;

public class MasterUserServicePlanMapper implements RowMapper<MasterUserServicePlan>{

	@Override
	public MasterUserServicePlan mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		MasterUserServicePlan musp = new MasterUserServicePlan();
		musp.setServicePlanId(rs.getInt("service_plan_ID"));
		musp.setServicePlan(rs.getString("service_plan"));
		return musp;
	}

}
