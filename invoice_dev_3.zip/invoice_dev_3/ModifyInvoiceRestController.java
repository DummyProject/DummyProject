package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerBusinessDao;
import indi.ucm.jdbc.dao.CustomerInvoiceStatusDao;
import indi.ucm.jdbc.dao.CustomerWorkDao;
import indi.ucm.jdbc.dao.CustomerWorkInvoiceDao;
import indi.ucm.jdbc.dao.CustomerWorkInvoiceMappingDao;
import indi.ucm.jdbc.dao.CustomerWorkStatusDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.dao.WorkTimeDurationDao;
import indi.ucm.jdbc.entry.BillingCurrency;
import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.entry.CustomerBusiness;
import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.CustomerWorkInvoice;
import indi.ucm.jdbc.entry.InvoiceDetail;
import indi.ucm.jdbc.entry.WorkInfoForInvoice;
import indi.ucm.security.common.GenerateCurrencySymbolHelper;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ModifyInvoiceRestController {
    @Autowired
    MasterUserListDao masterUserListDao;
    @Autowired
    StaffUserDao staffUserDao;
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    CustomerAccountDao customerAccountDao;
    @Autowired
    CustomerWorkInvoiceDao customerWorkInvoiceDao;
    @Autowired
    CustomerWorkInvoiceMappingDao customerWorkInvoiceMappingDao;
    @Autowired
    CustomerWorkDao customerWorkDao;
    @Autowired
    CustomerInvoiceStatusDao customerInvoiceStatusDao;
    @Autowired
    CustomerWorkStatusDao customerWorkStatusDao;
    @Autowired
    CustomerBusinessDao customerBusinessDao;
    @Autowired
    WorkTimeDurationDao workTimeDurationDao;

    // -------------------Retrieve invoices---------------
    @RequestMapping(value = "/invoices/{userName}/{businessId}/{clientId}", method = RequestMethod.GET)
    public ResponseEntity<List> getInvoices(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("clientId") final String clientId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);

        List<CustomerWorkInvoice> cwis = this.customerWorkInvoiceDao.getInvoiceByCustomerId(Integer.parseInt(clientId),
            masterUserId);

        return new ResponseEntity<List>(cwis, HttpStatus.OK);
    }

    // -------------------Retrieve a invoice---------------
    @RequestMapping(value = "/getInvoice/{userName}/{businessId}/{invoiceId}", method = RequestMethod.GET)
    public ResponseEntity<InvoiceDetail> getInvoice(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("invoiceId") final long invoiceId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);

        InvoiceDetail id = new InvoiceDetail();
        CustomerWorkInvoice cwi = this.customerWorkInvoiceDao.getInvoiceByID(invoiceId, masterUserId);
        BeanUtils.copyProperties(cwi, id);

        List<WorkInfoForInvoice> addedWorksList = getAddedWorks(masterUserId, invoiceId);
        id.setAddedWorkList(addedWorksList);

        return new ResponseEntity<InvoiceDetail>(id, HttpStatus.OK);
    }

    /**
     * get the works that is added to specific invoice
     * 
     * @param masterUserId
     * @param businessId
     * @param businessId2
     * @param invoiceId
     * @param clientId
     * @return
     */
    private List<WorkInfoForInvoice> getAddedWorks(final int masterUserId, final long invoiceId) {
        List<WorkInfoForInvoice> workInfoForInvoices = new ArrayList<WorkInfoForInvoice>();

        List<Long> workIdList = this.customerWorkInvoiceMappingDao.getCustomerWorkIdsByInvoiceId(invoiceId, masterUserId);
        if (workIdList != null) {
            List<CustomerWork> customerWorks = this.customerWorkDao.getWorkListByIdList(masterUserId, workIdList);

            if (customerWorks != null) {
                for (int i = 0; i < customerWorks.size(); i++) {

                    int workStatusID = customerWorks.get(i).getWorkStatus();
                    String workStatus = this.customerWorkStatusDao.getStatusByID(workStatusID, masterUserId);

                    String client = "";
                    CustomerAccount customerAccount = this.customerAccountDao.getCustomerAccount(customerWorks.get(i)
                        .getCustomerId(), masterUserId);
                    if (customerAccount != null) {
                        if (customerAccount.getCustomerAccountType() == 1) {
                            client = customerAccount.getFirstName() + " " + customerAccount.getLastName();
                        } else {
                            CustomerBusiness customerBusiness = this.customerBusinessDao.getCustomerBusinessByBusinessId(
                                customerAccount.getCustomerBusinessId(), masterUserId);
                            client = customerBusiness.getBusinessName();
                        }
                    }


                    BillingCurrency bc = this.masterUserListDao.getBillingCurrency(1);
                    String formalBillingRate = GenerateCurrencySymbolHelper.generateCurrencySymbol(
                        String.valueOf(customerWorks.get(i).getWorkBillingRate()), bc);
                    int workTimeDurationID = customerWorks.get(i).getWorkTimeDuration();
                    String workTimeDuration = this.workTimeDurationDao.getworkTimeDurationByID(workTimeDurationID, masterUserId)
                        .getWorkTimeDuration();
                    double totalAmount = (double) customerWorks.get(i).getWorkBillingRate()
                        / 60
                        * this.workTimeDurationDao.getworkTimeDurationByID(workTimeDurationID, masterUserId)
                            .getWorkTimeDurationMinutes();
                    String formalSubTotal = GenerateCurrencySymbolHelper.generateCurrencySymbol(String.valueOf(totalAmount), bc);

                    WorkInfoForInvoice workInfoForInvoice = new WorkInfoForInvoice();
                    workInfoForInvoice.setCustomerWorkId(customerWorks.get(i).getCustomerWorkId());
                    workInfoForInvoice.setWorkName(customerWorks.get(i).getWorkName());
                    workInfoForInvoice.setCustomerId(customerWorks.get(i).getCustomerId());
                    workInfoForInvoice.setClient(client);
                    workInfoForInvoice.setWorkStatus(workStatus);
                    workInfoForInvoice.setScheduleStartDate(customerWorks.get(i).getScheduleStartDate());
                    workInfoForInvoice.setScheduleStartTime(customerWorks.get(i).getScheduleStartTime());
                    workInfoForInvoice.setWorkTimeDuration(workTimeDuration);
                    workInfoForInvoice.setWorkDescription(customerWorks.get(i).getWorkDescription());
                    workInfoForInvoice.setFormalWorkBillingRate(formalBillingRate);
                    workInfoForInvoice.setSubTotal(totalAmount);
                    workInfoForInvoice.setFormalSubTotal(formalSubTotal);

                    workInfoForInvoices.add(workInfoForInvoice);
                }
            }
        }
        return workInfoForInvoices;
    }

    // -------------------Modify invoices---------------
    @RequestMapping(value = "/modifyInvoice", method = RequestMethod.POST)
    public ResponseEntity<String> modifyInvoice(final HttpServletRequest request) {
        String userName = request.getParameter("userName");
        String businessId = request.getParameter("businessId");
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);
        int invoiceId = Integer.parseInt(request.getParameter("invoiceId"));

        try {
            String invoiceJsonData = request.getParameter("invoiceJsonData");
            Type listType = new TypeToken<ArrayList<Long>>() {}.getType();
            Gson gson = new Gson();
            List<Long> workIdsFromRequest = (List<Long>) gson.fromJson(invoiceJsonData, listType);

            // modify mapping relationship
            modifyInvoiceMapping(masterUserId, invoiceId, workIdsFromRequest);

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>("Modify new invoices fail", HttpStatus.OK);
        }
        return new ResponseEntity<String>("Modify new invoices Successfully", HttpStatus.OK);
    }

    /**
     * modify mapping relationship of the specific invoice
     * 
     * @param masterUserId
     * @param invoiceId
     * @param invoiceInfoList
     */
    private void modifyInvoiceMapping(final int masterUserId, final int invoiceId, final List<Long> workIdsFromRequest) {
        List<Long> workIdsFromDB = this.customerWorkInvoiceMappingDao.getCustomerWorkIdsByInvoiceId(invoiceId, masterUserId);

        // create tmp list for processing
        List<Long> oldMapping = new ArrayList();
        List<Long> newMapping = new ArrayList();
        oldMapping.addAll(workIdsFromDB);
        newMapping.addAll(workIdsFromRequest);

        // search out workIds which will be removed
        if (oldMapping.removeAll(workIdsFromRequest)) {
            removeOldMapping(masterUserId, oldMapping);

            newMapping.removeAll(workIdsFromDB);
            addNewMapping(invoiceId, masterUserId, newMapping);
        } else {
            // this step means all workIds are new, then delete all old mapping
            // and add new mapping directly
            removeOldMapping(masterUserId, workIdsFromDB);
            addNewMapping(invoiceId, masterUserId, workIdsFromRequest);
        }
    }

    // -------------------Delete invoice---------------
    @RequestMapping(value = "/deleteInvoice/{userName}/{businessId}/{invoiceId}", method = RequestMethod.GET)
    public ResponseEntity<String> deleteInvoice(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("invoiceId") final long invoiceId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);

        // 1. mark all works which to be removed in invoice as not invoiced
        List<Long> cwims = this.customerWorkInvoiceMappingDao.getCustomerWorkIdsByInvoiceId(invoiceId, masterUserId);
        for (int i = 0; i < cwims.size(); i++) {
            long workId = (long) cwims.get(i);
            this.customerWorkDao.markAsNotInvoiced(workId, masterUserId);
        }

        // 2. delete all mapping with specific invoice
        this.customerWorkInvoiceMappingDao.deleteCustomerAccountInvoiceMappingByInvoiceId(invoiceId, masterUserId);

        return new ResponseEntity<String>("Invoice deleted", HttpStatus.OK);
    }

    /**
     * add new mapping of workId and invoiceId
     * 
     * @param masterUserId
     * @param invoiceId
     * 
     * @param newWorkIds
     */
    private void addNewMapping(final int invoiceId, final int masterUserId, final List<Long> newWorkIds) {
        for (int i = 0; i < newWorkIds.size(); i++) {
            long workId = (long) newWorkIds.get(i);
            this.customerWorkInvoiceMappingDao.createCustomerAccountInvoiceMapping(invoiceId, workId, masterUserId);
            this.customerWorkDao.markAsInvoiced(workId, masterUserId);
        }

    }

    /**
     * remove old mapping of workId and invoiceId
     * 
     * @param masterUserId
     * 
     * @param workIdsToBeRemove
     */
    private void removeOldMapping(final int masterUserId, final List<Long> workIdsToBeRemove) {
        for (int i = 0; i < workIdsToBeRemove.size(); i++) {
            long workId = (long) workIdsToBeRemove.get(i);
            this.customerWorkInvoiceMappingDao.deleteCustomerAccountInvoiceMappingByWorkId(workId, masterUserId);
            this.customerWorkDao.markAsNotInvoiced(workId, masterUserId);
        }
    }
}
