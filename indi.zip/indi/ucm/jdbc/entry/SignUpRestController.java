/*
 * COPYRIGHT. HSBC HOLDINGS PLC 2017. ALL RIGHTS RESERVED.
 * 
 * This software is only to be used for the purpose for which it has been
 * provided. No part of it is to be reproduced, disassembled, transmitted,
 * stored in a retrieval system nor translated in any human or computer
 * language in any way or for any other purposes whatsoever without the prior
 * written consent of HSBC Holdings plc.
 */
package indi.ucm.jdbc.entry;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;

public class SignUpRestController {

    public String SignUp(final HttpServletRequest request) {
        // store data from request
        storeParameters(request);

        return null;
    }

    /**
     * retrieve data from request
     * 
     * @param request
     */
    private void storeParameters(final HttpServletRequest request) {
        // 1.store basic info for master user
        int masterUserId = updateMasterUserList(request);

        // 2.store info of master user from request
        stroeMasterUserInfo(request, masterUserId);

        // 3.store info of master user business from request
        storeMasterUserBusinessInfo(request, masterUserId);
    }

    /**
     * store basic info for master user
     * 
     * @param request
     * @return
     * 
     */
    private int updateMasterUserList(final HttpServletRequest request) {
        // 1.generate master user ID
        int masterUserId = generateMasterUserId();

        return masterUserId;
    }

    /**
     * generate master user ID
     * 
     * @return
     */
    private int generateMasterUserId() {
        // generate a 8 digit number as Master User ID
        int masterUserId = 0;
        boolean isUnique = false;
        while (!isUnique) {
            masterUserId = generateRandomNumber(8);
            isUnique = isUniqueId(masterUserId);
        }
        return masterUserId;
    }

    /**
     * verify whether the master user ID is unique
     * 
     * @param masterUserId
     * @return
     */
    private boolean isUniqueId(final int masterUserId) {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * generate certain digit random number
     * 
     * @param i
     * @return
     */
    private int generateRandomNumber(final int digit) {
        StringBuilder str = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < digit; i++) {
            str.append(random.nextInt(10));
        }
        int num = Integer.parseInt(str.toString());
        return num;
    }

    /**
     * store info of master user from request
     * 
     * @param request
     * @param tableName
     */
    private void storeMasterUserBusinessInfo(final HttpServletRequest request, final int masterUserId) {

    }

    /**
     * store info of master user business from request
     * 
     * @param request
     * @param tableName
     */
    private void stroeMasterUserInfo(final HttpServletRequest request, final int masterUserId) {
        // TODO Auto-generated method stub

    }

}
