package indi.ucm.jdbc.entry;

// Info of customer work status
public class CustomerWorkStatus {
    private int workStatusId;
    private String workStatusName;

    /**
     * @return the workStatusId
     */
    public int getWorkStatusId() {
        return this.workStatusId;
    }

    /**
     * @param workStatusId
     *            the workStatusId to set
     */
    public void setWorkStatusId(final int workStatusId) {
        this.workStatusId = workStatusId;
    }

    /**
     * @return the workStatusName
     */
    public String getWorkStatusName() {
        return this.workStatusName;
    }

    /**
     * @param workStatusName
     *            the workStatusName to set
     */
    public void setWorkStatusName(final String workStatusName) {
        this.workStatusName = workStatusName;
    }
}
