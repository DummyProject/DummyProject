package indi.ucm.jdbc.entry;

// Info of Buiness department
public class BusinessDepartment {
    private int businessDepartmentId;
    private String businessDepartmentName;

    /**
     * @return the businessDepartmentId
     */
    public int getBusinessDepartmentId() {
        return this.businessDepartmentId;
    }

    /**
     * @param businessDepartmentId
     *            the businessDepartmentId to set
     */
    public void setBusinessDepartmentId(final int businessDepartmentId) {
        this.businessDepartmentId = businessDepartmentId;
    }

    /**
     * @return the businessDepartmentName
     */
    public String getBusinessDepartmentName() {
        return this.businessDepartmentName;
    }

    /**
     * @param businessDepartmentName
     *            the businessDepartmentName to set
     */
    public void setBusinessDepartmentName(final String businessDepartmentName) {
        this.businessDepartmentName = businessDepartmentName;
    }

}
