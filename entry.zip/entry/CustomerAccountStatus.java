package indi.ucm.jdbc.entry;

// Info of customer account status
public class CustomerAccountStatus {
    private int customerAccountStatusId;
    private String accountStatusName;

    /**
     * @return the customerAccountStatusId
     */
    public int getCustomerAccountStatusId() {
        return this.customerAccountStatusId;
    }

    /**
     * @param customerAccountStatusId
     *            the customerAccountStatusId to set
     */
    public void setCustomerAccountStatusId(final int customerAccountStatusId) {
        this.customerAccountStatusId = customerAccountStatusId;
    }

    /**
     * @return the accountStatusName
     */
    public String getAccountStatusName() {
        return this.accountStatusName;
    }

    /**
     * @param accountStatusName
     *            the accountStatusName to set
     */
    public void setAccountStatusName(final String accountStatusName) {
        this.accountStatusName = accountStatusName;
    }
}
