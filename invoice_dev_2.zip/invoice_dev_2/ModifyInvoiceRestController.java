package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerWorkDao;
import indi.ucm.jdbc.dao.CustomerWorkInvoiceDao;
import indi.ucm.jdbc.dao.CustomerWorkInvoiceMappingDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.CustomerWorkInvoice;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class ModifyInvoiceRestController {
    @Autowired
    MasterUserListDao masterUserListDao;
    @Autowired
    StaffUserDao staffUserDao;
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    CustomerAccountDao customerAccountDao;
    @Autowired
    CustomerWorkInvoiceDao customerWorkInvoiceDao;
    @Autowired
    CustomerWorkInvoiceMappingDao customerWorkInvoiceMappingDao;
    @Autowired
    CustomerWorkDao customerWorkDao;

    // -------------------Retrieve invoices---------------
    @RequestMapping(value = "/invoices/{userName}/{businessId}/{clientId}", method = RequestMethod.GET)
    public ResponseEntity<List> getInvoices(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("clientId") final String clientId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);

        List<CustomerWorkInvoice> cwis = this.customerWorkInvoiceDao.getInvoiceByCustomerId(Integer.parseInt(clientId),
            masterUserId);

        return new ResponseEntity<List>(cwis, HttpStatus.OK);
    }

    // -------------------Modify invoices---------------
    @RequestMapping(value = "/modifyInvoice", method = RequestMethod.POST)
    public ResponseEntity<String> modifyInvoice(final HttpServletRequest request) {
        String userName = request.getParameter("userName");
        String businessId = request.getParameter("businessId");
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);
        int invoiceId = Integer.parseInt(request.getParameter("invoiceId"));

        try {
            String invoiceJsonData = request.getParameter("invoiceJsonData");
            Type listType = new TypeToken<ArrayList<Long>>() {}.getType();
            Gson gson = new Gson();
            List<Long> workIdsFromRequest = (List<Long>) gson.fromJson(invoiceJsonData, listType);

            // modify mapping relationship
            modifyInvoiceMapping(masterUserId, invoiceId, workIdsFromRequest);

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<String>("Modify new invoices fail", HttpStatus.OK);
        }
        return new ResponseEntity<String>("Modify new invoices Successfully", HttpStatus.OK);
    }

    /**
     * modify mapping relationship of the specific invoice
     * 
     * @param masterUserId
     * @param invoiceId
     * @param invoiceInfoList
     */
    private void modifyInvoiceMapping(final int masterUserId, final int invoiceId, final List<Long> workIdsFromRequest) {
        List<Long> workIdsFromDB = this.customerWorkInvoiceMappingDao.getCustomerWorkIdsByInvoiceId(invoiceId, masterUserId);

        // create tmp list for processing
        List<Long> oldMapping = new ArrayList();
        List<Long> newMapping = new ArrayList();
        oldMapping.addAll(workIdsFromDB);
        newMapping.addAll(workIdsFromRequest);

        // search out workIds which will be removed
        if (oldMapping.removeAll(workIdsFromRequest)) {
            removeOldMapping(masterUserId, oldMapping);

            newMapping.removeAll(workIdsFromDB);
            addNewMapping(invoiceId, masterUserId, newMapping);
        } else {
            // this step means all workIds are new, then delete all old mapping
            // and add new mapping directly
            removeOldMapping(masterUserId, workIdsFromDB);
            addNewMapping(invoiceId, masterUserId, workIdsFromRequest);
        }
    }

    // -------------------Delete invoice---------------
    @RequestMapping(value = "/deleteInvoice/{userName}/{businessId}/{invoiceId}", method = RequestMethod.GET)
    public ResponseEntity<String> deleteInvoice(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("invoiceId") final long invoiceId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);

        // 1. mark all works which to be removed in invoice as not invoiced
        List<Long> cwims = this.customerWorkInvoiceMappingDao.getCustomerWorkIdsByInvoiceId(invoiceId, masterUserId);
        for (int i = 0; i < cwims.size(); i++) {
            long workId = (long) cwims.get(i);
            this.customerWorkDao.markAsNotInvoiced(workId, masterUserId);
        }

        // 2. delete all mapping with specific invoice
        this.customerWorkInvoiceMappingDao.deleteCustomerAccountInvoiceMappingByInvoiceId(invoiceId, masterUserId);

        return new ResponseEntity<String>("Invoice deleted", HttpStatus.OK);
    }

    /**
     * add new mapping of workId and invoiceId
     * 
     * @param masterUserId
     * @param invoiceId
     * 
     * @param newWorkIds
     */
    private void addNewMapping(final int invoiceId, final int masterUserId, final List<Long> newWorkIds) {
        for (int i = 0; i < newWorkIds.size(); i++) {
            long workId = (long) newWorkIds.get(i);
            this.customerWorkInvoiceMappingDao.createCustomerAccountInvoiceMapping(invoiceId, workId, masterUserId);
            this.customerWorkDao.markAsInvoiced(workId, masterUserId);
        }

    }

    /**
     * remove old mapping of workId and invoiceId
     * 
     * @param masterUserId
     * 
     * @param workIdsToBeRemove
     */
    private void removeOldMapping(final int masterUserId, final List<Long> workIdsToBeRemove) {
        for (int i = 0; i < workIdsToBeRemove.size(); i++) {
            long workId = (long) workIdsToBeRemove.get(i);
            this.customerWorkInvoiceMappingDao.deleteCustomerAccountInvoiceMappingByWorkId(workId, masterUserId);
            this.customerWorkDao.markAsNotInvoiced(workId, masterUserId);
        }
    }
}
