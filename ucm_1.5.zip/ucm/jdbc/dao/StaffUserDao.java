package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.StaffUser;
import indi.ucm.jdbc.entry.StaffUserBaseInfo;
import indi.ucm.jdbc.mapper.StaffUserBaseInfoMapper;
import indi.ucm.jdbc.mapper.StaffUserMapper;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class StaffUserDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_ONE_STAFF_USER_POSTFIX = " (staff_user_ID, master_user_business_ID, username, hashed_password, security_question, security_question_answer, first_name, last_name, email_address, mobile_phone, other_phone, enable_2_factor_authentication_login, send_passcode_to_device_ID, job_title, business_department_ID, work_time_zone, work_email, office_phone, office_address_street, office_address_room_number, office_address_city, office_address_state_province, office_addresss_country, user_note, created_date_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private final static String SQL_SELECT_ONE_STAFF_USER_POSTFIX = " where staff_user_ID = ?";
    private final static String SQL_SELECT_STAFF_USER_BASE_INFO_PREFIX = "SELECT staff_user_ID, username FROM staff_user_";

    public StaffUser getStaffUser(final int StaffUserId, final int masterUserId) {
        try {
            StaffUser su = this.getJdbcTemplate().queryForObject(
                "SELECT * FROM staff_user_" + masterUserId + StaffUserDao.SQL_SELECT_ONE_STAFF_USER_POSTFIX,
                new Object[] {StaffUserId}, new StaffUserMapper());
            return su;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public List<StaffUserBaseInfo> getStaffUsers(final int masterUserId) {
        List<StaffUserBaseInfo> subis = this.getJdbcTemplate().query(
            StaffUserDao.SQL_SELECT_STAFF_USER_BASE_INFO_PREFIX + masterUserId, new Object[] {}, new StaffUserBaseInfoMapper());

        return subis;
    }

    /**
     * create Staff user
     * 
     * @param StaffUser
     */
    public void createStaffUser(final StaffUser StaffUser, final int masterUserId) {
        this.getJdbcTemplate().update("INSERT INTO staff_user_" + masterUserId + StaffUserDao.SQL_INSERT_ONE_STAFF_USER_POSTFIX,
            StaffUser.getStaffUserId(), StaffUser.getMasterUserBusinessId(), StaffUser.getUsername(),
            StaffUser.getHashedPassword(), StaffUser.getSecurityQuestion(), StaffUser.getSecurityQuestionAnswer(),
            StaffUser.getFirstName(), StaffUser.getLastName(), StaffUser.geteMailAddress(), StaffUser.getMobilePhone(),
            StaffUser.getOtherPhone(), StaffUser.getEnable2FactorAuthenticationLogin(), StaffUser.getSendPasscodeToDeviceId(),
            StaffUser.getJobTitle(), StaffUser.getBusinessDepartmentId(), StaffUser.getWorkTimeZone(), StaffUser.getWorkEmail(),
            StaffUser.getOfficePhone(), StaffUser.getOfficeAddressStreet(), StaffUser.getOfficeAddressRoomNumber(),
            StaffUser.getOfficeAddressCity(), StaffUser.getOfficeAddressStateProvince(), StaffUser.getOfficeAddressCountry(),
            StaffUser.getUserNote(), StaffUser.getCreatedDateTime(), StaffUser.getEnableAccess());
    }

    /**
     * create Staff_user_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`staff_user_ID` int NOT NULL,");
        sb.append("`master_user_business_ID` int NOT NULL,");
        sb.append("`username` varchar(50)  NOT NULL,");
        sb.append("`hashed_password` varchar(100)  NOT NULL,");
        sb.append("`security_question` varchar(100)  NOT NULL,");
        sb.append("`security_question_answer` varchar(100)  NOT NULL,");
        sb.append("`first_name` varchar(100)  NOT NULL,");
        sb.append("`last_name` varchar(100)  NOT NULL,");
        sb.append("`email_address` varchar(254)  NOT NULL,");
        sb.append("`mobile_phone` varchar(50)  NOT NULL,");
        sb.append("`other_phone` varchar(50)  NOT NULL,");
        sb.append("`enable_2_factor_authentication_login` tinyint  NOT NULL,");
        sb.append("`send_passcode_to_device_ID` tinyint  NOT NULL,");
        sb.append("`job_title` varchar(100)  NOT NULL,");
        sb.append("`business_department_ID` tinyint  NOT NULL,");
        sb.append("`work_time_zone` tinyint  NOT NULL,");
        sb.append("`work_email` varchar(254)  NOT NULL,");
        sb.append("`office_phone` varchar(50)  NOT NULL,");
        sb.append("`office_address_street` varchar(100)  NOT NULL,");
        sb.append("`office_address_room_number` varchar(100)  NOT NULL,");
        sb.append("`office_address_city` varchar(100)  NOT NULL,");
        sb.append("`office_address_state_province` varchar(100)  NOT NULL,");
        sb.append("`office_addresss_country` tinyint  NOT NULL,");
        sb.append("`user_note` varchar(1000)  NOT NULL,");
        sb.append("`created_date_time` datetime  NOT NULL,");
        sb.append("`enable_access` tinyint  DEFAULT 0,");
        sb.append("PRIMARY KEY (`staff_user_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * check whether the user name is registered
     * 
     * @param userName
     */
    public boolean isUniqueUserName(final String userName, final int masterUserId) {
        try {
            StaffUser su = this.getJdbcTemplate().queryForObject(
                "SELECT * FROM staff_user_" + masterUserId + StaffUserDao.SQL_SELECT_STAFF_USER_LIST_BY_NAME_POSTFIX,
                new Object[] {userName}, new StaffUserMapper());
            return false;
        } catch (EmptyResultDataAccessException e) {
            return true;
        }
    }
}
