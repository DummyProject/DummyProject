package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerAccountType;
import indi.ucm.jdbc.mapper.CustomerAccountTypeMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerAccountTypeDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_CUSTOMER_ACCOUNT_TYPE_POSTFIX = " (customer_account_type_ID, account_type_name) VALUES (?, ?)";
    private final static String SQL_SELECT_CUSTOMER_ACCOUNT_TYPE_PREFIX = "SELECT * FROM customer_account_type_";

    /**
     * create customer account
     * 
     * @param CustomerAccountType
     */
    public void createCustomerAccountType(final CustomerAccountType CustomerAccountType, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_account_type_" + masterUserId + CustomerAccountTypeDao.SQL_INSERT_CUSTOMER_ACCOUNT_TYPE_POSTFIX,
            CustomerAccountType.getCustomerAccountTypeId(), CustomerAccountType.getAccountTypeName());
    }

    public List<CustomerAccountType> getCustomerAccountTypes(final int masterUserId) {
        List<CustomerAccountType> cats = this.getJdbcTemplate().query(
            CustomerAccountTypeDao.SQL_SELECT_CUSTOMER_ACCOUNT_TYPE_PREFIX + masterUserId, new Object[] {},
            new CustomerAccountTypeMapper());

        return cats;
    }

    /**
     * create CUSTOMER_ACCOUNT_TYPR_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_account_type_ID` tinyint NOT NULL,");
        sb.append("`account_type_name` varchar(100) NOT NULL,");
        sb.append("PRIMARY KEY (`customer_account_type_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        insertCustomerAccountType();
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    private void insertCustomerAccountType() {
        // TODO Auto-generated method stub

    }
}
