package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerNotificationPreference;
import indi.ucm.jdbc.mapper.CustomerNotificationPreferenceMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerNotificationPreferenceDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_CUSTOMER_NOTIFICATION_PREFERENCE_POSTFIX = " (notification_preference_ID, notification_preference_name) VALUES (?, ?)";
    private final static String SQL_SELECT_CUSTOMER_NOTIFICATION_PREFERENCE_PREFIX = "SELECT * FROM customer_notification_preference_";

    /**
     * create customer account
     * 
     * @param CustomerNotificationPreference
     */
    public void createCustomerNotificationPreference(final CustomerNotificationPreference CustomerNotificationPreference,
        final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_notification_preference_" + masterUserId
                + CustomerNotificationPreferenceDao.SQL_INSERT_CUSTOMER_NOTIFICATION_PREFERENCE_POSTFIX,
            CustomerNotificationPreference.getNotificationPreferenceId(),
            CustomerNotificationPreference.getNotificationPreferenceName());
    }

    public List<CustomerNotificationPreference> getCustomerNotificationPreferences(final int masterUserId) {
        List<CustomerNotificationPreference> cnps = this.getJdbcTemplate().query(
            CustomerNotificationPreferenceDao.SQL_SELECT_CUSTOMER_NOTIFICATION_PREFERENCE_PREFIX + masterUserId, new Object[] {},
            new CustomerNotificationPreferenceMapper());

        return cnps;
    }

    /**
     * create customer_notification_preference_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`notification_preference_ID` tinyint NOT NULL,");
        sb.append("`notification_preference_name` varchar(100) NOT NULL,");
        sb.append("PRIMARY KEY (`notification_preference_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        insertNotificationPreference();
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    private void insertNotificationPreference() {
        // TODO Auto-generated method stub

    }
}
