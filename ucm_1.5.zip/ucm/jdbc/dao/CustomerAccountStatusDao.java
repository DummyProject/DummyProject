package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerAccountStatus;
import indi.ucm.jdbc.mapper.CustomerAccountStatusMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerAccountStatusDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_CUSTOMER_ACCOUNT_STATUS_POSTFIX = " (customer_account_status_ID, account_status_name) VALUES (?, ?)";
    private final static String SQL_SELECT_CUSTOMER_ACCOUNT_STATUS_PREFIX = "SELECT * FROM customer_account_status_";

    /**
     * create customer account
     * 
     * @param CustomerAccountStatus
     */
    public void createCustomerAccountStatus(final CustomerAccountStatus CustomerAccountStatus, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_account_status_" + masterUserId
                + CustomerAccountStatusDao.SQL_INSERT_CUSTOMER_ACCOUNT_STATUS_POSTFIX,
            CustomerAccountStatus.getCustomerAccountStatusId(), CustomerAccountStatus.getAccountStatusName());
    }

    public List<CustomerAccountStatus> getCustomerAccountStatuss(final int masterUserId) {
        List<CustomerAccountStatus> cass = this.getJdbcTemplate().query(
            CustomerAccountStatusDao.SQL_SELECT_CUSTOMER_ACCOUNT_STATUS_PREFIX + masterUserId, new Object[] {},
            new CustomerAccountStatusMapper());

        return cass;
    }

    /**
     * create CUSTOMER_ACCOUNT_STATUS_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_account_status_ID` tinyint NOT NULL,");
        sb.append("`account_status_name` varchar(100) NOT NULL,");
        sb.append("PRIMARY KEY (`customer_account_status_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
        insertAccountStatus();
    }

    /**
     * <p>
     * <b> TODO : Insert description of the method's responsibility/role. </b>
     * </p>
     * 
     */
    private void insertAccountStatus() {
        // TODO Auto-generated method stub

    }
}
