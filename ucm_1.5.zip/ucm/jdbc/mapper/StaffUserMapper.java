package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.StaffUser;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class StaffUserMapper implements RowMapper<StaffUser>{

	@Override
	public StaffUser mapRow(ResultSet rs, int rowNum) throws SQLException {
		StaffUser su = new StaffUser();
		su.setStaffUserId(rs.getInt("staff_user_ID"));
		su.setMasterUserBusinessId(rs.getInt("master_user_business_ID"));
		su.setUsername(rs.getString("username"));
		su.setHashedPassword(rs.getString("hashed_password"));
		su.setSecurityQuestion(rs.getString("security_question"));
		su.setSecurityQuestionAnswer(rs.getString("security_question_answer"));
		su.setFirstName(rs.getString("first_name"));
		su.setLastName(rs.getString("last_name"));
		su.seteMailAddress(rs.getString("email_address"));
		su.setMobilePhone(rs.getString("mobile_phone"));
		su.setOtherPhone(rs.getString("other_phone"));
		su.setEnable2FactorAuthenticationLogin(rs.getInt("enable_2_factor_authentication_login"));
		su.setSendPasscodeToDeviceId(rs.getShort("send_passcode_to_device_ID"));
		su.setJobTitle(rs.getString("job_title"));
		su.setBusinessDepartmentId(rs.getInt("business_department_ID"));
		su.setWorkTimeZone(rs.getInt("work_time_zone"));
		su.setWorkEmail(rs.getString("work_email"));
		su.setOfficePhone(rs.getString("office_phone"));
		su.setOfficeAddressStreet(rs.getString("office_address_street"));
		su.setOfficeAddressRoomNumber(rs.getString("office_address_room_number"));
		su.setOfficeAddressCity(rs.getString("office_address_city"));
		su.setOfficeAddressStateProvince(rs.getString("office_address_state_province"));
		su.setOfficeAddressCountry(rs.getInt("office_addresss_country"));
		su.setUserNote(rs.getString("user_note"));
		su.setCreatedDateTime(rs.getTimestamp("created_date_time"));
		su.setEnableAccess(rs.getInt("enable_access"));
		return su;
	}

}
