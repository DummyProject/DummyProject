package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.PasscodeReceiveDevice;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class PasscodeReceiveDeviceMapper implements RowMapper<PasscodeReceiveDevice>{

	@Override
	public PasscodeReceiveDevice mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		PasscodeReceiveDevice prd = new PasscodeReceiveDevice();
		prd.setDeviceId(rs.getInt("device_ID"));
		prd.setDeviceName(rs.getString("device_ID"));
		return prd;
	}
	

}
