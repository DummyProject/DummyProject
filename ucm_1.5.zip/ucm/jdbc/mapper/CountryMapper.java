package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.Country;

import org.springframework.jdbc.core.RowMapper;

public class CountryMapper implements RowMapper<Country>{

	@Override
	public Country mapRow(ResultSet rs, int rowNum) throws SQLException {
		Country c = new Country();
		c.setCountryId(rs.getInt("country_ID"));
		c.setCountryCode(rs.getString("country_code"));
		c.setCountryName(rs.getString("country_name"));
		return c;
	}
	

}
