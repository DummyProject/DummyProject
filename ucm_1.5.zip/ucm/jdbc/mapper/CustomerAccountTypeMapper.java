package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerAccountType;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerAccountTypeMapper implements RowMapper<CustomerAccountType> {

    @Override
    public CustomerAccountType mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerAccountType cat = new CustomerAccountType();
        cat.setCustomerAccountTypeId(rs.getInt("customer_account_type_ID"));
        cat.setAccountTypeName(rs.getString("customer_account_type_ID"));
        return cat;
    }

}
