package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.WorkLocationType;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class WorkLocationTypeMapper implements RowMapper<WorkLocationType> {

    public WorkLocationType mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        WorkLocationType wlt = new WorkLocationType();
        wlt.setWorkLocationType(rs.getInt("work_time_duration_ID"));
        wlt.setLocationType(rs.getString("work_time_duration"));
        return wlt;
    }

}
