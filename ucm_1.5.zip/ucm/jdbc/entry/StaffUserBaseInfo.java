package indi.ucm.jdbc.entry;

/**
 * store staff user ID and staff user name
 */
public class StaffUserBaseInfo {
    private int staffUserId;
    private String staffUserName;

    /**
     * @return the staffUserId
     */
    public int getStaffUserId() {
        return this.staffUserId;
    }

    /**
     * @param staffUserId
     *            the staffUserId to set
     */
    public void setStaffUserId(final int staffUserId) {
        this.staffUserId = staffUserId;
    }

    /**
     * @return the staffUserName
     */
    public String getStaffUserName() {
        return this.staffUserName;
    }

    /**
     * @param staffUserName
     *            the staffUserName to set
     */
    public void setStaffUserName(final String staffUserName) {
        this.staffUserName = staffUserName;
    }

}
