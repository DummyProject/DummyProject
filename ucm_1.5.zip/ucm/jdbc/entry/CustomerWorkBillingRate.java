package indi.ucm.jdbc.entry;

// Info of customer work billing rate
public class CustomerWorkBillingRate {
    private int workBillingRateId;
    private int workTimeDurationId;
    private double billingRate;
    private String billingRateComment;

    /**
     * @return the workBillingRateId
     */
    public int getWorkBillingRateId() {
        return this.workBillingRateId;
    }

    /**
     * @param workBillingRateId
     *            the workBillingRateId to set
     */
    public void setWorkBillingRateId(final int workBillingRateId) {
        this.workBillingRateId = workBillingRateId;
    }

    /**
     * @return the workTimeDurationId
     */
    public int getWorkTimeDurationId() {
        return this.workTimeDurationId;
    }

    /**
     * @param workTimeDurationId
     *            the workTimeDurationId to set
     */
    public void setWorkTimeDurationId(final int workTimeDurationId) {
        this.workTimeDurationId = workTimeDurationId;
    }

    /**
     * @return the billingRate
     */
    public double getBillingRate() {
        return this.billingRate;
    }

    /**
     * @param billingRate
     *            the billingRate to set
     */
    public void setBillingRate(final double billingRate) {
        this.billingRate = billingRate;
    }

    /**
     * @return the billingRateComment
     */
    public String getBillingRateComment() {
        return this.billingRateComment;
    }

    /**
     * @param billingRateComment
     *            the billingRateComment to set
     */
    public void setBillingRateComment(final String billingRateComment) {
        this.billingRateComment = billingRateComment;
    }
}
