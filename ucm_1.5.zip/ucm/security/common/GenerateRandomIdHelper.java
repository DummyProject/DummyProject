package indi.ucm.security.common;

import java.util.Random;

public class GenerateRandomIdHelper {

	/**
     * generate certain digit random number
     * 
     * @param i
     * @return
     */
    public static int generateRandomNumber(final int digit) {
        StringBuilder str = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < digit; i++) {
            str.append(random.nextInt(10));
        }
        int num = Integer.parseInt(str.toString());
        return num;
    }
}
