package indi.ucm.jdbc.entry;

//Info of billing currrency
public class BillingCurrency {
	private int billingCurrencyId;
	private String isoCode;
	private String symbol;
	private String unicode;
	private String position;
	private String comments;
	
	public int getBillingCurrencyId() {
		return billingCurrencyId;
	}
	public void setBillingCurrencyId(int billingCurrencyId) {
		this.billingCurrencyId = billingCurrencyId;
	}
	public String getIsoCode() {
		return isoCode;
	}
	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getUnicode() {
		return unicode;
	}
	public void setUnicode(String unicode) {
		this.unicode = unicode;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
}
