package indi.ucm.jdbc.entry;

// Info of customer work invoice mapping
public class CustomerWorkInvoiceMapping {
    private long customerWorkInvoiceId;
    private long customerWorkId;

    /**
     * @return the customerWorkInvoiceId
     */
    public long getCustomerWorkInvoiceId() {
        return this.customerWorkInvoiceId;
    }

    /**
     * @param customerWorkInvoiceId
     *            the customerWorkInvoiceId to set
     */
    public void setCustomerWorkInvoiceId(final long customerWorkInvoiceId) {
        this.customerWorkInvoiceId = customerWorkInvoiceId;
    }

    /**
     * @return the customerWorkId
     */
    public long getCustomerWorkId() {
        return this.customerWorkId;
    }

    /**
     * @param customerWorkId
     *            the customerWorkId to set
     */
    public void setCustomerWorkId(final long customerWorkId) {
        this.customerWorkId = customerWorkId;
    }
}
