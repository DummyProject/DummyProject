package indi.ucm.controller.rest;

import javax.servlet.http.HttpServletRequest;

import indi.ucm.jdbc.dao.MasterUserDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class LogInRestController {
	// Service which will do all data retrieval/manipulation work
	@Autowired
	MasterUserDao masterUserDao;

	// -------------------master user login API-----------------------
	@RequestMapping(value = "/LogIn", method = RequestMethod.POST)
	public ResponseEntity<String> signUpMasterUser(HttpServletRequest request) {
		

		return new ResponseEntity<String>("Authenticated", HttpStatus.OK);
	}
}
