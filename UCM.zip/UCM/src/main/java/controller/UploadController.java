package controller;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;

import jdbc.Test;
import jdbc.TestJDBC;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@Controller
public class UploadController {
	
	@Autowired
	TestJDBC testJDBC; // Service which will do all data
						// retrieval/manipulation work

	@RequestMapping(value = "/index", method = RequestMethod.GET)
	public String index(ModelMap model) {

		Test test = testJDBC.getAdmin(1);

		model.addAttribute("message", "Hi world!--" + test.getFirstName() + " "
				+ test.getLastName());
		System.out.println(test.getFirstName());
		// model.addAttribute("pwd",admin.getPassword());
		return "index";
	}

	@RequestMapping(value = "/uploadLogo")
	@ResponseBody
	public ResponseEntity<String> upload(HttpServletRequest request, ModelMap model) {

		// ����ǰ�����ĳ�ʼ���� CommonsMutipartResolver ���ಿ�ֽ�������
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());
		// ���form���Ƿ���enctype="multipart/form-data"
		if (multipartResolver.isMultipart(request)) {
			// ��request��ɶಿ��request
			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			// ��ȡmultiRequest �����е��ļ���
			Iterator iter = multiRequest.getFileNames();

			while (iter.hasNext()) {
				// һ�α��������ļ�
				MultipartFile file = multiRequest.getFile(iter.next()
						.toString());
				if (file != null) {
					String path = "C:\\SpringUpload\\" + "1";
					File targetFile = new File(path, file.getOriginalFilename());
					if (!targetFile.exists()) {
						targetFile.mkdirs();
					}
					;

					System.out.println(path);
					// �ϴ�
					try {
						System.out.println("begin");
						file.transferTo(targetFile);
						System.out.println("end");
					} catch (IllegalStateException | IOException e) {
						System.out.println("oh");
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}

		}

		return new ResponseEntity<String>("uploaded", HttpStatus.OK);
	}

	@RequestMapping("/download")
	public ResponseEntity<byte[]> download(String filename) throws IOException {
		HttpHeaders headers = new HttpHeaders();
		String file = "D:\\SpringUpload\\" + "1\\" + filename;
		File file2 = new File(file);
		headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
		System.out.println(filename);
		String charset = new String(filename.getBytes("utf-8"), "iso-8859-1");
		headers.setContentDispositionFormData("file", charset);
		return new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file2),
				headers, HttpStatus.CREATED);
	}
}
