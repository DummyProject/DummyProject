package controller;

import java.util.List;

import jdbc.Test;
import jdbc.TestJDBC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

@RestController
public class TestController {

	@Autowired
	TestJDBC testJDBC; // Service which will do all data
						// retrieval/manipulation work

	// -------------------Retrieve All
	// Users--------------------------------------------------------

	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public ResponseEntity<List<Test>> listAllUsers() {
		List<Test> tests = testJDBC.findAllTests();

		if (tests.isEmpty()) {
			System.out.println(tests);
			return new ResponseEntity<List<Test>>(HttpStatus.NO_CONTENT);// You
																			// many
																			// decide
																			// to
																			// return
																			// HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<Test>>(tests, HttpStatus.OK);
	}


	// -------------------Retrieve Single
	// User--------------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Test> getUser(@PathVariable("id") long id) {
		System.out.println("Fetching User with id " + id);
		Test test = testJDBC.findById(id);
		if (test == null) {
			System.out.println("User with id " + id + " not found");
			return new ResponseEntity<Test>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Test>(test, HttpStatus.OK);
	}

	// -------------------Create a
	// User--------------------------------------------------------

	@RequestMapping(value = "/user", method = RequestMethod.POST)
	public ResponseEntity<String> createUser(@RequestBody Test test) {
		System.out.println("Creating User " + test.getFirstName());

		testJDBC.saveTest(test);

		return new ResponseEntity<String>("Created", HttpStatus.OK);
	}

	// ------------------- Update a User
	// --------------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.PUT)
	public ResponseEntity<String> updateUser(@PathVariable("id") long id,
			@RequestParam String firstName) {
		System.out.println("Updating User " + id);

		testJDBC.updateTest(id, firstName);
		return new ResponseEntity<String>("updated", HttpStatus.OK);
	}

	// ------------------- Delete a User
	// --------------------------------------------------------

	@RequestMapping(value = "/user/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<String> deleteUser(@PathVariable("id") long id) {
		System.out.println("Fetching & Deleting User with id " + id);

		testJDBC.deleteTestById(id);
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	}
	//
	// // ------------------- Delete All Users
	// // --------------------------------------------------------
	//
	// @RequestMapping(value = "/user/", method = RequestMethod.DELETE)
	// public ResponseEntity<User> deleteAllUsers() {
	// System.out.println("Deleting All Users");
	//
	// userService.deleteAllUsers();
	// return new ResponseEntity<User>(HttpStatus.NO_CONTENT);
	// }

}
