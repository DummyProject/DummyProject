package indi.ucm.security.common;

import indi.ucm.jdbc.entry.BillingCurrency;

public class GenerateCurrencySymbolHelper {

    public static String generateCurrencySymbol(final String data, final BillingCurrency bc) {

        String symbol = bc.getSymbol();
        String position = bc.getPosition();
        String formalBillingRate = null;

        if ("before".equals(position)) {
            formalBillingRate = symbol + data + "/hour";
        } else if ("after".equals(position)) {
            formalBillingRate = data + symbol + "/hour";
        }

        return formalBillingRate;
    }
}
