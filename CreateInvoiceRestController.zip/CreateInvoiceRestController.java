package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerBusinessDao;
import indi.ucm.jdbc.dao.CustomerInvoiceStatusDao;
import indi.ucm.jdbc.dao.CustomerWorkBillingRateDao;
import indi.ucm.jdbc.dao.CustomerWorkDao;
import indi.ucm.jdbc.dao.CustomerWorkStatusDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.SendMailRequestDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.dao.WorkLocationTypeDao;
import indi.ucm.jdbc.dao.WorkReminderNotifyTimeDao;
import indi.ucm.jdbc.dao.WorkRepeatIntervalDao;
import indi.ucm.jdbc.dao.WorkTimeDurationDao;
import indi.ucm.jdbc.entry.BillingCurrency;
import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.entry.CustomerBusiness;
import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.WorkInfoForInvoice;
import indi.ucm.security.common.GenerateCurrencySymbolHelper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateInvoiceRestController {
    @Autowired
    CustomerWorkDao customerWorkDao;
    @Autowired
    MasterUserListDao masterUserListDao;
    @Autowired
    CustomerWorkStatusDao customerWorkStatusDao;
    @Autowired
    WorkRepeatIntervalDao workRepeatIntervalDao;
    @Autowired
    WorkTimeDurationDao workTimeDurationDao;
    @Autowired
    CustomerWorkBillingRateDao customerWorkBillingRateDao;
    @Autowired
    CustomerInvoiceStatusDao customerInvoiceStatusDao;
    @Autowired
    WorkReminderNotifyTimeDao workReminderNotifyTimeDao;
    @Autowired
    WorkLocationTypeDao workLocationTypeDao;
    @Autowired
    CustomerAccountDao customerAccountDao;
    @Autowired
    StaffUserDao staffUserDao;
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    CustomerBusinessDao customerBusinessDao;
    @Autowired
    SendMailRequestDao sendMailRequestDao;

    @RequestMapping(value = "/getNotInvoicedWorks/{userName}/{businessId}/{clientId}", method = RequestMethod.GET)
    public ResponseEntity<List> getNotInvoicedWorks(@PathVariable("userName") final String userName,
        @PathVariable("businessId") final String businessId, @PathVariable("clientId") final String clientId) {
        int masterUserId = this.masterUserListDao.getMasterId(userName, businessId);
        int staffID = -1;
        if (businessId != null && businessId.length() > 1) {
            staffID = this.staffUserDao.getStaffUserByName(userName, masterUserId).getStaffUserId();
        }
        List<CustomerWork> customerWorks = this.customerWorkDao.getNotInvoicedWorks(masterUserId, staffID, clientId);

        List<WorkInfoForInvoice> workInfoForInvoices = new ArrayList<WorkInfoForInvoice>();
        for (int i = 0; i < customerWorks.size(); i++) {

            int workStatusID = customerWorks.get(i).getWorkStatus();
            String workStatus = this.customerWorkStatusDao.getStatusByID(workStatusID, masterUserId);

            String client = "";
            CustomerAccount customerAccount = this.customerAccountDao.getCustomerAccount(customerWorks.get(i).getCustomerId(),
                masterUserId);
            if (customerAccount != null) {
                if (customerAccount.getCustomerAccountType() == 1) {
                    client = customerAccount.getFirstName() + " " + customerAccount.getLastName();
                } else {
                    CustomerBusiness customerBusiness = this.customerBusinessDao.getCustomerBusinessByBusinessId(
                        customerAccount.getCustomerBusinessId(), masterUserId);
                    client = customerBusiness.getBusinessName();
                }
            }


            BillingCurrency bc = this.masterUserListDao.getBillingCurrency(1);
            String formalBillingRate = GenerateCurrencySymbolHelper.generateCurrencySymbol(
                String.valueOf(customerWorks.get(i).getWorkBillingRate()), bc);
            int workTimeDurationID = customerWorks.get(i).getWorkTimeDuration();
            String workTimeDuration = this.workTimeDurationDao.getworkTimeDurationByID(workTimeDurationID, masterUserId)
                .getWorkTimeDuration();
            double totalAmount = customerWorks.get(i).getWorkBillingRate() / 60
                * this.workTimeDurationDao.getworkTimeDurationByID(workTimeDurationID, masterUserId).getWorkTimeDurationMinutes();
            String subTotal = GenerateCurrencySymbolHelper.generateCurrencySymbol(String.valueOf(totalAmount), bc);

            WorkInfoForInvoice workInfoForInvoice = new WorkInfoForInvoice();
            workInfoForInvoice.setCustomerWorkId(customerWorks.get(i).getCustomerWorkId());
            workInfoForInvoice.setWorkName(customerWorks.get(i).getWorkName());
            workInfoForInvoice.setCustomerId(customerWorks.get(i).getCustomerId());
            workInfoForInvoice.setClient(client);
            workInfoForInvoice.setWorkStatus(workStatus);
            workInfoForInvoice.setScheduleStartDate(customerWorks.get(i).getScheduleStartDate());
            workInfoForInvoice.setScheduleStartTime(customerWorks.get(i).getScheduleStartTime());
            workInfoForInvoice.setWorkTimeDuration(workTimeDuration);
            workInfoForInvoice.setWorkDescription(customerWorks.get(i).getWorkDescription());
            workInfoForInvoice.setFormalWorkBillingRate(formalBillingRate);
            workInfoForInvoice.setTotalAmount(totalAmount);
            workInfoForInvoice.setSubTotal(subTotal);

            workInfoForInvoices.add(workInfoForInvoice);
        }

        return new ResponseEntity<List>(workInfoForInvoices, HttpStatus.OK);
    }

    /**
     * status: 0-not invoiced,1-invoiced,2-paid,3-added
     * 
     * added means this work is added in the UI without saving, this method is
     * to set added status to not invoiced
     * 
     * @param invoiceStatus
     * @return
     */
    private int processInvoiceStatus(final int invoiceStatus) {

        return invoiceStatus == 3 ? 0 : invoiceStatus;
    }
}
