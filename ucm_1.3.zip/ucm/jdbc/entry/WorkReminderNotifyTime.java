package indi.ucm.jdbc.entry;

// Info of work reminder notify time
public class WorkReminderNotifyTime {
    private int workReminderNotifyTime;
    private String reminderScheduleName;
    private int reminderScheduleMinutes;

    /**
     * @return the workReminderNotifyTime
     */
    public int getWorkReminderNotifyTime() {
        return this.workReminderNotifyTime;
    }

    /**
     * @param workReminderNotifyTime
     *            the workReminderNotifyTime to set
     */
    public void setWorkReminderNotifyTime(final int workReminderNotifyTime) {
        this.workReminderNotifyTime = workReminderNotifyTime;
    }

    /**
     * @return the reminderScheduleName
     */
    public String getReminderScheduleName() {
        return this.reminderScheduleName;
    }

    /**
     * @param reminderScheduleName
     *            the reminderScheduleName to set
     */
    public void setReminderScheduleName(final String reminderScheduleName) {
        this.reminderScheduleName = reminderScheduleName;
    }

    /**
     * @return the reminderScheduleMinutes
     */
    public int getReminderScheduleMinutes() {
        return this.reminderScheduleMinutes;
    }

    /**
     * @param reminderScheduleMinutes
     *            the reminderScheduleMinutes to set
     */
    public void setReminderScheduleMinutes(final int reminderScheduleMinutes) {
        this.reminderScheduleMinutes = reminderScheduleMinutes;
    }
}
