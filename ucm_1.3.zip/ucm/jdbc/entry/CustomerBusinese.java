package indi.ucm.jdbc.entry;

// Info of customer businese
public class CustomerBusinese {
    private long customerBusineseId;
    private long customerId;
    private String busineseName;
    private int busineseType;
    private int busineseTimeZone;
    private String businesePhoneNumber;
    private String busineseFaxNumber;
    private String busineseAddressStreet;
    private String busineseAddressRoomNumber;
    private String busineseAddressCity;
    private String busineseAddressStateProvince;
    private int busineseAddressCountry;
    private String busineseDescription;

    /**
     * @return the customerBusineseId
     */
    public long getCustomerBusineseId() {
        return this.customerBusineseId;
    }

    /**
     * @param customerBusineseId
     *            the customerBusineseId to set
     */
    public void setCustomerBusineseId(final long customerBusineseId) {
        this.customerBusineseId = customerBusineseId;
    }

    /**
     * @return the customerId
     */
    public long getCustomerId() {
        return this.customerId;
    }

    /**
     * @param customerId
     *            the customerId to set
     */
    public void setCustomerId(final long customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the busineseName
     */
    public String getBusineseName() {
        return this.busineseName;
    }

    /**
     * @param busineseName
     *            the busineseName to set
     */
    public void setBusineseName(final String busineseName) {
        this.busineseName = busineseName;
    }

    /**
     * @return the busineseType
     */
    public int getBusineseType() {
        return this.busineseType;
    }

    /**
     * @param busineseType
     *            the busineseType to set
     */
    public void setBusineseType(final int busineseType) {
        this.busineseType = busineseType;
    }

    /**
     * @return the busineseTimeZone
     */
    public int getBusineseTimeZone() {
        return this.busineseTimeZone;
    }

    /**
     * @param busineseTimeZone
     *            the busineseTimeZone to set
     */
    public void setBusineseTimeZone(final int busineseTimeZone) {
        this.busineseTimeZone = busineseTimeZone;
    }

    /**
     * @return the phoneNumber
     */
    public String getBusinesePhoneNumber() {
        return this.businesePhoneNumber;
    }

    /**
     * @param phoneNumber
     *            the phoneNumber to set
     */
    public void setBusinesePhoneNumber(final String phoneNumber) {
        this.businesePhoneNumber = phoneNumber;
    }

    /**
     * @return the busineseFaxNumber
     */
    public String getBusineseFaxNumber() {
        return this.busineseFaxNumber;
    }

    /**
     * @param busineseFaxNumber
     *            the busineseFaxNumber to set
     */
    public void setBusineseFaxNumber(final String busineseFaxNumber) {
        this.busineseFaxNumber = busineseFaxNumber;
    }

    /**
     * @return the busineseAddressStreet
     */
    public String getBusineseAddressStreet() {
        return this.busineseAddressStreet;
    }

    /**
     * @param busineseAddressStreet
     *            the busineseAddressStreet to set
     */
    public void setBusineseAddressStreet(final String busineseAddressStreet) {
        this.busineseAddressStreet = busineseAddressStreet;
    }

    /**
     * @return the busineseAddressRoomNumber
     */
    public String getBusineseAddressRoomNumber() {
        return this.busineseAddressRoomNumber;
    }

    /**
     * @param busineseAddressRoomNumber
     *            the busineseAddressRoomNumber to set
     */
    public void setBusineseAddressRoomNumber(final String busineseAddressRoomNumber) {
        this.busineseAddressRoomNumber = busineseAddressRoomNumber;
    }

    /**
     * @return the busineseAddressCity
     */
    public String getBusineseAddressCity() {
        return this.busineseAddressCity;
    }

    /**
     * @param busineseAddressCity
     *            the busineseAddressCity to set
     */
    public void setBusineseAddressCity(final String busineseAddressCity) {
        this.busineseAddressCity = busineseAddressCity;
    }

    /**
     * @return the busineseAddressStateProvince
     */
    public String getBusineseAddressStateProvince() {
        return this.busineseAddressStateProvince;
    }

    /**
     * @param busineseAddressStateProvince
     *            the busineseAddressStateProvince to set
     */
    public void setBusineseAddressStateProvince(final String busineseAddressStateProvince) {
        this.busineseAddressStateProvince = busineseAddressStateProvince;
    }

    /**
     * @return the busineseAddressCountry
     */
    public int getBusineseAddressCountry() {
        return this.busineseAddressCountry;
    }

    /**
     * @param busineseAddressCountry
     *            the busineseAddressCountry to set
     */
    public void setBusineseAddressCountry(final int busineseAddressCountry) {
        this.busineseAddressCountry = busineseAddressCountry;
    }

    /**
     * @return the busineseDescription
     */
    public String getBusineseDescription() {
        return this.busineseDescription;
    }

    /**
     * @param busineseDescription
     *            the busineseDescription to set
     */
    public void setBusineseDescription(final String busineseDescription) {
        this.busineseDescription = busineseDescription;
    }
}
