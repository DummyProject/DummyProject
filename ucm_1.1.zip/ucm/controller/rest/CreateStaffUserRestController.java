package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.MasterUserBusiness;
import indi.ucm.jdbc.entry.StaffUser;
import indi.ucm.security.common.EncryptionDecryption;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateStaffUserRestController {

	// Service which will do all data retrieval/manipulation work
    @Autowired
    MasterUserDao masterUserDao;
    @Autowired
    StaffUserDao staffUserDao;
	
 // -------------------Create a staff user-----------------------
//    @RequestMapping(value = "/CreateStaffUser", method = RequestMethod.POST)
//    public ResponseEntity<String> createStaffUser(final HttpServletRequest request) {
//        // store data from request
//    	int masterUserId = Integer.parseInt(request.getParameter("masterUserId"));
//        try {
//        	storeParameters(request);
//        } catch (Exception e) {
//            e.printStackTrace();
//            return new ResponseEntity<String>("Duplicated user name", HttpStatus.SERVICE_UNAVAILABLE);
//        }
//
//        return new ResponseEntity<String>("Create staff user Successfully", HttpStatus.OK);
//    }
//    
//    /**
//     * retrieve data from request
//     * 
//     * @param request
//     * @throws Exception
//     */
//    private void storeParameters(final HttpServletRequest request) throws Exception {
//        Boolean isUniqueUserName = this.masterUserListDao.isUniqueUserName(request.getParameter("userName"));
//        if (isUniqueUserName) {
//            // 1.store basic info for master user
//            int masterUserId = updateMasterUserList(request);
//
//            // 2.store info of master user from request
//            stroeStaffUserInfo(request, masterUserId);
//        } else {
//            throw new Exception("Duplicated user name");
//        }
//
//    }
//    
//    /**
//     * store info of staff user business from request
//     * 
//     * @param request
//     * @param tableName
//     * @throws Exception
//     */
//    private void stroeStaffUserInfo(final HttpServletRequest request, final int masterUserId) throws Exception {
//        StaffUser StaffUser = new StaffUser();
//
//        this.staffUserDao.createTable("staff_user_" + masterUserId);
//        MasterUserBusiness masterUserBusiness = new MasterUserBusiness();
//        int masterUserBusinessId = generateMasterUserBusinessId(masterUserId);
//        masterUserBusiness.setMasterUserBusinessId(masterUserBusinessId);
//        masterUserBusiness.setBusinessName(request.getParameter("businessName"));
//        masterUserBusiness.setBusinessTypeId(Integer.parseInt(request.getParameter("businessTypeId")));
//        masterUserBusiness.setBusinessTimeZoneId(Integer.parseInt(request.getParameter("businessTimeZoneId")));
//        masterUserBusiness.setBusinessEMail(request.getParameter("businessEMail"));
//        masterUserBusiness.setBusinessPhoneNumber(request.getParameter("businessPhoneNumber"));
//        masterUserBusiness.setBusineseFaxNumber(request.getParameter("busineseFaxNumber"));
//        masterUserBusiness.setBusinessAddressStreet(request.getParameter("businessAddressStreet"));
//        masterUserBusiness.setBusinessRoomNumber(request.getParameter("businessRoomNumber"));
//        masterUserBusiness.setBusinessAddressCity(request.getParameter("businessAddressCity"));
//        masterUserBusiness.setBusinessAddressStateProvince(request.getParameter("businessAddressStateProvince"));
//        masterUserBusiness.setBusinessCountryId(Integer.parseInt(request.getParameter("businessCountryId")));
//        masterUserBusiness.setBusinessDescription(request.getParameter("businessDescription"));
//
//        masterUser.setHashedPassword(EncryptionDecryption.encryptStr(request.getParameter("hashedPassword")));
//        masterUser.setSecurityQuestion(request.getParameter("securityQuestion"));
//        masterUser.setSecurityQuestionAnswer(EncryptionDecryption.encryptStr(request.getParameter("securityQuestionAnswer")));
//        masterUser.setFirstName(request.getParameter("firstName"));
//        masterUser.setLastName(request.getParameter("lastName"));
//        masterUser.seteMailAddress(request.getParameter("eMailAddress"));
//        masterUser.setPhoneNumber(request.getParameter("phoneNumber"));
//        masterUser.setOtherPhone(request.getParameter("otherPhone"));
//        masterUser.setEnable2FactorAuthenticationLogin(Integer.parseInt(request.getParameter("enable2FactorAuthenticationLogin")));
//        masterUser.setSendPasscodeToDeviceId(Integer.parseInt(request.getParameter("sendPasscodeToDeviceId")));
//        masterUser.setMasterUserBusinessId(masterUserBusinessId);
//
//        this.masterUserDao.createTable("master_user_" + masterUserId);
//        this.masterUserDao.creatMasterUser(masterUser);
//
//    }
//}
}
