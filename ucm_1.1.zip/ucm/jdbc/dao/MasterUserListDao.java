package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.BusinessType;
import indi.ucm.jdbc.entry.Country;
import indi.ucm.jdbc.entry.MasterUserList;
import indi.ucm.jdbc.entry.TimeZone;
import indi.ucm.jdbc.mapper.BusinessTypeMapper;
import indi.ucm.jdbc.mapper.CountryMapper;
import indi.ucm.jdbc.mapper.MasterUserListMapper;
import indi.ucm.jdbc.mapper.TimeZoneMapper;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class MasterUserListDao extends JdbcDaoSupport {
    private final static String SQL_SELECT_ONE_MASTER_USER_LIST = "SELECT * FROM master_user_list where master_user_ID = ?";
    private final static String SQL_INSERT_ONE_MASTER_USER_LIST = "INSERT INTO master_user_list (master_user_ID, account_service_plan, account_status, account_created_date_time, account_billing_ID, database_table_name_postfix, description, username) VALUES (?, 1, 1, ?, NULL, ?, NULL, ?)";
    private final static String SQL_SELECT_BUSINESS_TYPES = "SELECT * FROM business_type";
    private final static String SQL_SELECT_COUNRTY = "SELECT * FROM country";
    private final static String SQL_SELECT_TIMEZONE = "SELECT * FROM timezones";
    private final static String SQL_SELECT_MASTER_USER_LIST_BY_NAME = "SELECT * FROM master_user_list where username = ?";

    public MasterUserList getMasterUserList(final long masterUserId) {
        try {
            MasterUserList mul = this.getJdbcTemplate().queryForObject(MasterUserListDao.SQL_SELECT_ONE_MASTER_USER_LIST,
                new Object[] {masterUserId}, new MasterUserListMapper());
            return mul;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public MasterUserList getMasterUserListByName(final String userName) {
        try {
            MasterUserList mul = this.getJdbcTemplate().queryForObject(MasterUserListDao.SQL_SELECT_MASTER_USER_LIST_BY_NAME,
                new Object[] {userName}, new MasterUserListMapper());
            return mul;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    public void creatMasterUserList(final MasterUserList masterUserList) {
        this.getJdbcTemplate().update(MasterUserListDao.SQL_INSERT_ONE_MASTER_USER_LIST, masterUserList.getMasterUserId(),
            new Timestamp(System.currentTimeMillis()), masterUserList.getMasterUserId(), masterUserList.getUserName());
    }

    public List<BusinessType> getBusinessTypes() {
        List<BusinessType> bts = this.getJdbcTemplate().query(MasterUserListDao.SQL_SELECT_BUSINESS_TYPES, new Object[] {},
            new BusinessTypeMapper());

        return bts;
    }

    public List<Country> getCountries() {
        List<Country> cs = this.getJdbcTemplate().query(MasterUserListDao.SQL_SELECT_COUNRTY, new Object[] {}, new CountryMapper());

        return cs;
    }

    public List<TimeZone> getTimeZones() {
        List<TimeZone> tzs = this.getJdbcTemplate().query(MasterUserListDao.SQL_SELECT_TIMEZONE, new Object[] {},
            new TimeZoneMapper());

        return tzs;
    }

    /**
     * check whether the user name is registered
     * 
     * @param userName
     */
    public boolean isUniqueUserName(final String userName) {
        System.out.println(userName);
        try {
            MasterUserList mul = this.getJdbcTemplate().queryForObject(MasterUserListDao.SQL_SELECT_MASTER_USER_LIST_BY_NAME,
                new Object[] {userName}, new MasterUserListMapper());
            return false;
        } catch (EmptyResultDataAccessException e) {
            return true;
        }
    }
}
