package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.MasterUser;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class MasterUserMapper implements RowMapper<MasterUser>{

	@Override
	public MasterUser mapRow(ResultSet rs, int rowNum) throws SQLException {
		MasterUser mu = new MasterUser();
		mu.setMasterUserId(rs.getLong("master_user_ID"));
		mu.setUerName(rs.getString("username"));
		mu.setHashedPassword(rs.getString("hashed_password"));
		mu.setSecurityQuestion(rs.getString("security_question"));
		mu.setSecurityQuestionAnswer(rs.getString("security_question_answer"));
		mu.setFirstName(rs.getString("first_name"));
		mu.setLastName(rs.getString("last_name"));
		mu.seteMailAddress(rs.getString("email_address"));
		mu.setPhoneNumber(rs.getString("mobile_phone"));
		mu.setOtherPhone(rs.getString("other_phone"));
		mu.setEnable2FactorAuthenticationLogin(rs.getInt("enable_2_factor_authentication_login"));
		mu.setSendPasscodeToDeviceId(rs.getShort("send_passcode_to_device_ID"));
		mu.setMasterUserBusinessId(rs.getInt("master_user_business_ID"));
		return mu;
	}

}
