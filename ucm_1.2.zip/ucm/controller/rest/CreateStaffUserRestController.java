package indi.ucm.controller.rest;

import java.sql.Timestamp;

import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.StaffUser;
import indi.ucm.security.common.EncryptionDecryption;
import indi.ucm.security.common.GenerateRandomIdHelper;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateStaffUserRestController {

	// Service which will do all data retrieval/manipulation work
	@Autowired
	MasterUserDao masterUserDao;
	@Autowired
	StaffUserDao staffUserDao;

	// -------------------Create a staff user-----------------------
	@RequestMapping(value = "/CreateStaffUser", method = RequestMethod.POST)
	public ResponseEntity<String> createStaffUser(
			final HttpServletRequest request) {
		// store data from request
		int masterUserId = Integer.parseInt(request
				.getParameter("masterUserId"));
		try {
			storeParameters(request, masterUserId);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Duplicated user name",
					HttpStatus.SERVICE_UNAVAILABLE);
		}

		return new ResponseEntity<String>("Create staff user Successfully",
				HttpStatus.OK);
	}

	/**
	 * retrieve data from request
	 * 
	 * @param request
	 * @param masterUserId2
	 * @throws Exception
	 */
	private void storeParameters(final HttpServletRequest request,
			int masterUserId) throws Exception {
		Boolean isUniqueUserName = staffUserDao.isUniqueUserName(
				request.getParameter("userName"), masterUserId);
		if (isUniqueUserName) {
			// store info of master user from request
			stroeStaffUserInfo(request, masterUserId);
		} else {
			throw new Exception("Duplicated user name");
		}

	}

	/**
	 * generate staff user ID
	 * 
	 * @param masterUserId
	 * 
	 * @return
	 */
	private int generateStaffUserId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		int masterUserBusinessId = 0;
		boolean isUnique = false;
		while (!isUnique) {
			masterUserBusinessId = GenerateRandomIdHelper
					.generateRandomNumber(8);
			isUnique = isStaffUserUniqueId(masterUserBusinessId, masterUserId);
		}
		return masterUserBusinessId;
	}

	/**
	 * verify whether the staff user ID is unique
	 * 
	 * @param masterUserId
	 * 
	 * @param masterUserId
	 * @return
	 */
	private boolean isStaffUserUniqueId(int staffUserId, int masterUserId) {
		StaffUser staffUser = staffUserDao.getStaffUser(staffUserId,
				masterUserId);
		if (staffUser == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * store info of staff user business from request
	 * 
	 * @param request
	 * @param tableName
	 * @throws Exception
	 */
	private void stroeStaffUserInfo(final HttpServletRequest request,
			final int masterUserId) throws Exception {
		StaffUser staffUser = new StaffUser();
		int staffUserId = generateStaffUserId(masterUserId);
		staffUser.setStaffUserId(staffUserId);
		staffUser.setUsername(request.getParameter("userName"));
		staffUser.setHashedPassword(EncryptionDecryption.encryptStr(request
				.getParameter("hashedPassword")));
		staffUser.setSecurityQuestion(request.getParameter("securityQuestion"));
		staffUser.setSecurityQuestionAnswer(EncryptionDecryption
				.encryptStr(request.getParameter("securityQuestionAnswer")));
		staffUser.setFirstName(request.getParameter("firstName"));
		staffUser.setLastName(request.getParameter("lastName"));
		staffUser.seteMailAddress(request.getParameter("eMailAddress"));
		staffUser.setMobilePhone(request.getParameter("mobilePhone"));
		staffUser.setOtherPhone(request.getParameter("otherPhone"));
		staffUser.setEnable2FactorAuthenticationLogin(Integer.parseInt(request
				.getParameter("enable2FactorAuthenticationLogin")));
		staffUser.setSendPasscodeToDeviceId(Integer.parseInt(request
				.getParameter("sendPasscodeToDeviceId")));
		MasterUser masterUser = masterUserDao.getMasterUser(masterUserId);
		staffUser.setMasterUserBusinessId(masterUser.getMasterUserBusinessId());
		staffUser.setJobTitle(request.getParameter("jobTitle"));
		staffUser.setBusinessDepartmentId(Integer.parseInt(request
				.getParameter("businessDepartmentId")));
		staffUser.setWorkTimeZone(Integer.parseInt(request
				.getParameter("workTimeZone")));
		staffUser.setWorkEmail(request.getParameter("workEmail"));
		staffUser.setOfficePhone(request.getParameter("officePhone"));
		staffUser.setOfficeAddressStreet(request
				.getParameter("officeAddressStreet"));
		staffUser.setOfficeAddressRoomNumber(request
				.getParameter("officeAddressRoomNumber"));
		staffUser.setOfficeAddressCity(request
				.getParameter("officeAddressCity"));
		staffUser.setOfficeAddressStateProvince(request
				.getParameter("officeAddressStateProvince"));
		staffUser.setOfficeAddressCountry(Integer.parseInt(request
				.getParameter("officeAddressCountry")));
		staffUser.setUserNote(request.getParameter("userNote"));
		staffUser.setCreatedDateTime(new Timestamp(System.currentTimeMillis()));
		staffUser.setEnableAccess(Integer.parseInt(request
				.getParameter("enableAccess")));

		this.staffUserDao.createStaffUser(staffUser, masterUserId);

	}
}
