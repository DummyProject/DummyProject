package indi.ucm.controller.rest;

import java.sql.Timestamp;

import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.security.common.EncryptionDecryption;
import indi.ucm.security.common.GenerateRandomIdHelper;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateCustomerAccountRestController {

	// Service which will do all data retrieval/manipulation work
	@Autowired
	MasterUserDao masterUserDao;
	@Autowired
	CustomerAccountDao CustomerAccountDao;

	// -------------------Create a customer account-----------------------
	@RequestMapping(value = "/CreateCustomerAccount", method = RequestMethod.POST)
	public ResponseEntity<String> createCustomerAccount(
			final HttpServletRequest request) {
		// store data from request
		int masterUserId = Integer.parseInt(request
				.getParameter("masterUserId"));
		try {
			stroeCustomerAccountInfo(request, masterUserId);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Duplicated user name",
					HttpStatus.SERVICE_UNAVAILABLE);
		}

		return new ResponseEntity<String>("Create staff user Successfully",
				HttpStatus.OK);
	}


	/**
	 * generate customer ID
	 * 
	 * @param masterUserId
	 * 
	 * @return
	 */
	private long generateCustomerId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		long customerId = 0;
		boolean isUnique = false;
		while (!isUnique) {
			customerId = GenerateRandomIdHelper
					.generateRandomNumber(8);
			isUnique = isCustomerAccountUniqueId(customerId, masterUserId);
		}
		return customerId;
	}

	/**
	 * verify whether the staff user ID is unique
	 * 
	 * @param masterUserId
	 * 
	 * @param masterUserId
	 * @return
	 */
	private boolean isCustomerAccountUniqueId(long customerId, int masterUserId) {
		CustomerAccount CustomerAccount = CustomerAccountDao.getCustomerAccount(customerId,
				masterUserId);
		if (CustomerAccount == null) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * generate customer Business ID
	 * 
	 * @param masterUserId
	 * 
	 * @return
	 */
	private long generateCustomerBusinessId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		long customerBusinessId = 0;
		boolean isUnique = false;
		while (!isUnique) {
			customerBusinessId = GenerateRandomIdHelper
					.generateRandomNumber(8);
			isUnique = isCustomerBusinessUniqueId(customerBusinessId, masterUserId);
		}
		return customerBusinessId;
	}

	/**
	 * verify whether the staff user ID is unique
	 * 
	 * @param masterUserId
	 * 
	 * @param masterUserId
	 * @return
	 */
	private boolean isCustomerBusinessUniqueId(long customerBusinessId, int masterUserId) {
		CustomerAccount CustomerAccount = CustomerAccountDao.getCustomerAccountByBusinessId(customerBusinessId,
				masterUserId);
		if (CustomerAccount == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * store info of staff user business from request
	 * 
	 * @param request
	 * @param tableName
	 * @throws Exception
	 */
	private void stroeCustomerAccountInfo(final HttpServletRequest request,
			final int masterUserId) throws Exception {
		CustomerAccount customerAccount = new CustomerAccount();
		long customerId = generateCustomerId(masterUserId);
		long customerBusinessId = generateCustomerBusinessId(masterUserId);
		customerAccount.setCustomerId(customerId);
		customerAccount.setCustomerBusinessId(customerBusinessId);
		customerAccount.setCustomerAccountType(Integer.parseInt(request.getParameter("customerAccountType")));
		customerAccount.setCustomerAccountStatus(Integer.parseInt(request.getParameter("customerAccountStatus")));
		customerAccount.setAssignedStaffUser(Integer.parseInt(request.getParameter("assignedStaffUser")));
		customerAccount.setFirstName(request.getParameter("firstName"));
		customerAccount.setLastName(request.getParameter("lastName"));
		customerAccount.setEmailAddress(request.getParameter("emailAddress"));
		customerAccount.setMobilePhone(request.getParameter("mobilePhone"));	
		customerAccount.setMailingAddressStreet(request
				.getParameter("mailingAddressStreet"));
		customerAccount.setMailingAddressRoomNumber(request
				.getParameter("mailingAddressRoomNumber"));
		customerAccount.setMailingAddressCity(request
				.getParameter("mailingAddressCity"));
		customerAccount.setMailingAddressStateProvince(request
				.getParameter("mailingAddressStateProvince"));
		customerAccount.setMailingAddressCountry(Integer.parseInt(request
				.getParameter("mailingAddressCountry")));
		customerAccount.setBillingAddressStreet(request
				.getParameter("billingAddressStreet"));
		customerAccount.setBillingAddressRoomNumber(request
				.getParameter("billingAddressRoomNumber"));
		customerAccount.setBillingAddressCity(request
				.getParameter("billingAddressCity"));
		customerAccount.setBillingAddressStateProvince(request
				.getParameter("billingAddressStateProvince"));
		customerAccount.setBillingAddressCountry(Integer.parseInt(request
				.getParameter("billingAddressCountry")));
		customerAccount.setCustomerNote(request.getParameter("customerNote"));
		customerAccount.setEmailGroup(Integer.parseInt(request.getParameter("emailGroup")));
		customerAccount.setNotificationPreference(Integer.parseInt(request.getParameter("notificationPreference")));
		customerAccount.setEnableClientPortal(Integer.parseInt(request.getParameter("enableClientPortal")));
		customerAccount.setClientPortalUserName(request.getParameter("clientPortalUserName"));
		customerAccount.setHashedPassword(EncryptionDecryption.encryptStr(request
				.getParameter("hashedPassword")));
		customerAccount.setSecurityQuestion(request.getParameter("securityQuestion"));
		customerAccount.setSecurityQuestionAnswer(EncryptionDecryption
				.encryptStr(request.getParameter("securityQuestionAnswer")));
		customerAccount.setEnable2FactorAuthenticationLogin(Integer.parseInt(request
				.getParameter("enable2FactorAuthenticationLogin")));
		customerAccount.setSendPasscodeToDeviceId(Integer.parseInt(request
				.getParameter("sendPasscodeToDeviceId")));

		this.CustomerAccountDao.createCustomerAccount(customerAccount, masterUserId);

	}
}
