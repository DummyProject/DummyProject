package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.mapper.MasterUserMapper;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class MasterUserDao extends JdbcDaoSupport {
    private final static String SQL_INSERT_ONE_MASTER_USER_POSTFIX = " (master_user_ID, username, hashed_password, security_question, security_question_answer, first_name, last_name, email_address, mobile_phone, other_phone, enable_2_factor_authentication_login, send_passcode_to_device_ID, master_user_business_ID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private final static String SQL_SELECT_ONE_MASTER_USER_POSTFIX = " where master_user_ID = ?";

    public MasterUser getMasterUser(final int masterUserId) {
        try {
            MasterUser mu = this.getJdbcTemplate().queryForObject(
                "SELECT * FROM master_user_" + masterUserId + MasterUserDao.SQL_SELECT_ONE_MASTER_USER_POSTFIX,
                new Object[] {masterUserId}, new MasterUserMapper());
            return mu;
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * create master user
     * 
     * @param masterUser
     */
    public void creatMasterUser(final MasterUser masterUser) {
        this.getJdbcTemplate().update(
            "INSERT INTO master_user_" + masterUser.getMasterUserId() + MasterUserDao.SQL_INSERT_ONE_MASTER_USER_POSTFIX,
            masterUser.getMasterUserId(), masterUser.getUerName(), masterUser.getHashedPassword(),
            masterUser.getSecurityQuestion(), masterUser.getSecurityQuestionAnswer(), masterUser.getFirstName(),
            masterUser.getLastName(), masterUser.geteMailAddress(), masterUser.getPhoneNumber(), masterUser.getOtherPhone(),
            masterUser.getEnable2FactorAuthenticationLogin(), masterUser.getSendPasscodeToDeviceId(),
            masterUser.getMasterUserBusinessId());
    }

    /**
     * create master_user_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`master_user_ID` int NOT NULL,");
        sb.append("`username` varchar(50)  NOT NULL,");
        sb.append("`hashed_password` varchar(100)  NOT NULL,");
        sb.append("`security_question` varchar(100)  NOT NULL,");
        sb.append("`security_question_answer` varchar(100)  NOT NULL,");
        sb.append("`first_name` varchar(100)  NOT NULL,");
        sb.append("`last_name` varchar(100)  NOT NULL,");
        sb.append("`email_address` varchar(254)  NOT NULL,");
        sb.append("`mobile_phone` varchar(50)  NOT NULL,");
        sb.append("`other_phone` varchar(50)  NOT NULL,");
        sb.append("`enable_2_factor_authentication_login` tinyint  NOT NULL,");
        sb.append("`send_passcode_to_device_ID` tinyint  NOT NULL,");
        sb.append("`master_user_business_ID` int  NOT NULL,");
        sb.append("PRIMARY KEY (`master_user_ID`))");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
