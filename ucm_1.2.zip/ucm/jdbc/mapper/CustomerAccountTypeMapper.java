package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerAccount;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public enum CustomerAccountTypeMapper implements RowMapper<CustomerAccount>{
	;

	@Override
	public CustomerAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		CustomerAccount ac = new CustomerAccount();
		ac.setCustomerId(rs.getLong("customer_ID"));
		ac.setCustomerBusinessId(rs.getLong("customer_business_ID"));
		ac.setCustomerAccountType(rs.getInt("customer_account_type"));
		ac.setCustomerAccountStatus(rs.getShort("customer_account_status"));
		ac.setAssignedStaffUser(rs.getInt("assigned_staff_user"));
		ac.setFirstName(rs.getString("first_name"));
		ac.setLastName(rs.getString("last_name"));
		ac.setMailingAddressCity(rs.getString("email_address"));
		ac.setMobilePhone(rs.getString("mobile_phone"));
		ac.setMailingAddressStreet(rs.getString("mailing_address_street"));
		ac.setMailingAddressRoomNumber(rs.getString("mailing_address_room_number"));
		ac.setMailingAddressCity(rs.getString("mailing_address_city"));
		ac.setMailingAddressStateProvince(rs.getString("mailing_address_state_province"));
		ac.setMailingAddressCountry(rs.getInt("mailing_addresss_country"));
		ac.setBillingAddressStreet(rs.getString("billing_address_street"));
		ac.setBillingAddressRoomNumber(rs.getString("billing_address_room_number"));
		ac.setBillingAddressCity(rs.getString("billing_address_city"));
		ac.setBillingAddressStateProvince(rs.getString("billing_address_state_province"));
		ac.setBillingAddressCountry(rs.getInt("billing_addresss_country"));
		ac.setCustomerNote(rs.getString("customer_note"));
		ac.setEmailGroup(rs.getInt("email_group"));
		ac.setNotificationPreference(rs.getInt("notification_preference"));
		ac.setEnableClientPortal(rs.getInt("enable_client_portal"));
		ac.setClientPortalUserName(rs.getString("client_portal_username"));
		ac.setHashedPassword(rs.getString("hashed_password"));
		ac.setSecurityQuestion(rs.getString("security_question"));
		ac.setSecurityQuestionAnswer(rs.getString("security_question_answer"));
		ac.setEnable2FactorAuthenticationLogin(rs.getInt("enable_2_factor_authentication_login"));
		ac.setSendPasscodeToDeviceId(rs.getInt("send_passcode_to_device_ID"));
		return ac;
	}

}
