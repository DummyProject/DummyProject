package indi.ucm.jdbc.entry;

// Info of customer payment method
public class CustomerPaymentMethod {
    private int paymentMethodId;
    private String paymentMethod;

    /**
     * @return the paymentMethodId
     */
    public int getPaymentMethodId() {
        return this.paymentMethodId;
    }

    /**
     * @param paymentMethodId
     *            the paymentMethodId to set
     */
    public void setPaymentMethodId(final int paymentMethodId) {
        this.paymentMethodId = paymentMethodId;
    }

    /**
     * @return the paymentMethod
     */
    public String getPaymentMethod() {
        return this.paymentMethod;
    }

    /**
     * @param paymentMethod
     *            the paymentMethod to set
     */
    public void setPaymentMethod(final String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}
