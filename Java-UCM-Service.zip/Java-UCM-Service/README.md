# Java-UCM-Service

前言

这个项目是一个小型的外包项目，由于功能尚未开发完全，仅给开发人员同步进度用。


后台代码的说明（ Java ）

这个项目使用spring mvc为开发框架，tomcat作为服务器，mysql作为数据库。
