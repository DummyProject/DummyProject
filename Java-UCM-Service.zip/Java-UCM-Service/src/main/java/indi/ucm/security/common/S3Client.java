package indi.ucm.security.common;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.zip.GZIPInputStream;

import javax.imageio.ImageIO;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.Upload;

public class S3Client {
	static AmazonS3 s3;
	static TransferManager tx;
	static S3Client instance;

	private static String AWS_ACCESS_KEY = "AKIAICEJJHECNK2SMC6A";
	private static String AWS_SECRET_KEY = "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";

	static final String bucketName = "ucmbucket";

	public static S3Client getInstance() {
		if (instance == null) {
			synchronized (AmazonS3Client.class) {
				if (instance == null) {
					instance = new S3Client();
				}
			}
		}
		return instance;
	}

	private AmazonS3 getAmazonS3() throws Exception {
		if (s3 == null) {
			init_with_key();
		}
		return s3;
	}

	private TransferManager getTransferManager() throws Exception {
		if (tx == null) {
			init_with_key();
		}
		return tx;
	}

	private static void init_with_key() throws Exception {
		AWSCredentials credentials = null;
		credentials = new BasicAWSCredentials(AWS_ACCESS_KEY, AWS_SECRET_KEY);
		s3 = new AmazonS3Client(credentials);
		// Region usWest2 = Region.getRegion(Regions.US_WEST_2);
		// s3.setRegion(usWest2);
		tx = new TransferManager(s3);
	}

	private static void createBucket(String bucketName) {
		if (s3.doesBucketExist(bucketName) == true) {
			System.out.println(bucketName + " already exist!");
			return;
		}
		System.out.println("creating " + bucketName + " ...");
		s3.createBucket(bucketName);
		System.out.println(bucketName + " has been created!");
	}

	private static void listObjects() {
		System.out.println("Listing objects of " + bucketName);
		ObjectListing objectListing = s3.listObjects(bucketName);
		int objectNum = 0;
		for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
			System.out.println(" - " + objectSummary.getKey());
			objectNum++;
		}
		System.out.println("total " + objectNum + " object(s).");
	}

	private static boolean isObjectExit(String bucketName, String key) {
		int len = key.length();
		ObjectListing objectListing = s3.listObjects(bucketName);
		String s = new String();
		for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
			s = objectSummary.getKey();
			int slen = s.length();
			if (len == slen) {
				int i;
				for (i = 0; i < len; i++)
					if (s.charAt(i) != key.charAt(i))
						break;
				if (i == len)
					return true;
			}
		}
		return false;
	}

	private static void createSampleFile(String bucketName, String filename) throws IOException {
		if (isObjectExit(bucketName, filename) == true) {
			System.out.println(filename + " already exists in " + bucketName + "!");
			return;
		}
		System.out.println("creating file " + filename);
		File file = new File(filename);
		file.deleteOnExit();

		Writer writer = new OutputStreamWriter(new FileOutputStream(file));
		writer.write("abcdefghijklmnopqrstuvwxyz\n");
		writer.write("01234567890112345678901234\n");
		writer.write("!@#$%^&*()-=[]{};':',.<>/?\n");
		writer.write("01234567890112345678901234\n");
		writer.write("abcdefghijklmnopqrstuvwxyz\n");
		writer.close();

		s3.putObject(bucketName, filename, file);
		System.out.println("create sample file " + filename + " succeed!");
	}

	private static void showContentOfAnObject(String bucketName, String key) {
		S3Object object = s3.getObject(new GetObjectRequest(bucketName, key));
		InputStream input = object.getObjectContent();
		BufferedReader reader = new BufferedReader(new InputStreamReader(input));
		try {
			while (true) {
				String line = reader.readLine();
				if (line == null)
					break;
				System.out.println("    " + line);
			}
			System.out.println();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void showContentOfAnGzipObject(String bucketName, String key) {
		try {
			S3Object object = s3.getObject(new GetObjectRequest(bucketName, key));
			InputStream input = new GZIPInputStream(object.getObjectContent());
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));

			while (true) {
				String line = reader.readLine();
				if (line == null)
					break;
				System.out.println("    " + line);
			}
			System.out.println();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static void listBuckets() {
		System.out.println("Listing buckets");
		int bucketNum = 0;
		for (Bucket bucket : s3.listBuckets()) {
			System.out.println(" - " + bucket.getName());
			bucketNum++;
		}
		System.out.println("total " + bucketNum + " bucket(s).");
	}

	private static void deleteBucket(String bucketName) {
		if (s3.doesBucketExist(bucketName) == false) {
			System.out.println(bucketName + " does not exists!");
			return;
		}
		System.out.println("deleting " + bucketName + " ...");
		ObjectListing objectListing = s3.listObjects(bucketName);
		for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
			String key = objectSummary.getKey();
			s3.deleteObject(bucketName, key);
		}
		s3.deleteBucket(bucketName);
		System.out.println(bucketName + " has been deleted!");
	}

	public void deleteObjectsWithPrefix(String prefix) throws AmazonServiceException, SdkClientException, Exception {
		if (S3Client.getInstance().getAmazonS3().doesBucketExist(bucketName) == false) {
			System.out.println(bucketName + " does not exists!");
			return;
		}
		prefix = prefix + "/";
		System.out.println("deleting " + prefix + "* in " + bucketName + " ...");
		int pre_len = prefix.length();
		ObjectListing objectListing = S3Client.getInstance().getAmazonS3().listObjects(bucketName);
		for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
			String key = objectSummary.getKey();
			int len = key.length();
			if (len < pre_len)
				continue;
			int i;
			for (i = 0; i < pre_len; i++)
				if (key.charAt(i) != prefix.charAt(i))
					break;
			if (i < pre_len)
				continue;
			S3Client.getInstance().getAmazonS3().deleteObject(bucketName, key);
		}
		System.out.println("All " + prefix + "* deleted!");
	}

	private static void deleteObject(String bucketName, String obj) {
		if (s3.doesBucketExist(bucketName) == false) {
			System.out.println(bucketName + " does not exists!");
			return;
		}
		System.out.println("deleting " + obj + "* in " + bucketName + " ...");

		s3.deleteObject(bucketName, obj);
		System.out.println("All " + obj + "* deleted!");
	}

	public void uploadFileToBucket(File fileToUpload, String key)
			throws AmazonServiceException, AmazonClientException, Exception {

		PutObjectRequest request = new PutObjectRequest(bucketName, key, fileToUpload);
		Upload upload = S3Client.getInstance().getTransferManager().upload(request);
		System.out.println(fileToUpload.getName() + " upload succeed!");
	}

	public InputStream getObjects(String keyName) throws AmazonServiceException, SdkClientException, Exception {

		if (S3Client.getInstance().getAmazonS3().doesObjectExist(bucketName, keyName)) {
			S3Object object = s3.getObject(new GetObjectRequest(bucketName, keyName));
			S3ObjectInputStream objStream = object.getObjectContent();
			InputStream is = new BufferedInputStream(objStream);

			return is;
		} else {
			return null;
		}

	}

	private static void createFolder(String bucketName, String folderName) {
		// Create metadata for my folder & set content-length to 0
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentLength(0);
		// Create empty content
		InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
		// Create a PutObjectRequest passing the foldername suffixed by /
		PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, folderName + "/", emptyContent, metadata);
		// Send request to S3 to create folder
		s3.putObject(putObjectRequest);
	}

//	public static void main(String[] args) throws Exception {
//
//		init_with_key();
//		// S3Client.getInstance().uploadFileToBucket(new
//		// File("D:\\UCM\\tmp.jpg"),"test/logo2.jpg");
//		S3Client.getInstance().deleteObjectsWithPrefix("tmp");
//		listObjects();
//
//		// String path = "test/logo.jpg";
//		//
//		// InputStream is = S3Client.getInstance().getObjects(path);
//		//
//		// byte[] byt = new byte[10240];
//		// int len = 0;
//		// FileOutputStream fileOutputStream = null;
//		// File file = new File("D:\\UCM\\tmp\\tmp.jpg");
//		// fileOutputStream = new FileOutputStream(file);
//		// while ((len = is.read(byt)) != -1) {
//		// fileOutputStream.write(byt, 0, len);
//		// }
//		// fileOutputStream.close();
//
//	}
}
