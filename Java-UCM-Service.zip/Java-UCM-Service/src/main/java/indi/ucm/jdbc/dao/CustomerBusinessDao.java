package indi.ucm.jdbc.dao;

import java.util.List;

import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.entry.CustomerBusiness;
import indi.ucm.jdbc.mapper.CustomerAccountMapper;
import indi.ucm.jdbc.mapper.CustomerBusinessMapper;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerBusinessDao extends JdbcDaoSupport {
	private final static String SQL_INSERT_ONE_CUSTOMER_BUSINESS_POSTFIX = " (customer_business_ID, customer_ID, business_name, business_type, business_time_zone, business_phone_number, business_fax_number, business_address_street, business_address_room_number, business_address_city, business_address_state_province,  business_addresss_country, business_description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	private final static String SQL_PROCESS_BY_CUSTOMER_ID_POSTFIX = " where customer_ID = ?";
	private final static String SQL_SELECT_ONE_CUSTOMER_BUSINESS_BY_BUSINESS_ID_POSTFIX = " where customer_business_ID = ?";
	private final static String SQL_SELECT_CUSTOMER_BUSINESS_PREFIX = "SELECT * FROM customer_business_";
	private final static String SQL_UPDATE_CUSTOMER_BUSINESS_POSTFIX = " set business_name = ? where customer_ID = ?";

	public CustomerBusiness getCustomerBusiness(final long customerId,
			int masterUserId) {
		try {
			CustomerBusiness cb = this
					.getJdbcTemplate()
					.queryForObject(
							"SELECT * FROM customer_business_"
									+ masterUserId
									+ CustomerBusinessDao.SQL_PROCESS_BY_CUSTOMER_ID_POSTFIX,
							new Object[] { customerId },
							new CustomerBusinessMapper());
			return cb;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public CustomerBusiness getCustomerBusinessByBusinessId(
			final long businesssId, int masterUserId) {
		try {
			CustomerBusiness cb = this
					.getJdbcTemplate()
					.queryForObject(
							"SELECT * FROM customer_business_"
									+ masterUserId
									+ SQL_SELECT_ONE_CUSTOMER_BUSINESS_BY_BUSINESS_ID_POSTFIX,
							new Object[] { businesssId },
							new CustomerBusinessMapper());
			return cb;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<CustomerBusiness> getCustomerBusinesss(final int masterUserId) {
		List<CustomerBusiness> cbs = this.getJdbcTemplate().query(
				SQL_SELECT_CUSTOMER_BUSINESS_PREFIX + masterUserId,
				new Object[] {}, new CustomerBusinessMapper());

		return cbs;
	}

	/**
	 * create customer business
	 * 
	 * @param CustomerBusiness
	 */
	public void createCustomerBusiness(final CustomerBusiness CustomerBusiness,
			int masterUserId) {
		this.getJdbcTemplate()
				.update("INSERT INTO customer_business_"
						+ masterUserId
						+ CustomerBusinessDao.SQL_INSERT_ONE_CUSTOMER_BUSINESS_POSTFIX,
						CustomerBusiness.getCustomerBusinessId(),
						CustomerBusiness.getCustomerId(),
						CustomerBusiness.getBusinessName(),
						CustomerBusiness.getBusinessType(),
						CustomerBusiness.getBusinessTimeZone(),
						CustomerBusiness.getPhoneNumber(),
						CustomerBusiness.getBusinessFaxNumber(),
						CustomerBusiness.getBusinessAddressStreet(),
						CustomerBusiness.getBusinessAddressRoomNumber(),
						CustomerBusiness.getBusinessAddressCity(),
						CustomerBusiness.getBusinessAddressStateProvince(),
						CustomerBusiness.getBusinessAddressCountry(),
						CustomerBusiness.getBusinessDescription());
	}

	public void updateCustomerBusiness(final CustomerBusiness CustomerBusiness,
			int masterUserId) {
		this.getJdbcTemplate().update(
				"update customer_business_" + masterUserId
						+ SQL_UPDATE_CUSTOMER_BUSINESS_POSTFIX,
				CustomerBusiness.getBusinessName(),CustomerBusiness.getCustomerId());
	}

	public void deleteCustomerBusiness(final int customerId, int masterUserId) {
		this.getJdbcTemplate().update(
				"DELETE FROM customer_business_" + masterUserId
						+ SQL_PROCESS_BY_CUSTOMER_ID_POSTFIX, customerId);
	}

	/**
	 * create customer_business_[postfix] table
	 * 
	 * @param tableName
	 */
	public void createTable(final String tableName) {
		StringBuffer sb = new StringBuffer("");
		sb.append("CREATE TABLE `" + tableName + "` (");
		sb.append("`customer_business_ID` bigint NOT NULL,");
		sb.append("`customer_ID` bigint NOT NULL,");
		sb.append("`business_name` varchar(200)  NOT NULL,");
		sb.append("`business_type` tinyint  ,");
		sb.append("`business_time_zone` int  ,");
		sb.append("`business_phone_number` varchar(50)  ,");
		sb.append("`business_fax_number` varchar(50)  ,");
		sb.append("`business_address_street` varchar(100)  ,");
		sb.append("`business_address_room_number` varchar(100)  ,");
		sb.append("`business_address_city` varchar(100)  ,");
		sb.append("`business_address_state_province` varchar(100)  ,");
		sb.append("`business_addresss_country` int  ,");
		sb.append("`business_description` varchar(1000)  ,");
		sb.append("PRIMARY KEY (`customer_ID`))character set = utf8;");
		try {
			this.getJdbcTemplate().update(sb.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
