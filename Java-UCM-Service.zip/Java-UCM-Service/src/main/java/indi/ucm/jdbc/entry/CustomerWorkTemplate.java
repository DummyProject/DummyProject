package indi.ucm.jdbc.entry;

// Info of customer work template
public class CustomerWorkTemplate {
    private int customerWorkTemplateId;
    private String templateName;
    private int templateSectionId;
    private int assignedStaffUser;
    private String scheduleStartDate;
    private String scheduleEndDate;
    private int workRepeatInterval;
    private String scheduleStartTime;
    private String scheduleEndTime;
    private int workTimeDuration;
    private int workLocationType;
    private int customerID;
    private String workDescription;
    private int workBillable;
    private int workBillingRate;
    private int workReminderNotifyStaff;
    private int workReminderNotifyStaffTime;
    private String workReminderNotifyStaffMethod;
    private int workReminderNotifyCustomer;
    private int workReminderNotifyCustomerTime;
    private String workReminderNotifyCustomerMethod;
    private String workReminderMessage;
    private String workName;
    private String dateRange;

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public String getDateRange() {
		return dateRange;
	}

	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}

	/**
     * @return the customerWorkTemplateId
     */
    public int getCustomerWorkTemplateId() {
        return this.customerWorkTemplateId;
    }

    /**
     * @param customerWorkTemplateId
     *            the customerWorkTemplateId to set
     */
    public void setCustomerWorkTemplateId(final int customerWorkTemplateId) {
        this.customerWorkTemplateId = customerWorkTemplateId;
    }

    /**
     * @return the templateName
     */
    public String getTemplateName() {
        return this.templateName;
    }

    /**
     * @param templateName
     *            the templateName to set
     */
    public void setTemplateName(final String templateName) {
        this.templateName = templateName;
    }

    /**
     * @return the templateSectionId
     */
    public int getTemplateSectionId() {
        return this.templateSectionId;
    }

    /**
     * @param templateSectionId
     *            the templateSectionId to set
     */
    public void setTemplateSectionId(final int templateSectionId) {
        this.templateSectionId = templateSectionId;
    }

    /**
     * @return the assignStaffUser
     */
    public int getAssignStaffUser() {
        return this.assignedStaffUser;
    }

    /**
     * @param assignStaffUser
     *            the assignStaffUser to set
     */
    public void setAssignStaffUser(final int assignedStaffUser) {
        this.assignedStaffUser = assignedStaffUser;
    }

    /**
     * @return the scheduleStartDate
     */
    public String getScheduleStartDate() {
        return this.scheduleStartDate;
    }

    /**
     * @param scheduleStartDate
     *            the scheduleStartDate to set
     */
    public void setScheduleStartDate(String scheduleStartDate) {
        this.scheduleStartDate = scheduleStartDate;
    }

    /**
     * @return the scheduleEndDate
     */
    public String getScheduleEndDate() {
        return this.scheduleEndDate;
    }

    /**
     * @param scheduleEndDate
     *            the scheduleEndDate to set
     */
    public void setScheduleEndDate(String scheduleEndDate) {
        this.scheduleEndDate = scheduleEndDate;
    }

    /**
     * @return the workRepeatInterval
     */
    public int getWorkRepeatInterval() {
        return this.workRepeatInterval;
    }

    /**
     * @param workRepeatInterval
     *            the workRepeatInterval to set
     */
    public void setWorkRepeatInterval(final int workRepeatInterval) {
        this.workRepeatInterval = workRepeatInterval;
    }

    /**
     * @return the scheduleStartTime
     */
    public String getScheduleStartTime() {
        return this.scheduleStartTime;
    }

    /**
     * @param scheduleStartTime
     *            the scheduleStartTime to set
     */
    public void setScheduleStartTime(String scheduleStartTime) {
        this.scheduleStartTime = scheduleStartTime;
    }

    /**
     * @return the scheduleEndTime
     */
    public String getScheduleEndTime() {
        return this.scheduleEndTime;
    }

    /**
     * @param scheduleEndTime
     *            the scheduleEndTime to set
     */
    public void setScheduleEndTime(String scheduleEndTime) {
        this.scheduleEndTime = scheduleEndTime;
    }

    /**
     * @return the workTimeDuration
     */
    public int getWorkTimeDuration() {
        return this.workTimeDuration;
    }

    /**
     * @param workTimeDuration
     *            the workTimeDuration to set
     */
    public void setWorkTimeDuration(final int workTimeDuration) {
        this.workTimeDuration = workTimeDuration;
    }

    /**
     * @return the workLocationType
     */
    public int getWorkLocationType() {
        return this.workLocationType;
    }

    /**
     * @param workLocationType
     *            the workLocationType to set
     */
    public void setWorkLocationType(final int workLocationType) {
        this.workLocationType = workLocationType;
    }

    /**
     * @return the workClientContact
     */
    public int getCustomerID() {
        return this.customerID;
    }

    /**
     * @param workClientContact
     *            the workClientContact to set
     */
    public void setcCustomerID(final int customerID) {
        this.customerID = customerID;
    }

    /**
     * @return the workDescription
     */
    public String getWorkDescription() {
        return this.workDescription;
    }

    /**
     * @param workDescription
     *            the workDescription to set
     */
    public void setWorkDescription(final String workDescription) {
        this.workDescription = workDescription;
    }

    /**
     * @return the workBillable
     */
    public int getWorkBillable() {
        return this.workBillable;
    }

    /**
     * @param workBillable
     *            the workBillable to set
     */
    public void setWorkBillable(final int workBillable) {
        this.workBillable = workBillable;
    }

    /**
     * @return the workBillingRate
     */
    public int getWorkBillingRate() {
        return this.workBillingRate;
    }

    /**
     * @param workBillingRate
     *            the workBillingRate to set
     */
    public void setWorkBillingRate(final int workBillingRate) {
        this.workBillingRate = workBillingRate;
    }

    /**
     * @return the workReminderNotifyStaff
     */
    public int getWorkReminderNotifyStaff() {
        return this.workReminderNotifyStaff;
    }

    /**
     * @param workReminderNotifyStaff
     *            the workReminderNotifyStaff to set
     */
    public void setWorkReminderNotifyStaff(final int workReminderNotifyStaff) {
        this.workReminderNotifyStaff = workReminderNotifyStaff;
    }

    /**
     * @return the workReminderNotifyStaffTime
     */
    public int getWorkReminderNotifyStaffTime() {
        return this.workReminderNotifyStaffTime;
    }

    /**
     * @param workReminderNotifyStaffTime
     *            the workReminderNotifyStaffTime to set
     */
    public void setWorkReminderNotifyStaffTime(final int workReminderNotifyStaffTime) {
        this.workReminderNotifyStaffTime = workReminderNotifyStaffTime;
    }

    /**
     * @return the workReminderNotifyStaffMethod
     */
    public String getWorkReminderNotifyStaffMethod() {
        return this.workReminderNotifyStaffMethod;
    }

    /**
     * @param workReminderNotifyStaffMethod
     *            the workReminderNotifyStaffMethod to set
     */
    public void setWorkReminderNotifyStaffMethod(String workReminderNotifyStaffMethod) {
        this.workReminderNotifyStaffMethod = workReminderNotifyStaffMethod;
    }

    /**
     * @return the workReminderNotifyCustomer
     */
    public int getWorkReminderNotifyCustomer() {
        return this.workReminderNotifyCustomer;
    }

    /**
     * @param workReminderNotifyCustomer
     *            the workReminderNotifyCustomer to set
     */
    public void setWorkReminderNotifyCustomer(final int workReminderNotifyCustomer) {
        this.workReminderNotifyCustomer = workReminderNotifyCustomer;
    }

    /**
     * @return the workReminderNotifyCustomerTime
     */
    public int getWorkReminderNotifyCustomerTime() {
        return this.workReminderNotifyCustomerTime;
    }

    /**
     * @param workReminderNotifyCustomerTime
     *            the workReminderNotifyCustomerTime to set
     */
    public void setWorkReminderNotifyCustomerTime(final int workReminderNotifyCustomerTime) {
        this.workReminderNotifyCustomerTime = workReminderNotifyCustomerTime;
    }

    /**
     * @return the workReminderNotifyCustomerMethod
     */
    public String getWorkReminderNotifyCustomerMethod() {
        return this.workReminderNotifyCustomerMethod;
    }

    /**
     * @param workReminderNotifyCustomerMethod
     *            the workReminderNotifyCustomerMethod to set
     */
    public void setWorkReminderNotifyCustomerMethod(String workReminderNotifyCustomerMethod) {
        this.workReminderNotifyCustomerMethod = workReminderNotifyCustomerMethod;
    }

    /**
     * @return the workReminderMessage
     */
    public String getWorkReminderMessage() {
        return this.workReminderMessage;
    }

    /**
     * @param workReminderMessage
     *            the workReminderMessage to set
     */
    public void setWorkReminderMessage(final String workReminderMessage) {
        this.workReminderMessage = workReminderMessage;
    }
    
    public String getWorkName() {
		return workName;
	}

	public void setWorkName(String workName) {
		this.workName = workName;
	}

}
