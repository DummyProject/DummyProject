package indi.ucm.jdbc.dao;


import indi.ucm.jdbc.entry.CustomerWorkStatus;
import indi.ucm.jdbc.entry.WorkTimeDuration;
import indi.ucm.jdbc.mapper.CustomerWorkStatusMapper;
import indi.ucm.jdbc.mapper.WorkTimeDurationMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class WorkTimeDurationDao extends JdbcDaoSupport{
	private final  String SQL_INSERT_WORK_TIME_DURATION_POSTFIX = " (work_time_duration_ID, work_time_duration,work_time_duration_minutes) VALUES (?, ?, ?)";
	private final  String SQL_SELECT_WORK_TIME_DURATION_PREFIX = "SELECT * FROM work_time_duration_";
	private final  String SQL_SELECT_WORK_TIME_DURATION_BY_ID_POSTFIX =" where work_time_duration_ID = ?";
	
	public void createWorkTimeDuration (final WorkTimeDuration workTimeDuration, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO customer_work_status_" + masterUserId
	                + SQL_INSERT_WORK_TIME_DURATION_POSTFIX,
	                workTimeDuration.getWorkTimeDurationId(), 
	                workTimeDuration.getWorkTimeDuration(),
	                workTimeDuration.getWorkTimeDurationMinutes());
	}
	
	public List<WorkTimeDuration> getAllWorkTimeDuration(final int masterUserId) {
        List<WorkTimeDuration> AllWorkTimeDuration = this.getJdbcTemplate().query(
        		SQL_SELECT_WORK_TIME_DURATION_PREFIX + masterUserId, new Object[] {},       		
            new WorkTimeDurationMapper());

        return AllWorkTimeDuration;
    }
	
	
	public String getworkTimeDurationByID( int statusID,int masterUserId){
		WorkTimeDuration workTimeDuration = this.getJdbcTemplate().queryForObject(
				SQL_SELECT_WORK_TIME_DURATION_PREFIX + masterUserId+SQL_SELECT_WORK_TIME_DURATION_BY_ID_POSTFIX, 
        		new Object[] { statusID },       		
            new WorkTimeDurationMapper());
		
		return workTimeDuration.getWorkTimeDuration();
	}
	 /**
     * create work_time_duration_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`work_time_duration_ID` smallint NOT NULL,");
	        sb.append("`work_time_duration` varchar(100) NOT NULL,");
	        sb.append("`work_time_duration_minutes` int NOT NULL,");
	        sb.append("PRIMARY KEY (`work_time_duration_ID`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertWorkDuration(tableName);
	 }
	 
	 private void insertWorkDuration(String tableName) {
	        String sql = "insert into "+tableName+" (work_time_duration_ID, work_time_duration,work_time_duration_minutes) "
	        		     + "VALUES (1, '30 minutes',30),(2, '45 minutes',45),(3, '1 hour',60),"
	        		     + "(4, '2 hours',120),(5, '4 hours',240),(6, '6 hours',360),"
	        		     + "(7,'8 hours',480),(8,'12 hours',720),(9,'1 day',1440),"
	        		     + "(10,'2 days',2880),(11,'3 days',4320)";
	        this.getJdbcTemplate().update(sql);
	 }
	
}
