package indi.ucm.jdbc.dao;

import java.util.List;

import indi.ucm.jdbc.entry.CustomerWorkStatus;
import indi.ucm.jdbc.mapper.CustomerWorkStatusMapper;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkStatusDao extends JdbcDaoSupport {
	private final  String SQL_INSERT_CUSTOMER_WORK_STATUS_POSTFIX = " (work_status_ID, work_status_name) VALUES (?, ?)";
	private final  String SQL_SELECT_CUSTOMER_WORK_STATUS_PREFIX = "SELECT * FROM customer_work_status_";
	private final  String SQL_SELECT_WORK_STATUS_BY_ID_POSTFIX = " where work_status_ID = ?";
	
	public void createCustomerAccountStatus (final CustomerWorkStatus CustomerWorkStatus, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO customer_work_status_" + masterUserId
	                + SQL_INSERT_CUSTOMER_WORK_STATUS_POSTFIX,
	                CustomerWorkStatus.getWorkStatusId(), 
	                CustomerWorkStatus.getWorkStatusName());
	}
	
	public List<CustomerWorkStatus> getAllCustomerWorkStatus(final int masterUserId) {
        List<CustomerWorkStatus> allCustomerWorkStatus = this.getJdbcTemplate().query(
        		SQL_SELECT_CUSTOMER_WORK_STATUS_PREFIX + masterUserId, new Object[] {},       		
            new CustomerWorkStatusMapper());

        return allCustomerWorkStatus;
    }
	
	public String getStatusByID( int statusID,int masterUserId){	
		CustomerWorkStatus customerWorkStatus = this.getJdbcTemplate().queryForObject(
        		SQL_SELECT_CUSTOMER_WORK_STATUS_PREFIX + masterUserId+SQL_SELECT_WORK_STATUS_BY_ID_POSTFIX, 
        		new Object[] { statusID },       		
            new CustomerWorkStatusMapper());
		
		return customerWorkStatus.getWorkStatusName();
	}
	
	 /**
     * create CUSTOMER_WORK_STATUS_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`work_status_ID` tinyint NOT NULL,");
	        sb.append("`work_status_name` varchar(100) NOT NULL,");
	        sb.append("PRIMARY KEY (`work_status_ID`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertWorkStatus(tableName);
	 }
	 
	 private void insertWorkStatus(String tableName) {
	        String sql = "insert into "+tableName+" (work_status_ID, work_status_name) "
	        		     + "VALUES (1, 'scheduled'),(2, 'in-progress'),(3, 'pending'),(4, 'completed')";
	        this.getJdbcTemplate().update(sql);
	 }
}
