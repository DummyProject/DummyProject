package indi.ucm.jdbc.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class WorkDocumentsDao  extends JdbcDaoSupport {

}
