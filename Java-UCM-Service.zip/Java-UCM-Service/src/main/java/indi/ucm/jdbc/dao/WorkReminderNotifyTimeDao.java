package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.WorkReminderNotifyTime;
import indi.ucm.jdbc.mapper.WorkReminderNotifyTimeMapper;


import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class WorkReminderNotifyTimeDao extends JdbcDaoSupport{
	private final  String SQL_INSERT_WORK_REMINDER_NOTIFY_TIME_POSTFIX = " (work_reminder_notify_time, reminder_schedule_name,reminder_schedule_minutes) VALUES (?, ?, ?)";
	private final  String SQL_SELECT_WORK_REMINDER_NOTIFY_TIME_PREFIX = "SELECT * FROM work_reminder_notify_time_";
	
	
	public void createWorkReminderNotifyTime (final WorkReminderNotifyTime workReminderNotifyTime, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO work_reminder_notify_time_" + masterUserId
	                + SQL_INSERT_WORK_REMINDER_NOTIFY_TIME_POSTFIX,
	                workReminderNotifyTime.getWorkReminderNotifyTime(), 
	                workReminderNotifyTime.getReminderScheduleName(),
	                workReminderNotifyTime.getReminderScheduleMinutes());
	}
	
	public List<WorkReminderNotifyTime> getAllWorkReminderNotifyTime(final int masterUserId) {
        List<WorkReminderNotifyTime> AllWorkTimeDuration = this.getJdbcTemplate().query(
        		SQL_SELECT_WORK_REMINDER_NOTIFY_TIME_PREFIX + masterUserId, new Object[] {},       		
            new WorkReminderNotifyTimeMapper());

        return AllWorkTimeDuration;
    }
	
	 /**
     * create work_time_duration_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`work_reminder_notify_time` tinyint NOT NULL,");
	        sb.append("`reminder_schedule_name` varchar(100) NOT NULL,");
	        sb.append("`reminder_schedule_minutes` int NOT NULL,");
	        sb.append("PRIMARY KEY (`work_reminder_notify_time`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertWorkReminderNotify_time(tableName);
	 }
	 
	 private void insertWorkReminderNotify_time(String tableName) {
	        String sql = "insert into "+tableName+" (work_reminder_notify_time, reminder_schedule_name,reminder_schedule_minutes) "
	        		     + "VALUES (1, '1 hour',60),(2, '2 hour',120),(3, '4 hour',240),"
	        		     + "(4, '8 hours',480),(5, '12 hours',720),(6, '1 day',1440),"
	        		     + "(7,'2 days',2880),(8,'3 days',4320),(9,'1 week',10080),"
	        		     + "(10,'2 weeks',20160),(11,'1 month',43200)";
	        this.getJdbcTemplate().update(sql);
	 }
}
