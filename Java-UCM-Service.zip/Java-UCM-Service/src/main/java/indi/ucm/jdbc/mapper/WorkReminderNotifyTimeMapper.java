package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.WorkReminderNotifyTime;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class WorkReminderNotifyTimeMapper implements RowMapper<WorkReminderNotifyTime> {

    public WorkReminderNotifyTime mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        WorkReminderNotifyTime wrnt = new WorkReminderNotifyTime();
        wrnt.setWorkReminderNotifyTime(rs.getInt("work_reminder_notify_time"));
        wrnt.setReminderScheduleName(rs.getString("reminder_schedule_name"));
        wrnt.setReminderScheduleMinutes(rs.getInt("reminder_schedule_minutes"));
        return wrnt;
    }

}
