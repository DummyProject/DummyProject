package indi.ucm.jdbc.mapper;

import indi.ucm.jdbc.entry.CustomerBusiness;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CustomerBusinessMapper implements RowMapper<CustomerBusiness> {

    @Override
    public CustomerBusiness mapRow(final ResultSet rs, final int rowNum) throws SQLException {
        CustomerBusiness cb = new CustomerBusiness();
        cb.setCustomerBusinessId(rs.getLong("customer_business_ID"));
        cb.setCustomerId(rs.getLong("customer_ID"));
        cb.setBusinessName(rs.getString("business_name"));
        cb.setBusinessType(rs.getInt("business_type"));
        cb.setBusinessTimeZone(rs.getShort("business_time_zone"));
        cb.setPhoneNumber(rs.getString("business_phone_number"));
        cb.setBusinessFaxNumber(rs.getString("business_fax_number"));
        cb.setBusinessAddressStreet(rs.getString("business_address_street"));
        cb.setBusinessAddressRoomNumber(rs.getString("business_address_room_number"));
        cb.setBusinessAddressCity(rs.getString("business_address_city"));
        cb.setBusinessAddressStateProvince(rs.getString("business_address_state_province"));
        cb.setBusinessAddressCountry(rs.getInt("business_addresss_country"));
        cb.setBusinessDescription(rs.getString("business_description"));
        return cb;
    }

}
