package indi.ucm.jdbc.entry;

import java.sql.Date;
import java.sql.Time;


// Info of customer work
public class CustomerWork {
    private long customerWorkId;
    private String workName;
	private long customerId;
    private int workStatus;
    private int assignedStaffUser;
    private String scheduleStartDate;
    private String scheduleEndDate;
    private String scheduleStartTime;
    private String scheduleEndTime;
    private int workRepeatInterval;
    private int workTimeDuration;
    private int workLocationType;
    private String workDescription;
    private int workBillable;
    private int workBillingRate;
    private int billingCurrencyId;
    private int workReminderNotifyStaff;
    private int workReminderNotifyStaffTime;
    private String workReminderNotifyStaffMethod;
    private int workReminderNotifyCustomer;
    private int workReminderNotifyCustomerTime;
    private String workReminderNotifyCustomerMethod;
    private String workReminderMessage;
    private String actualCompleteDate;
    private String actualCompleteTime;
    private String dateRange;

    public String getDateRange() {
		return dateRange;
	}

	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}

	/**
     * @return the customerWorkId
     */
    public long getCustomerWorkId() {
        return this.customerWorkId;
    }
    
    public String getWorkName() {
		return workName;
	}

	public void setWorkName(String workName) {
		this.workName = workName;
	}

    /**
     * @param customerWorkId
     *            the customerWorkId to set
     */
    public void setCustomerWorkId(final long customerWorkId) {
        this.customerWorkId = customerWorkId;
    }

    /**
     * @return the customerId
     */
    public long getCustomerId() {
        return this.customerId;
    }

    /**
     * @param customerId
     *            the customerId to set
     */
    public void setCustomerId(final long customerId) {
        this.customerId = customerId;
    }

    /**
     * @return the workStatus
     */
    public int getWorkStatus() {
        return this.workStatus;
    }

    /**
     * @param workStatus
     *            the workStatus to set
     */
    public void setWorkStatus(final int workStatus) {
        this.workStatus = workStatus;
    }

    /**
     * @return the assignedStaffUser
     */
    public int getAssignedStaffUser() {
        return this.assignedStaffUser;
    }

    /**
     * @param assignedStaffUser
     *            the assignedStaffUser to set
     */
    public void setAssignedStaffUser(final int assignedStaffUser) {
        this.assignedStaffUser = assignedStaffUser;
    }

    /**
     * @return the scheduleStartDate
     */
    public String getScheduleStartDate() {
        return this.scheduleStartDate;
    }

    /**
     * @param scheduleStartDate
     *            the scheduleStartDate to set
     */
    public void setScheduleStartDate(final String scheduleStartDate) {
        this.scheduleStartDate = scheduleStartDate;
    }

    /**
     * @return the scheduleEndDate
     */
    public String getScheduleEndDate() {
        return this.scheduleEndDate;
    }

    /**
     * @param scheduleEndDate
     *            the scheduleEndDate to set
     */
    public void setScheduleEndDate(final String scheduleEndDate) {
        this.scheduleEndDate = scheduleEndDate;
    }

    /**
     * @return the scheduleStartTime
     */
    public String getScheduleStartTime() {
        return this.scheduleStartTime;
    }

    /**
     * @param scheduleStartTime
     *            the scheduleStartTime to set
     */
    public void setScheduleStartTime(final String scheduleStartTime) {
        this.scheduleStartTime = scheduleStartTime;
    }

    /**
     * @return the scheduleEndTime
     */
    public String getScheduleEndTime() {
        return this.scheduleEndTime;
    }

    /**
     * @param scheduleEndTime
     *            the scheduleEndTime to set
     */
    public void setScheduleEndTime(final String scheduleEndTime) {
        this.scheduleEndTime = scheduleEndTime;
    }

    /**
     * @return the workRepeatInterval
     */
    public int getWorkRepeatInterval() {
        return this.workRepeatInterval;
    }

    /**
     * @param workRepeatInterval
     *            the workRepeatInterval to set
     */
    public void setWorkRepeatInterval(final int workRepeatInterval) {
        this.workRepeatInterval = workRepeatInterval;
    }

    /**
     * @return the workTimeDuration
     */
    public int getWorkTimeDuration() {
        return this.workTimeDuration;
    }

    /**
     * @param workTimeDuration
     *            the workTimeDuration to set
     */
    public void setWorkTimeDuration(final int workTimeDuration) {
        this.workTimeDuration = workTimeDuration;
    }

    /**
     * @return the workLocationType
     */
    public int getWorkLocationType() {
        return this.workLocationType;
    }

    /**
     * @param workLocationType
     *            the workLocationType to set
     */
    public void setWorkLocationType(final int workLocationType) {
        this.workLocationType = workLocationType;
    }

    /**
     * @return the workDescription
     */
    public String getWorkDescription() {
        return this.workDescription;
    }

    /**
     * @param workDescription
     *            the workDescription to set
     */
    public void setWorkDescription(final String workDescription) {
        this.workDescription = workDescription;
    }

    /**
     * @return the workBillable
     */
    public int getWorkBillable() {
        return this.workBillable;
    }

    /**
     * @param workBillable
     *            the workBillable to set
     */
    public void setWorkBillable(final int workBillable) {
        this.workBillable = workBillable;
    }

    /**
     * @return the workBillingRate
     */
    public int getWorkBillingRate() {
        return this.workBillingRate;
    }

    /**
     * @param workBillingRate
     *            the workBillingRate to set
     */
    public void setWorkBillingRate(final int workBillingRate) {
        this.workBillingRate = workBillingRate;
    }

    /**
     * @return the billingCurrencyId
     */
    public int getBillingCurrencyId() {
        return this.billingCurrencyId;
    }

    /**
     * @param billingCurrencyId
     *            the billingCurrencyId to set
     */
    public void setBillingCurrencyId(final int billingCurrencyId) {
        this.billingCurrencyId = billingCurrencyId;
    }

    /**
     * @return the workReminderNotifyStaff
     */
    public int getWorkReminderNotifyStaff() {
        return this.workReminderNotifyStaff;
    }

    /**
     * @param workReminderNotifyStaff
     *            the workReminderNotifyStaff to set
     */
    public void setWorkReminderNotifyStaff(final int workReminderNotifyStaff) {
        this.workReminderNotifyStaff = workReminderNotifyStaff;
    }

    /**
     * @return the workReminderNotifyStaffTime
     */
    public int getWorkReminderNotifyStaffTime() {
        return this.workReminderNotifyStaffTime;
    }

    /**
     * @param workReminderNotifyStaffTime
     *            the workReminderNotifyStaffTime to set
     */
    public void setWorkReminderNotifyStaffTime(final int workReminderNotifyStaffTime) {
        this.workReminderNotifyStaffTime = workReminderNotifyStaffTime;
    }

    /**
     * @return the workReminderNotifyStaffMethod
     */
    public String getWorkReminderNotifyStaffMethod() {
        return this.workReminderNotifyStaffMethod;
    }

    /**
     * @param workReminderNotifyStaffMethod
     *            the workReminderNotifyStaffMethod to set
     */
    public void setWorkReminderNotifyStaffMethod(final String workReminderNotifyStaffMethod) {
        this.workReminderNotifyStaffMethod = workReminderNotifyStaffMethod;
    }

    /**
     * @return the workReminderNotifyCustomer
     */
    public int getWorkReminderNotifyCustomer() {
        return this.workReminderNotifyCustomer;
    }

    /**
     * @param workReminderNotifyCustomer
     *            the workReminderNotifyCustomer to set
     */
    public void setWorkReminderNotifyCustomer(final int workReminderNotifyCustomer) {
        this.workReminderNotifyCustomer = workReminderNotifyCustomer;
    }

    /**
     * @return the workReminderNotifyCustomerTime
     */
    public int getWorkReminderNotifyCustomerTime() {
        return this.workReminderNotifyCustomerTime;
    }

    /**
     * @param workReminderNotifyCustomerTime
     *            the workReminderNotifyCustomerTime to set
     */
    public void setWorkReminderNotifyCustomerTime(final int workReminderNotifyCustomerTime) {
        this.workReminderNotifyCustomerTime = workReminderNotifyCustomerTime;
    }

    /**
     * @return the workReminderNotifyCustomerMethod
     */
    public String getWorkReminderNotifyCustomerMethod() {
        return this.workReminderNotifyCustomerMethod;
    }

    /**
     * @param workReminderNotifyCustomerMethod
     *            the workReminderNotifyCustomerMethod to set
     */
    public void setWorkReminderNotifyCustomerMethod(final String workReminderNotifyCustomerMethod) {
        this.workReminderNotifyCustomerMethod = workReminderNotifyCustomerMethod;
    }

    /**
     * @return the workReminderMessage
     */
    public String getWorkReminderMessage() {
        return this.workReminderMessage;
    }

    /**
     * @param workReminderMessage
     *            the workReminderMessage to set
     */
    public void setWorkReminderMessage(final String workReminderMessage) {
        this.workReminderMessage = workReminderMessage;
    }

    /**
     * @return the actualCompleteDate
     */
    public String getActualCompleteDate() {
        return this.actualCompleteDate;
    }

    /**
     * @param actualCompleteDate
     *            the actualCompleteDate to set
     */
    public void setActualCompleteDate(final String actualCompleteDate) {
        this.actualCompleteDate = actualCompleteDate;
    }

    /**
     * @return the actualCompleteTime
     */
    public String getActualCompleteTime() {
        return this.actualCompleteTime;
    }

    /**
     * @param actualCompleteTime
     *            the actualCompleteTime to set
     */
    public void setActualCompleteTime(final String actualCompleteTime) {
        this.actualCompleteTime = actualCompleteTime;
    }
}
