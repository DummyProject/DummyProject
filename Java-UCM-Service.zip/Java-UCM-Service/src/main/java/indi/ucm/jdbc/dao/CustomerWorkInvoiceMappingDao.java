package indi.ucm.jdbc.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkInvoiceMappingDao extends JdbcDaoSupport {

}
