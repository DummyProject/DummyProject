package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerWorkInvoice;
import indi.ucm.jdbc.mapper.CustomerWorkInvoiceMapper;


import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkInvoiceDao extends JdbcDaoSupport  {
	private final  String SQL_INSERT_CUSTOMER_WORK_INVOICE_POSTFIX = " (customer_work_invoice_ID, customer_ID,"
			+"customer_name,invoice_date,invoice_total_amount,billing_address_street"
			+"billing_address_room_number,billing_address_city,billing_address_state_province"
			+"billing_addresss_country,user_note,invoice_status,received_payment_ID)"
			+ " VALUES (?, ?,?,?,?,?,?,?,?,?,?,?,?)";
	private final  String SQL_SELECT_CUSTOMER_WORK_INVOICE_PREFIX = "SELECT * FROM customer_work_invoice_";
	private final  String SQL_SELECT_WORK_INVOICE_BY_ID_POSTFIX = " where customer_work_invoice_ID = ?";
	
	public void createCustomerAccountInvoice (final CustomerWorkInvoice customerWorkInvoice, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO customer_work_invoice_" + masterUserId
	                + SQL_INSERT_CUSTOMER_WORK_INVOICE_POSTFIX,
	                customerWorkInvoice.getCustomerWorkInvoiceId(),customerWorkInvoice.getCustomerId(),
	                customerWorkInvoice.getCustomerName(),customerWorkInvoice.getInvoiceDate(),
	                customerWorkInvoice.getInvoiceTotalAmount(),customerWorkInvoice.getBillingAddressStreet(),
	                customerWorkInvoice.getBillingAddressRoomNumber(),customerWorkInvoice.getBillingAddressCity(),
	                customerWorkInvoice.getBillingAddressStateProvince(),customerWorkInvoice.getBillingAddressCountry(),
	                customerWorkInvoice.getUserNote(),customerWorkInvoice.getInvoiceStatus(),customerWorkInvoice.getReceivedPaymentId());
	}
	
	/*
	public List<CustomerWorkStatus> getAllCustomerWorkStatus(final int masterUserId) {
        List<CustomerWorkStatus> allCustomerWorkStatus = this.getJdbcTemplate().query(
        		SQL_SELECT_CUSTOMER_WORK_STATUS_PREFIX + masterUserId, new Object[] {},       		
            new CustomerWorkStatusMapper());

        return allCustomerWorkStatus;
    }
    */
	
	public CustomerWorkInvoice getInvoiceByID( int invoiceID,int masterUserId){	
		CustomerWorkInvoice customerWorkInvoice = this.getJdbcTemplate().queryForObject(
				SQL_SELECT_CUSTOMER_WORK_INVOICE_PREFIX + masterUserId+SQL_SELECT_WORK_INVOICE_BY_ID_POSTFIX, 
        		new Object[] { invoiceID },       		
            new CustomerWorkInvoiceMapper());
		
		return customerWorkInvoice;
	}
	
	 /**
     * create CUSTOMER_WORK_STATUS_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`customer_work_invoice_ID` bigint NOT NULL,");
	        sb.append("`customer_ID` bigint NOT NULL,");
	        sb.append("`customer_name` varchar(200) NOT NULL,");
	        sb.append("`invoice_date` date NOT NULL,");
	        sb.append("`invoice_total_amount` double NOT NULL,");
	        sb.append("`billing_address_street` varchar(100),");
	        sb.append("`billing_address_room_number` varchar(100),");
	        sb.append("`billing_address_city` varchar(100),");
	        sb.append("`billing_address_state_province` varchar(100),");
	        sb.append("`billing_addresss_country` tinyint,");
	        sb.append("`user_note` varchar(2000),");
	        sb.append("`invoice_status` tinyint NOT NULL,");
	        sb.append("`received_payment_ID` bigint,");
	        sb.append("PRIMARY KEY (`customer_work_invoice_ID`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        
	 }
	 
	 
}
