package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.CustomerInvoiceStatus;

import org.springframework.jdbc.core.RowMapper;

public class CustomerInvoiceStatusMapper implements RowMapper<CustomerInvoiceStatus> {

	@Override
	public CustomerInvoiceStatus mapRow(ResultSet rs, int rowNum)throws SQLException {
		
		CustomerInvoiceStatus customerInvoiceStatus = new CustomerInvoiceStatus();
		customerInvoiceStatus.setInvoiceStatusId(rs.getInt("invoice_status_ID"));
		customerInvoiceStatus.setInvoiceStatusName(rs.getString("invoice_status_name"));
		
		return customerInvoiceStatus;
	}

}
