package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerWorkBillingRate;
import indi.ucm.jdbc.mapper.CustomerWorkBillingRateMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkBillingRateDao extends JdbcDaoSupport {
	private final  String SQL_INSERT_WORK_BILLING_RATE_POSTFIX = " (work_billing_rate_ID, work_time_duration_ID,billing_rate,billing_rate_comment) VALUES (?, ?, ?,?)";
	private final  String SQL_SELECT_WORK_BILLING_RATE_PREFIX = "SELECT * FROM customer_work_billing_rate_";
	
	
	public void createWorkTimeDuration (final CustomerWorkBillingRate customerWorkBillingRate, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO customer_work_billing_rate_" + masterUserId
	                + SQL_INSERT_WORK_BILLING_RATE_POSTFIX,
	                customerWorkBillingRate.getWorkBillingRateId(), 
	                customerWorkBillingRate.getWorkTimeDurationId(),
	                customerWorkBillingRate.getBillingRate(),
	                customerWorkBillingRate.getBillingRateComment());
	}
	
	public List<CustomerWorkBillingRate> getAllWorkBillingRate(final int masterUserId) {
        List<CustomerWorkBillingRate> allWorkBillingRate = this.getJdbcTemplate().query(
        		SQL_SELECT_WORK_BILLING_RATE_PREFIX + masterUserId, new Object[] {},       		
            new CustomerWorkBillingRateMapper());

        return allWorkBillingRate;
    }
	
	 /**
     * create work_time_duration_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`work_billing_rate_ID` smallint NOT NULL,");
	        sb.append("`work_time_duration_ID` smallint NOT NULL,");
	        sb.append("`billing_rate` double NOT NULL,");
	        sb.append("`billing_rate_comment` varchar(200) NOT NULL,");
	        sb.append("PRIMARY KEY (`work_billing_rate_ID`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertWorkBillingRate(tableName);
	 }
	 
	 
	 private void insertWorkBillingRate(String tableName) {
		 String sql = "insert into "+tableName+" (work_billing_rate_ID, work_time_duration_ID,billing_rate,billing_rate_comment) "
    		     + "VALUES (1, 3,100,''),(2, 9,1000,'')";
    this.getJdbcTemplate().update(sql);
	 }
	 
}
