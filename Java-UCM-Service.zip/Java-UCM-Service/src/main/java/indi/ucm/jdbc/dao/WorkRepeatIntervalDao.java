package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.WorkRepeatInterval;
import indi.ucm.jdbc.mapper.WorkRepeatIntervalMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class WorkRepeatIntervalDao extends JdbcDaoSupport{
	
	private final  String SQL_INSERT_WORK_REPEAT_INTERVAL_POSTFIX = " (work_repeat_interval_ID, repeat_Interval_name, repeat_Interval_minutes) VALUES (?, ?,?)";
	private final  String SQL_SELECT_WORK_REPEAT_INTERVAL_PREFIX = "SELECT * FROM work_repeat_interval_";
	
	public void createWorkRepeatInterval (final WorkRepeatInterval workRepeatInterval, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO work_repeat_interval_" + masterUserId
	                + SQL_INSERT_WORK_REPEAT_INTERVAL_POSTFIX,
	                workRepeatInterval.getWorkRepeatIntervalId(), 
	                workRepeatInterval.getRepeatIntervalName(),
	                workRepeatInterval.getRepeatIntervalMinutes());
	}
	
	public List<WorkRepeatInterval> getAllWorkRepeatInterval(final int masterUserId) {
        List<WorkRepeatInterval> allWorkRepeatInterval = this.getJdbcTemplate().query(
        		SQL_SELECT_WORK_REPEAT_INTERVAL_PREFIX + masterUserId, new Object[] {},       		
            new WorkRepeatIntervalMapper());

        return allWorkRepeatInterval;
    }
	
	 /**
     * create CUSTOMER_WORK_STATUS_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`work_repeat_interval_ID` tinyint NOT NULL,");
	        sb.append("`repeat_Interval_name` varchar(100) NOT NULL,");
	        sb.append("`repeat_Interval_minutes` int NOT NULL,");
	        sb.append("PRIMARY KEY (`work_repeat_interval_ID`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertWorkRepeatInterval(tableName);
	 }
	 
	 private void insertWorkRepeatInterval(String tableName) {
	        String sql = "insert into "+tableName+" (work_repeat_interval_ID, repeat_Interval_name,repeat_Interval_minutes) "
	        		     + "VALUES (1, '4 hours',240),(2, '8 hours',480),"
	        		     + "(3, '12 hours',720),(4, '1 day',1440),"
	                     + "(5, '2 days',2880),(6, '3 days',4320),"
	                     + "(7, '1 week',10080),(8, '2 weeks',20160),"
	                     + "(9, '1 month',43200),(10, '2 months',86400)";
	        this.getJdbcTemplate().update(sql);
	 }
}
