package indi.ucm.jdbc.entry;

//for customers book

public class CustomerAccountItem {
    private long customerId;
    private long customerBusinessId;
    private int customerAccountType;
    private int customerAccountStatus;
    private String assignedStaffUser;
    private String firstName;
    private String lastName;
    private String cFirstName;
    private String cLastName;
    private String emailAddress;
    private String mobilePhone;
    private String businessName;
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getMobilePhone() {
		return mobilePhone;
	}
	public void setMobilePhone(String mobilePhone) {
		this.mobilePhone = mobilePhone;
	}
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public long getCustomerBusinessId() {
		return customerBusinessId;
	}
	public void setCustomerBusinessId(long customerBusinessId) {
		this.customerBusinessId = customerBusinessId;
	}
	public int getCustomerAccountType() {
		return customerAccountType;
	}
	public void setCustomerAccountType(int customerAccountType) {
		this.customerAccountType = customerAccountType;
	}
	public int getCustomerAccountStatus() {
		return customerAccountStatus;
	}
	public void setCustomerAccountStatus(int customerAccountStatus) {
		this.customerAccountStatus = customerAccountStatus;
	}
	public String getAssignedStaffUser() {
		return assignedStaffUser;
	}
	public void setAssignedStaffUser(String assignedStaffUser) {
		this.assignedStaffUser = assignedStaffUser;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getcFirstName() {
		return cFirstName;
	}
	public void setcFirstName(String cFirstName) {
		this.cFirstName = cFirstName;
	}
	public String getcLastName() {
		return cLastName;
	}
	public void setcLastName(String cLastName) {
		this.cLastName = cLastName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
}
