package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.CustomerWorkTemplate;
import indi.ucm.jdbc.mapper.CustomerWorkMapper;
import indi.ucm.jdbc.mapper.CustomerWorkTemplateMapper;
import indi.ucm.jdbc.mapper.WorkLocationTypeMapper;

import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerWorkTemplateDao extends JdbcDaoSupport {
	private final  String SQL_INSERT_WORK_TEMPLATE_POSTFIX = 
			 "(customer_work_template_ID,"+" template_name,"+ " template_section_ID, "+" work_name,"
            + " assigned_staff_user, "+ "schedule_start_date, "+ "schedule_end_date, "
    		+ "schedule_start_time, "+ "schedule_end_time, "+ "work_repeat_interval, "
    		+ "work_time_duration, "+ "work_location_type, "+ "work_client_contact,"
    		+" work_description,"+ "work_billable,"+ " wrok_billing_rate,"
    		+ "work_reminder_notify_staff,"
    		+ " work_reminder_notify_staff_time,"+ " work_reminder_notify_staff_method, "
    		+ "work_reminder_notify_customer, "+ "work_reminder_notify_customer_time,"
    		+ "work_reminder_notify_customer_method, "+ "work_reminder_message) "

    		+ "VALUES (?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private final  String SQL_SELECT_WORK_TEMPLATE_PREFIX = 
    		 "select customer_work_template_ID,"+" template_name,"
            + " template_section_ID, "+" work_name,"
            + " assigned_staff_user, "+ "schedule_start_date, "+ "schedule_end_date, "
     		+ "schedule_start_time, "+ "schedule_end_time, "+ "work_repeat_interval, "
     		+ "work_time_duration, "+ "work_location_type, "+ "work_client_contact,"
     		+" work_description,"+ "work_billable,"+ " wrok_billing_rate,"
     		+ "work_reminder_notify_staff,"
     		+ " work_reminder_notify_staff_time,"+ " work_reminder_notify_staff_method, "
     		+ "work_reminder_notify_customer, "+ "work_reminder_notify_customer_time,"
     		+ "work_reminder_notify_customer_method, "+ "work_reminder_message from customer_work_template_";
     		
    private final  String SQL_SELECT_WORK_TEMPLATE_POSTFIX = " where customer_work_template_ID = ?";
    
    private final  String SQL_UPDATE_WORK_TEMPLATE_POSTFIX = " ";
    
    private final  String SQL_SELECT_ALL_TEMPLATE_NAME = "select distinct template_name from customer_work_template_";

    /**
     * create customer work
     * 
     * @param StaffUser
     */
    public void createCustomerWorkTemplate(final CustomerWorkTemplate customerWorkTemplate, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_work_template_" + masterUserId + SQL_INSERT_WORK_TEMPLATE_POSTFIX,
            customerWorkTemplate.getCustomerWorkTemplateId(),customerWorkTemplate.getTemplateName(),
            customerWorkTemplate.getTemplateSectionId(),customerWorkTemplate.getWorkName(),
            customerWorkTemplate.getAssignStaffUser(),
            customerWorkTemplate.getScheduleStartDate(),customerWorkTemplate.getScheduleEndDate(),
            customerWorkTemplate.getScheduleStartTime(),customerWorkTemplate.getScheduleEndTime(),
            customerWorkTemplate.getWorkRepeatInterval(),customerWorkTemplate.getWorkTimeDuration(),
            customerWorkTemplate.getWorkLocationType(),customerWorkTemplate.getCustomerID(),
            customerWorkTemplate.getWorkDescription(),customerWorkTemplate.getWorkBillable(),
            customerWorkTemplate.getWorkBillingRate(),customerWorkTemplate.getWorkReminderNotifyStaff(),
            customerWorkTemplate.getWorkReminderNotifyStaffTime(),customerWorkTemplate.getWorkReminderNotifyStaffMethod(),
            customerWorkTemplate.getWorkReminderNotifyCustomer(),customerWorkTemplate.getWorkReminderNotifyCustomerTime(),
            customerWorkTemplate.getWorkReminderNotifyCustomerMethod(),customerWorkTemplate.getWorkReminderMessage());
    }
    
    public List<String> getAllWorkTemplates (int masterUserId){
    	List<String> allWorkTemplates = this.getJdbcTemplate().queryForList(
    			SQL_SELECT_ALL_TEMPLATE_NAME+ masterUserId,String.class);	
    	return  allWorkTemplates; 	
    }
 
    
    public List<CustomerWorkTemplate > getTemplateDetail(String templateName,int masterUserId){
    	List<CustomerWorkTemplate> templatedetail = this.getJdbcTemplate().query(
    			SQL_SELECT_WORK_TEMPLATE_PREFIX + masterUserId+ " where template_name = ?",
                new Object[] {templateName}, new CustomerWorkTemplateMapper());
        return  templatedetail;
    }
    
    /**
     * create customer_work_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_work_template_ID` int NOT NULL,");
        sb.append("`template_name` varchar(100) NOT NULL,");
        sb.append("`template_section_ID` smallint NOT NULL,");     
        sb.append("`work_name` varchar(100) NOT NULL,");
        sb.append("`assigned_staff_user` int  NOT NULL,");
        sb.append("`schedule_start_date` date,");
        sb.append("`schedule_end_date` date,");
        sb.append("`schedule_start_time` time,");
        sb.append("`schedule_end_time` time,");
        sb.append("`work_repeat_interval` tinyint,");
        sb.append("`work_time_duration` tinyint,");
        sb.append("`work_location_type` tinyint,");
        sb.append("`work_client_contact` int,");
        sb.append("`work_description` varchar(2000),");
        sb.append("`work_billable` tinyint,");
        sb.append("`wrok_billing_rate` smallint,");
        sb.append("`work_reminder_notify_staff` tinyint,");
        sb.append("`work_reminder_notify_staff_time` tinyint,");
        sb.append("`work_reminder_notify_staff_method` varchar(10),");
        sb.append("`work_reminder_notify_customer` tinyint,");
        sb.append("`work_reminder_notify_customer_time` int,");
        sb.append("`work_reminder_notify_customer_method` varchar(10),");
        sb.append("`work_reminder_message` varchar(1000),");
        sb.append("PRIMARY KEY (`customer_work_template_ID`,`template_section_ID`))character set = utf8;");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<CustomerWorkTemplate> getWorkTemplateByID(int workTemplateID,int masterUserId){
    	try {
    		List<CustomerWorkTemplate> customerWorkTemplate = this.getJdbcTemplate().query(
    				SQL_SELECT_WORK_TEMPLATE_PREFIX + masterUserId
							+ SQL_SELECT_WORK_TEMPLATE_POSTFIX,
					new Object[] { workTemplateID }, new CustomerWorkTemplateMapper());
			return customerWorkTemplate;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
    }
   
}
