package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.CustomerInvoiceStatus;
import indi.ucm.jdbc.entry.WorkTimeDuration;
import indi.ucm.jdbc.mapper.CustomerInvoiceStatusMapper;
import indi.ucm.jdbc.mapper.WorkTimeDurationMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerInvoiceStatusDao extends JdbcDaoSupport {
	private final  String SQL_INSERT_CUSTOMER_INVOICE_STATUS_POSTFIX = " (invoice_status_ID, invoice_status_name) VALUES (?, ?)";
	private final  String SQL_SELECT_CUSTOMER_INVOICE_STATUS_PREFIX = "SELECT * FROM customer_invoice_status_";
	
	
	public void createInvoiceStatus (final CustomerInvoiceStatus customerInvoiceStatus, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO customer_invoice_status_" + masterUserId
	                + SQL_INSERT_CUSTOMER_INVOICE_STATUS_POSTFIX,
	                customerInvoiceStatus.getInvoiceStatusId(),
	                customerInvoiceStatus.getInvoiceStatusName());
	}
	
	public List<CustomerInvoiceStatus> getAllInvoiceStatus(final int masterUserId) {
        List<CustomerInvoiceStatus> allInvoiceStatus = this.getJdbcTemplate().query(
        		SQL_SELECT_CUSTOMER_INVOICE_STATUS_PREFIX + masterUserId, new Object[] {},       		
            new CustomerInvoiceStatusMapper());

        return allInvoiceStatus;
    }
	
	 /**
     * create customer_invoice_status_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`invoice_status_ID` tinyint NOT NULL,");
	        sb.append("`invoice_status_name` varchar(100) NOT NULL,");
	        sb.append("PRIMARY KEY (`invoice_status_ID`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertInvoiceStatus(tableName);
	 }
	 
	 private void insertInvoiceStatus(String tableName) {
	        String sql = "insert into "+tableName+" (invoice_status_ID, invoice_status_name) "
	        		     + "VALUES (1, 'created'),(2, 'sent first notice'),(3, 'sent second notice'),"
	        		     + "(4, 'sent third notice'),(5, 'paid')";
	        this.getJdbcTemplate().update(sql);
	 }
}
