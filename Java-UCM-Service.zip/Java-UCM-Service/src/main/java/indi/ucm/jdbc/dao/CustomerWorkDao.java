package indi.ucm.jdbc.dao;

import java.util.ArrayList;
import java.util.List;

import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.StaffUserBaseInfo;
import indi.ucm.jdbc.entry.WorkBookItem;
import indi.ucm.jdbc.mapper.CustomerWorkMapper;


import indi.ucm.jdbc.mapper.StaffUserBaseInfoMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;



public class CustomerWorkDao extends JdbcDaoSupport {
	
    private final  String SQL_INSERT_ONE_CUSTOMER_WORK_POSTFIX = " (work_name,"+" customer_work_ID,"+ " customer_ID, "+ "work_status,"
            + " assigned_staff_user, "+ "schedule_start_date, "+ "schedule_end_date, "
    		+ "schedule_start_time, "+ "schedule_end_time, "+ "work_repeat_interval, "
    		+ "work_time_duration, "+ "work_location_type, "+ "work_description,"
    		+ "work_billable,"+ " wrok_billing_rate,"
    		+ " billing_currency_ID, "+ "work_reminder_notify_staff,"
    		+ " work_reminder_notify_staff_time,"+ " work_reminder_notify_staff_method, "
    		+ "work_reminder_notify_customer, "+ "work_reminder_notify_customer_time,"
    		+ "work_reminder_notify_customer_method, "+ "work_reminder_message) "
    	//	+ "actual_complete_date, "+ "actual_complete_time) " 暂时不用  
    		+ "VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private final  String SQL_SELECT_CUSTOMER_WORK_PREFIX = " select work_name,"+" customer_work_ID,"+ " customer_ID, "+ "work_status,"
            + " assigned_staff_user, "+ "schedule_start_date, "+ "schedule_end_date, "
    		+ "schedule_start_time, "+ "schedule_end_time, "+ "work_repeat_interval, "
    		+ "work_time_duration, "+ "work_location_type, "+ "work_description,"
    		+ "work_billable,"+ " wrok_billing_rate,"
    		+ " billing_currency_ID, "+ "work_reminder_notify_staff,"
    		+ " work_reminder_notify_staff_time,"+ " work_reminder_notify_staff_method, "
    		+ "work_reminder_notify_customer, "+ "work_reminder_notify_customer_time,"
    		+ "work_reminder_notify_customer_method, "+ "work_reminder_message, "
    		+ "actual_complete_date, "+ "actual_complete_time from  customer_work_";
    private final  String SQL_SELECT_CUSTOMER_WORK_POSTFIX = " where customer_work_ID = ?";
    private final  String SQL_SELECT_ASSIGN_STAFF_POSTFIX = " where assigned_staff_user = ?";
    
    private final  String SQL_UPDATE_CUSTOMER_WORK_POSTFIX = " set work_name = ?,"+ "work_status = ?,"+ " customer_ID = ?,"
            + " assigned_staff_user = ? , "+ "schedule_start_date = ?, "+ "schedule_end_date = ?, "
    		+ "schedule_start_time = ?, "+ "schedule_end_time = ?, "+ "work_repeat_interval = ?, "
    		+ "work_time_duration = ?, "+ "work_location_type = ?, "+ "work_description = ?,"
    		+ "work_billable = ?,"+ " wrok_billing_rate = ?,"
    		+ " billing_currency_ID = ?, "+ "work_reminder_notify_staff = ?,"
    		+ " work_reminder_notify_staff_time = ?,"+ " work_reminder_notify_staff_method = ?, "
    		+ "work_reminder_notify_customer = ?, "+ "work_reminder_notify_customer_time = ?,"
    		+ "work_reminder_notify_customer_method = ?, "+ "work_reminder_message = ?";

    
    private final String SQL_DELETE_WORK_PREFIX = "delete from customer_work_";
    /**
     * create customer work
     * 
     * @param StaffUser
     */
    public void createCustomerWork(final CustomerWork customerWork, final int masterUserId) {
        this.getJdbcTemplate().update(
            "INSERT INTO customer_work_" + masterUserId + SQL_INSERT_ONE_CUSTOMER_WORK_POSTFIX,
            customerWork.getWorkName(),
            customerWork.getCustomerWorkId(), customerWork.getCustomerId(), customerWork.getWorkStatus(),
            customerWork.getAssignedStaffUser(), customerWork.getScheduleStartDate(), customerWork.getScheduleEndDate(),
            customerWork.getScheduleStartTime(), customerWork.getScheduleEndTime(), customerWork.getWorkRepeatInterval(),
            customerWork.getWorkTimeDuration(), customerWork.getWorkLocationType(), customerWork.getWorkDescription(),
            customerWork.getWorkBillable(), customerWork.getWorkBillingRate(),
            customerWork.getBillingCurrencyId(), customerWork.getWorkReminderNotifyStaff(),
            customerWork.getWorkReminderNotifyStaffTime(), customerWork.getWorkReminderNotifyStaffMethod(),
            customerWork.getWorkReminderNotifyCustomer(), customerWork.getWorkReminderNotifyCustomerTime(),
            customerWork.getWorkReminderNotifyCustomerMethod(), customerWork.getWorkReminderMessage());
    }
    
    
    public void modifyWork(final CustomerWork customerWork, final int masterUserId) {
    	//TODO
    	this.getJdbcTemplate().update(
				"UPDATE customer_work_" + masterUserId
				+SQL_UPDATE_CUSTOMER_WORK_POSTFIX+SQL_SELECT_CUSTOMER_WORK_POSTFIX,
				customerWork.getWorkName(),customerWork.getWorkStatus(),customerWork.getCustomerId(),
				customerWork.getAssignedStaffUser(), customerWork.getScheduleStartDate(), customerWork.getScheduleEndDate(),
	            customerWork.getScheduleStartTime(), customerWork.getScheduleEndTime(), customerWork.getWorkRepeatInterval(),
	            customerWork.getWorkTimeDuration(), customerWork.getWorkLocationType(), customerWork.getWorkDescription(),
	            customerWork.getWorkBillable(), customerWork.getWorkBillingRate(),
	            customerWork.getBillingCurrencyId(), customerWork.getWorkReminderNotifyStaff(),
	            customerWork.getWorkReminderNotifyStaffTime(), customerWork.getWorkReminderNotifyStaffMethod(),
	            customerWork.getWorkReminderNotifyCustomer(), customerWork.getWorkReminderNotifyCustomerTime(),
	            customerWork.getWorkReminderNotifyCustomerMethod(), customerWork.getWorkReminderMessage(),customerWork.getCustomerWorkId());
    }
    
    public List<CustomerWork> getAllWorkItems (int masterUserId,int staffId){
    	List<CustomerWork> customerWorks = null;
    	if(staffId == -1){
    		customerWorks = this.getJdbcTemplate().query(
        			SQL_SELECT_CUSTOMER_WORK_PREFIX
    						+ masterUserId, new Object[] {},
    				new CustomerWorkMapper());
    	}else{
    		customerWorks = this.getJdbcTemplate().query(
        			SQL_SELECT_CUSTOMER_WORK_PREFIX
    						+ masterUserId+SQL_SELECT_ASSIGN_STAFF_POSTFIX, new Object[] {staffId},
    				new CustomerWorkMapper());
    	}	
    	
    	return  customerWorks;
    	
    	
    }
    
    public void deleteWork( String workId,int masterUserId){
    	this.getJdbcTemplate().update(
    			SQL_DELETE_WORK_PREFIX+ masterUserId +SQL_SELECT_CUSTOMER_WORK_POSTFIX, new Object[] {workId});
    }

    /**
     * create customer_work_[postfix] table
     * 
     * @param tableName
     */
    public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`work_name` varchar(100) NOT NULL,");
        sb.append("`customer_work_ID` bigint NOT NULL,");
        sb.append("`customer_ID` bigint NOT NULL,");
        sb.append("`work_status` tinyint  NOT NULL,");
        sb.append("`assigned_staff_user` int  NOT NULL,");
        sb.append("`schedule_start_date` date  NOT NULL,");
        sb.append("`schedule_end_date` date  NOT NULL,");
        sb.append("`schedule_start_time` time  NOT NULL,");
        sb.append("`schedule_end_time` time  NOT NULL,");
        sb.append("`work_repeat_interval` tinyint  NOT NULL,");
        sb.append("`work_time_duration` tinyint  NOT NULL,");
        sb.append("`work_location_type` tinyint  NOT NULL,");
        sb.append("`work_description` varchar(2000)  NOT NULL,");
        sb.append("`work_billable` tinyint  NOT NULL,");
        sb.append("`wrok_billing_rate` smallint  NOT NULL,");
        sb.append("`billing_currency_ID` smallint,");
        sb.append("`work_reminder_notify_staff` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_staff_time` tinyint,");
        sb.append("`work_reminder_notify_staff_method` tinyint,");
        sb.append("`work_reminder_notify_customer` tinyint  NOT NULL,");
        sb.append("`work_reminder_notify_customer_time` int,");
        sb.append("`work_reminder_notify_customer_method` int,");
        sb.append("`work_reminder_message` varchar(1000)  NOT NULL,");
        sb.append("`actual_complete_date` date  ,");
        sb.append("`actual_complete_time` time  ,");
        sb.append("PRIMARY KEY (`customer_work_ID`))character set = utf8;");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public CustomerWork getWorkByID(int customerWorkID,int masterUserId){
    	try {
    		CustomerWork customerWork = this.getJdbcTemplate().queryForObject(
					SQL_SELECT_CUSTOMER_WORK_PREFIX + masterUserId
							+ SQL_SELECT_CUSTOMER_WORK_POSTFIX,
					new Object[] { customerWorkID }, new CustomerWorkMapper());
			return customerWork;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
    }
}


