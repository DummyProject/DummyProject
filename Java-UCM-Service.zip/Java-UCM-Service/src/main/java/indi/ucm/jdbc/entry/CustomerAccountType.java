package indi.ucm.jdbc.entry;

// Info of customer account type
public class CustomerAccountType {
    private int customerAccountTypeId;
    private String accountTypeName;

    /**
     * @return the customerAccountTypeId
     */
    public int getCustomerAccountTypeId() {
        return this.customerAccountTypeId;
    }

    /**
     * @param customerAccountTypeId
     *            the customerAccountTypeId to set
     */
    public void setCustomerAccountTypeId(final int customerAccountTypeId) {
        this.customerAccountTypeId = customerAccountTypeId;
    }

    /**
     * @return the accountTypeName
     */
    public String getAccountTypeName() {
        return this.accountTypeName;
    }

    /**
     * @param accountTypeName
     *            the accountTypeName to set
     */
    public void setAccountTypeName(final String accountTypeName) {
        this.accountTypeName = accountTypeName;
    }
}
