package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.WorkLocationType;
import indi.ucm.jdbc.entry.WorkTimeDuration;
import indi.ucm.jdbc.mapper.WorkLocationTypeMapper;
import indi.ucm.jdbc.mapper.WorkTimeDurationMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class WorkLocationTypeDao extends JdbcDaoSupport{
	private final  String SQL_INSERT_WORK_LOCATION_TYPE_POSTFIX = " (work_location_type, location_type) VALUES (?, ?)";
	private final  String SQL_SELECT_WORK_LOCATION_TYPE_PREFIX = "SELECT * FROM work_location_type_";
	private final  String SQL_SELECT_WORK_LOCATION_TYPE_BY_ID_POSTFIX = " where work_location_type = ?";
	
	
	public void createCustomerAccountStatus (final WorkLocationType workLocationType, final int masterUserId) {
		this.getJdbcTemplate().update(
	            "INSERT INTO work_location_type_" + masterUserId
	                + SQL_INSERT_WORK_LOCATION_TYPE_POSTFIX,
	                workLocationType.getWorkLocationType(), 
	                workLocationType.getLocationType());
	}
	
	public List<WorkLocationType> getAllWorkLocationType(final int masterUserId) {
        List<WorkLocationType> allWorkLocationType = this.getJdbcTemplate().query(
        		SQL_SELECT_WORK_LOCATION_TYPE_PREFIX + masterUserId, new Object[] {}, new WorkLocationTypeMapper());

        return allWorkLocationType;
    }
	
	public String getLocationTypeByID(int locationTypeID ,int masterUserId) {
		WorkLocationType workLocationType = this.getJdbcTemplate().queryForObject(
				SQL_SELECT_WORK_LOCATION_TYPE_PREFIX + masterUserId+SQL_SELECT_WORK_LOCATION_TYPE_BY_ID_POSTFIX, 
        		new Object[] { locationTypeID },       		
            new WorkLocationTypeMapper());
		
		return workLocationType.getLocationType();
	}

	
	 /**
     * create CUSTOMER_WORK_STATUS_[postfix] table
     * 
     * @param tableName
     */
	 public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`work_location_type` tinyint NOT NULL,");
	        sb.append("`location_type` varchar(100) NOT NULL,");
	        sb.append("PRIMARY KEY (`work_location_type`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertWorkStatus(tableName);
	 }
	 
	 private void insertWorkStatus(String tableName) {
	        String sql = "insert into "+tableName+" (work_location_type, location_type) "
	        		     + "VALUES (1, 'staff office'),(2, 'customer office'),(3, 'customer site')";
	        this.getJdbcTemplate().update(sql);
	 }
}
