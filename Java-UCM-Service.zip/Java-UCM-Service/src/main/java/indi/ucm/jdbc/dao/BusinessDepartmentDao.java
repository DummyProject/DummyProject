package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.BusinessDepartment;
import indi.ucm.jdbc.entry.CustomerAccountStatus;
import indi.ucm.jdbc.mapper.BusinessDepartmentMapper;
import indi.ucm.jdbc.mapper.CustomerAccountStatusMapper;

import java.util.List;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class BusinessDepartmentDao extends JdbcDaoSupport{
	    private final static String SQL_INSERT_BUSINESS_DEPARTMENT_POSTFIX = " (business_department_ID, business_department_name) VALUES (?, ?)";
	    private final static String SQL_SELECT_BUSINESS_DEPARTMENT_PREFIX = "SELECT * FROM business_department_";

	    /**
	     * create customer account
	     * 
	     * @param CustomerAccountStatus
	     */
	    public void createBusinessDepartment(final BusinessDepartment businessDepartment, final int masterUserId) {
	        this.getJdbcTemplate().update(
	            "INSERT INTO business_department_" + masterUserId
	                + SQL_INSERT_BUSINESS_DEPARTMENT_POSTFIX,
	                businessDepartment.getBusinessDepartmentId(), businessDepartment.getBusinessDepartmentName());
	    }

	    public List<BusinessDepartment> getBusinessDepartment(final int masterUserId) {
	        List<BusinessDepartment> cass = this.getJdbcTemplate().query(
	        		SQL_SELECT_BUSINESS_DEPARTMENT_PREFIX + masterUserId, new Object[] {},
	            new BusinessDepartmentMapper());

	        return cass;
	    }

	    /**
	     * create BUSINESS_DEPARTMENT_[postfix] table
	     * 
	     * @param tableName
	     */
	    public void createTable(final String tableName) {
	        StringBuffer sb = new StringBuffer("");
	        sb.append("CREATE TABLE `" + tableName + "` (");
	        sb.append("`business_department_ID` tinyint NOT NULL,");
	        sb.append("`business_department_name` varchar(100) NOT NULL,");
	        sb.append("PRIMARY KEY (`business_department_ID`))character set = utf8;");
	        try {
	            this.getJdbcTemplate().update(sb.toString());
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        insertBusinessDepartment(tableName);
	    }

	    private void insertBusinessDepartment(String tableName) {
	        String sql = "insert into "+tableName+" (business_department_ID, business_department_name)"
	        		+ " VALUES (1, 'sales'),(2, 'marketing'),(3, 'finance'),(4, 'technical support'),(5, 'customer service'),"
	        		+ "(6, 'administrative')";
	        this.getJdbcTemplate().update(sql);
	    }
}
