package indi.ucm.jdbc.entry;

public class WorkBookItem {
	private long customerWorkId;
	private String workName;
	private String workStatus;
	private String assignedStaffUser;
	private String datetime;
	private String workTimeDuration;
	private String workLocationType;
	private String client;
	private String workReminderMessage;
	private String workBillable;
	private String workBillingRate;
	
	public long getCustomerWorkId() {
		return customerWorkId;
	}
	public void setCustomerWorkId(long customerWorkId) {
		this.customerWorkId = customerWorkId;
	}
	public String getWorkName() {
		return workName;
	}
	public void setWorkName(String workName) {
		this.workName = workName;
	}
	public String getWorkStatus() {
		return workStatus;
	}
	public void setWorkStatus(String workStatus) {
		this.workStatus = workStatus;
	}
	public String getAssignedStaffUser() {
		return assignedStaffUser;
	}
	public void setAssignedStaffUser(String assignedStaffUser) {
		this.assignedStaffUser = assignedStaffUser;
	}
	public String getDatetime() {
		return datetime;
	}
	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}
	public String getWorkTimeDuration() {
		return workTimeDuration;
	}
	public void setWorkTimeDuration(String workTimeDuration) {
		this.workTimeDuration = workTimeDuration;
	}
	public String getWorkLocationType() {
		return workLocationType;
	}
	public void setWorkLocationType(String workLocationType) {
		this.workLocationType = workLocationType;
	}
	public String getClient() {
		return client;
	}
	public void setClient(String client) {
		this.client = client;
	}
	public String getWorkReminderMessage() {
		return workReminderMessage;
	}
	public void setWorkReminderMessage(String workReminderMessage) {
		this.workReminderMessage = workReminderMessage;
	}
	public String getWorkBillable() {
		return workBillable;
	}
	public void setWorkBillable(String workBillable) {
		this.workBillable = workBillable;
	}
	public String getWorkBillingRate() {
		return workBillingRate;
	}
	public void setWorkBillingRate(String workBillingRate) {
		this.workBillingRate = workBillingRate;
	}

}
