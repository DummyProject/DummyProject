package indi.ucm.jdbc.dao;

import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class CustomerGroupNotficationDao extends JdbcDaoSupport {
	
	public void createTable(final String tableName) {
        StringBuffer sb = new StringBuffer("");
        sb.append("CREATE TABLE `" + tableName + "` (");
        sb.append("`customer_group_notification_ID` bigint NOT NULL,");
        sb.append("`notification_name` varchar(100) NOT NULL,");
        sb.append("`description` varchar(2000),");     
        sb.append("`recipients` int NOT NULL,");
        sb.append("`schedule_send_date` date,");
        sb.append("`schedule_send_time` time,");
        sb.append("`email_subject_line` varchar(100),");
        sb.append("`email_content` text,");
        sb.append("`email_attachment_ID` bigint,");
        sb.append("`notification_status` varchar(20),");
        sb.append("`actual_send_date_time` datetime,");
        sb.append("PRIMARY KEY (`customer_group_notification_ID`))character set = utf8;");
        try {
            this.getJdbcTemplate().update(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
