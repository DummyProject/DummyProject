package indi.ucm.jdbc.entry;

// Info of customer invoice status
public class CustomerInvoiceStatus {
    private int invoiceStatusId;
    private String invoiceStatusName;

    /**
     * @return the invoiceStatusId
     */
    public int getInvoiceStatusId() {
        return this.invoiceStatusId;
    }

    /**
     * @param invoiceStatusId
     *            the invoiceStatusId to set
     */
    public void setInvoiceStatusId(final int invoiceStatusId) {
        this.invoiceStatusId = invoiceStatusId;
    }

    /**
     * @return the invoiceStatusName
     */
    public String getInvoiceStatusName() {
        return this.invoiceStatusName;
    }

    /**
     * @param invoiceStatusName
     *            the invoiceStatusName to set
     */
    public void setInvoiceStatusName(final String invoiceStatusName) {
        this.invoiceStatusName = invoiceStatusName;
    }
}
