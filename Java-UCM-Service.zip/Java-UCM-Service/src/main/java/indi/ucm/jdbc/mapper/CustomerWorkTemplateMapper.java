package indi.ucm.jdbc.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.CustomerWorkTemplate;

import org.springframework.jdbc.core.RowMapper;

public class CustomerWorkTemplateMapper implements RowMapper<CustomerWorkTemplate> {

	@Override
	 public CustomerWorkTemplate mapRow(final ResultSet rs, final int rowNum) throws SQLException {
		CustomerWorkTemplate cwt = new CustomerWorkTemplate();
		cwt.setWorkName(rs.getString("work_name"));
		cwt.setTemplateName(rs.getString("template_name"));
		cwt.setCustomerWorkTemplateId(rs.getInt("customer_work_template_ID"));
		cwt.setTemplateSectionId(rs.getInt("template_section_ID"));
		cwt.setAssignStaffUser(rs.getInt("assigned_staff_user"));
		cwt.setScheduleStartDate(rs.getString("schedule_start_date"));
		cwt.setScheduleEndDate(rs.getString("schedule_end_date"));
		cwt.setScheduleStartTime(rs.getString("schedule_start_time"));
		cwt.setScheduleEndTime(rs.getString("schedule_end_time"));
		cwt.setWorkRepeatInterval(rs.getInt("work_repeat_interval"));
		cwt.setWorkTimeDuration(rs.getInt("work_time_duration"));
		cwt.setWorkLocationType(rs.getInt("work_location_type"));
		cwt.setcCustomerID(rs.getInt("work_client_contact"));
		cwt.setWorkDescription(rs.getString("work_description"));
		cwt.setWorkBillable(rs.getInt("work_billable"));
        cwt.setWorkBillingRate(rs.getInt("wrok_billing_rate"));
        cwt.setWorkReminderNotifyStaff(rs.getInt("work_reminder_notify_staff"));
        cwt.setWorkReminderNotifyStaffTime(rs.getInt("work_reminder_notify_staff_time"));
        cwt.setWorkReminderNotifyStaffMethod(rs.getString("work_reminder_notify_staff_method"));
        cwt.setWorkReminderNotifyCustomer(rs.getInt("work_reminder_notify_customer"));
        cwt.setWorkReminderNotifyCustomerTime(rs.getInt("work_reminder_notify_customer_time"));
        cwt.setWorkReminderNotifyCustomerMethod(rs.getString("work_reminder_notify_customer_method"));
        cwt.setWorkReminderMessage(rs.getString("work_reminder_message"));

        return cwt;
    }

}
