package indi.ucm.jdbc.mapper;



import java.sql.ResultSet;
import java.sql.SQLException;

import indi.ucm.jdbc.entry.CustomerWorkInvoice;

import org.springframework.jdbc.core.RowMapper;

public class CustomerWorkInvoiceMapper implements RowMapper<CustomerWorkInvoice> {
	public CustomerWorkInvoice mapRow(final ResultSet rs, final int rowNum) throws SQLException {
		CustomerWorkInvoice ci = new CustomerWorkInvoice();
        ci.setCustomerWorkInvoiceId(rs.getInt("customer_work_invoice_ID"));
        ci.setCustomerId(rs.getInt("customer_ID"));
        ci.setCustomerName(rs.getString("customer_name"));
        ci.setInvoiceDate(rs.getDate("invoice_date"));
        ci.setInvoiceTotalAmount(rs.getDouble("invoice_total_amount"));
        ci.setBillingAddressStreet(rs.getString("billing_address_street"));
        ci.setBillingAddressRoomNumber(rs.getString("billing_address_room_number"));
        ci.setBillingAddressCity(rs.getString("billing_address_city"));
        ci.setBillingAddressStateProvince(rs.getString("billing_address_state_province"));
        ci.setBillingAddressCountry(rs.getInt("billing_addresss_country"));
        ci.setUserNote(rs.getString("customer_name"));
        ci.setInvoiceStatus(rs.getInt("invoice_status"));
        ci.setReceivedPaymentId(rs.getInt("received_payment_ID"));
        return ci;
    }
}
