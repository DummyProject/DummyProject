package indi.ucm.jdbc.dao;

import indi.ucm.jdbc.entry.BusinessType;
import indi.ucm.jdbc.entry.Country;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.MasterUserList;
import indi.ucm.jdbc.entry.StaffUserBaseInfo;
import indi.ucm.jdbc.entry.TimeZone;
import indi.ucm.jdbc.mapper.BusinessTypeMapper;
import indi.ucm.jdbc.mapper.CountryMapper;
import indi.ucm.jdbc.mapper.MasterUserListMapper;
import indi.ucm.jdbc.mapper.MasterUserMapper;
import indi.ucm.jdbc.mapper.StaffUserBaseInfoMapper;
import indi.ucm.jdbc.mapper.TimeZoneMapper;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

public class MasterUserListDao extends JdbcDaoSupport {
	private final static String SQL_SELECT_ONE_MASTER_USER_LIST = "SELECT * FROM master_user_list where master_user_ID = ?";
	private final static String SQL_INSERT_ONE_MASTER_USER_LIST = "INSERT INTO master_user_list (master_user_ID, account_service_plan, account_status, account_created_date_time, account_billing_ID, database_table_name_postfix, description, username) VALUES (?, 1, 1, ?, NULL, ?, NULL, ?)";
	private final static String SQL_SELECT_BUSINESS_TYPES = "SELECT * FROM business_type";
	private final static String SQL_SELECT_COUNRTY = "SELECT * FROM country";
	private final static String SQL_SELECT_TIMEZONE = "SELECT * FROM timezones";
	private final static String SQL_SELECT_MASTER_USER_LIST_BY_NAME = "SELECT * FROM master_user_list where username = ?";
	private final static String SQL_SELECT_MASTER_USER_LIST_BY_BUSINESS = "SELECT * FROM master_user_list where master_user_business_ID = ?";
	private final static String SQL_ADD_MASTER_USER_BUSINESS_ID = "update master_user_list set master_user_business_ID = ? where master_user_ID = ?";

	public MasterUserList getMasterUserList(final long masterUserId) {
		try {
			MasterUserList mul = this.getJdbcTemplate().queryForObject(
					MasterUserListDao.SQL_SELECT_ONE_MASTER_USER_LIST, new Object[] { masterUserId },
					new MasterUserListMapper());
			return mul;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public MasterUserList getMasterUserListByName(final String userName) {
		try {
			MasterUserList mul = this.getJdbcTemplate().queryForObject(
					MasterUserListDao.SQL_SELECT_MASTER_USER_LIST_BY_NAME, new Object[] { userName },
					new MasterUserListMapper());
			return mul;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public MasterUserList getMasterUserListByBusiness(final int masterUserBusinessId) {
		try {
			MasterUserList mul = this.getJdbcTemplate().queryForObject(
					MasterUserListDao.SQL_SELECT_MASTER_USER_LIST_BY_BUSINESS, new Object[] { masterUserBusinessId },
					new MasterUserListMapper());
			return mul;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public void createMasterUserList(final MasterUserList masterUserList) {
		this.getJdbcTemplate().update(MasterUserListDao.SQL_INSERT_ONE_MASTER_USER_LIST,
				masterUserList.getMasterUserId(), new Timestamp(System.currentTimeMillis()),
				masterUserList.getMasterUserId(), masterUserList.getUserName());
	}

	public List<BusinessType> getBusinessTypes() {
		List<BusinessType> bts = this.getJdbcTemplate().query(MasterUserListDao.SQL_SELECT_BUSINESS_TYPES,
				new Object[] {}, new BusinessTypeMapper());

		return bts;
	}

	public List<Country> getCountries() {
		List<Country> cs = this.getJdbcTemplate().query(MasterUserListDao.SQL_SELECT_COUNRTY, new Object[] {},
				new CountryMapper());

		return cs;
	}

	public List<TimeZone> getTimeZones() {
		List<TimeZone> tzs = this.getJdbcTemplate().query(MasterUserListDao.SQL_SELECT_TIMEZONE, new Object[] {},
				new TimeZoneMapper());

		return tzs;
	}

	/**
	 * check whether the user name is registered
	 * 
	 * @param userName
	 */
	public boolean isUniqueUserName(final String userName) {

		try {
			MasterUserList mul = this.getJdbcTemplate().queryForObject(
					MasterUserListDao.SQL_SELECT_MASTER_USER_LIST_BY_NAME, new Object[] { userName },
					new MasterUserListMapper());
			return false;
		} catch (EmptyResultDataAccessException e) {
			return true;
		}
	}

	public void addMasterUserBusinessId(final int masterUserId, final int masterUserBusinessId) {
		this.getJdbcTemplate().update(MasterUserListDao.SQL_ADD_MASTER_USER_BUSINESS_ID, masterUserBusinessId,
				masterUserId);
	}
	
	public int getMasterId(String userName,String businessId){
		int masterId = 0;
		if(businessId!=null && businessId.length()>1){
			masterId = this.getMasterUserListByBusiness(Integer.parseInt(businessId)).getMasterUserId();
		}else{
			masterId =getMasterUserListByName(userName).getMasterUserId();
		}
		return masterId;
	}

	public void sync() {
		List<MasterUserList> muls = this.getJdbcTemplate().query("select * from master_user_list", new Object[] {},
				new MasterUserListMapper());
		for (int i = 0; i < muls.size(); i++) {
			MasterUserList mul = (MasterUserList) muls.get(i);
			int masterUserId = mul.getMasterUserId();
			MasterUser mu = this.getJdbcTemplate().queryForObject(
					"SELECT * FROM master_user_" + masterUserId + " where master_user_ID = ?",
					new Object[] { masterUserId }, new MasterUserMapper());
			addMasterUserBusinessId(masterUserId,mu.getMasterUserBusinessId());
		}
	}

}
