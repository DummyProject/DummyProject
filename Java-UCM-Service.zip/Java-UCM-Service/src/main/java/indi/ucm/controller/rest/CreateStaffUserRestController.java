package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.StaffUser;
import indi.ucm.jdbc.entry.StaffUserBaseInfo;
import indi.ucm.security.common.EncryptionDecryption;
import indi.ucm.security.common.GenerateRandomIdHelper;

import java.sql.Timestamp;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CreateStaffUserRestController {

	// Service which will do all data retrieval/manipulation work
	@Autowired
	MasterUserDao masterUserDao;
	@Autowired
	MasterUserListDao masterUserListDao;
	@Autowired
	StaffUserDao staffUserDao;

	// -------------------Create a staff user-----------------------
	@RequestMapping(value = "/CreateStaffUser", method = RequestMethod.POST)
	public ResponseEntity<String> createStaffUser(
			final HttpServletRequest request) {
		// store data from request
		String businessId = request.getParameter("businessId");
		String userName = request.getParameter("userName");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		try {
			storeParameters(request, masterUserId);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Duplicated user name",
					HttpStatus.SERVICE_UNAVAILABLE);
		}

		return new ResponseEntity<String>("Create staff user Successfully",
				HttpStatus.OK);
	}

	// -------------------Retrieve staff user------------
	@RequestMapping(value = "/staffUsers/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getStaffUsers(
			@PathVariable("userName") final String userName,@PathVariable("businessId") final String businessId) {
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List subis = this.staffUserDao.getStaffUsers(masterUserId);
		return new ResponseEntity<List>(subis, HttpStatus.OK);
	}

	// -------------------Retrieve staff user------------
	@RequestMapping(value = "/GetStaffUser", method = RequestMethod.POST)
	public ResponseEntity<StaffUserBaseInfo> getStaffUser(
			final HttpServletRequest request) {
		String businessId = request.getParameter("businessId");
		String userName = request.getParameter("userName");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		StaffUserBaseInfo subi;
		
		if(businessId!=null && businessId.length() >1){
			subi = staffUserDao.getStaffUserInfoByName(userName, masterUserId);
		}else{
			int staffUserId  = Integer.parseInt(request.getParameter("staffUserId"));
			subi = this.staffUserDao.getStaffUser(staffUserId,
					masterUserId);
		} 
		
		return new ResponseEntity<StaffUserBaseInfo>(subi, HttpStatus.OK);
	}

	/**
	 * retrieve data from request
	 * 
	 * @param request
	 * @param masterUserId2
	 * @throws Exception
	 */
	private void storeParameters(final HttpServletRequest request,
			final int masterUserId) throws Exception {
		Boolean isUniqueUserName = this.masterUserListDao
				.isUniqueUserName(request.getParameter("staffUserName"));
		if (isUniqueUserName) {
			Boolean isUniqueStaffUserName = this.staffUserDao.isUniqueUserName(
					request.getParameter("staffUserName"), masterUserId);
			if (isUniqueStaffUserName) {
				// store info of master user from request
				stroeStaffUserInfo(request, masterUserId);
			} else {
				throw new Exception("Duplicated user name");
			}
		} else {
			throw new Exception("Duplicated user name");
		}

	}

	/**
	 * generate staff user ID
	 * 
	 * @param masterUserId
	 * 
	 * @return
	 */
	private int generateStaffUserId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		int masterUserBusinessId = 0;
		boolean isUnique = false;
		while (!isUnique) {
			masterUserBusinessId = GenerateRandomIdHelper
					.generateRandomNumber(8);
			isUnique = isStaffUserUniqueId(masterUserBusinessId, masterUserId);
		}
		return masterUserBusinessId;
	}

	/**
	 * verify whether the staff user ID is unique
	 * 
	 * @param masterUserId
	 * 
	 * @param masterUserId
	 * @return
	 */
	private boolean isStaffUserUniqueId(final int staffUserId,
			final int masterUserId) {
		StaffUserBaseInfo staffUserBaseInfo = this.staffUserDao.getStaffUser(
				staffUserId, masterUserId);
		if (staffUserBaseInfo == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * store info of staff user business from request
	 * 
	 * @param request
	 * @param tableName
	 * @throws Exception
	 */
	private void stroeStaffUserInfo(final HttpServletRequest request,
			final int masterUserId) throws Exception {
		StaffUser staffUser = new StaffUser();
		int staffUserId = generateStaffUserId(masterUserId);
		staffUser.setStaffUserId(staffUserId);
		staffUser.setUsername(request.getParameter("staffUserName"));
		staffUser.setHashedPassword(EncryptionDecryption.encryptStr(request
				.getParameter("hashedPassword")));
		staffUser.setSecurityQuestion(request.getParameter("securityQuestion"));
		staffUser.setSecurityQuestionAnswer(EncryptionDecryption
				.encryptStr(request.getParameter("securityQuestionAnswer")));
		staffUser.setFirstName(request.getParameter("firstName"));
		staffUser.setLastName(request.getParameter("lastName"));
		staffUser.seteMailAddress(request.getParameter("eMailAddress"));
		staffUser.setMobilePhone(request.getParameter("phoneNumber"));
		staffUser.setOtherPhone(request.getParameter("otherPhone"));
		staffUser.setEnable2FactorAuthenticationLogin(Integer.parseInt(request
				.getParameter("enable2FactorAuthenticationLogin")));
		staffUser.setSendPasscodeToDeviceId(Integer.parseInt(request
				.getParameter("sendPasscodeToDeviceId")));
		MasterUser masterUser = this.masterUserDao.getMasterUser(masterUserId);
		staffUser.setMasterUserBusinessId(masterUser.getMasterUserBusinessId());
		staffUser.setJobTitle(request.getParameter("jobTitle"));
		staffUser.setBusinessDepartmentId(Integer.parseInt(request
				.getParameter("businessDepartmentId")));
		staffUser.setWorkTimeZone(Integer.parseInt(request
				.getParameter("workTimeZone")));
		staffUser.setWorkEmail(request.getParameter("workEmail"));
		staffUser.setOfficePhone(request.getParameter("officePhone"));
		staffUser.setOfficeAddressStreet(request
				.getParameter("officeAddressStreet"));
		staffUser.setOfficeAddressRoomNumber("N/A");
		staffUser.setOfficeAddressCity(request
				.getParameter("officeAddressCity"));
		staffUser.setOfficeAddressStateProvince(request
				.getParameter("officeAddressStateProvince"));
		staffUser.setOfficeAddressZipCode(request.getParameter("officeAddressZipCode"));
		staffUser.setOfficeAddressCountry(Integer.parseInt(request
				.getParameter("officeAddressCountry")));
		staffUser.setUserNote(request.getParameter("userNote"));
		staffUser.setCreatedDateTime(new Timestamp(System.currentTimeMillis()));

		this.staffUserDao.createStaffUser(staffUser, masterUserId);

	}
}
