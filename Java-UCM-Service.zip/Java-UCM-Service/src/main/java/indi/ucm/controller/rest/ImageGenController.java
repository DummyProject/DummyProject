package indi.ucm.controller.rest;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import indi.ucm.security.common.RandomValidateCode;

@Controller
public class ImageGenController {

	@RequestMapping(value = "/toImg")
	public String toImg() {

		return "image/image";
	}

	// reteive verification code
	@RequestMapping("/getVerificationCode")
	@ResponseBody
	public String getSysManageLoginCode(HttpServletResponse response,
			HttpServletRequest request) {
		response.setContentType("image/jpeg");
		response.setHeader("Pragma", "No-cache");// tell browser not to cache this content
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Set-Cookie", "name=value; HttpOnly");// set httponly to avoid Xss attack
		response.setDateHeader("Expire", 0);
		RandomValidateCode randomValidateCode = new RandomValidateCode();
		try {
			randomValidateCode.getRandcode(request, response, "imagecode");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}

	// check verification code
	@RequestMapping(value = "/checkVerificationCode", method = RequestMethod.POST)
	@ResponseBody
	public String checkTcode(
			@RequestParam(value = "code", required = false) String code,
			HttpServletRequest request, HttpServletResponse response) {

		// 1. retrieve code from session
		String sessionid = request.getSession().getId();
		String code1 = (String) request.getSession().getAttribute(
				sessionid + "imagecode");
		// 2: verify the code
		if (!StringUtils.isEmpty(code) && code.equals(code1)) {
			return "ok";

		}
		return "error";
	}

}
