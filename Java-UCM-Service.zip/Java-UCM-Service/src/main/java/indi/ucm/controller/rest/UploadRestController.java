package indi.ucm.controller.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;

import indi.ucm.security.common.S3Client;

@Controller
public class UploadRestController {

	@RequestMapping(value = "/uploadLogo")
	@ResponseBody
	public ResponseEntity<String> upload(final HttpServletRequest request) {
		String userName = request.getParameter("userName");

		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());

		if (multipartResolver.isMultipart(request)) {

			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;

			Iterator iter = multiRequest.getFileNames();

			while (iter.hasNext()) {

				MultipartFile file = multiRequest.getFile(iter.next().toString());
				if (file != null) {

					String path = "C:\\UCM\\tmp" + userName;
					File targetFile = new File(path, file.getOriginalFilename());

					File directory = new File(path);
					File[] array = directory.listFiles();
					if (array != null) {

						for (int i = 0; i < array.length; i++) {
							String fileName = array[i].getName();
							File existingFile = new File(path + "\\" + fileName);
							existingFile.delete();
						}

					}

					if (!targetFile.exists()) {
						targetFile.mkdirs();
					}

					System.out.println(path);

					try {
						file.transferTo(targetFile);
					} catch (IllegalStateException | IOException e) {
						e.printStackTrace();
					}
				}

			}

		}

		return new ResponseEntity<String>("uploaded", HttpStatus.OK);
	}

	@RequestMapping(value = "/Logo/{userName}", method = RequestMethod.GET)
	public void getIcon(@PathVariable("userName") String userName, HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		String fileName = null;

		String path = "C:\\UCM\\" + userName;
		File directory = new File(path);
		File[] array = directory.listFiles();

		if (array == null) {
			File file = new File("C:\\UCM\\defaultLogo.jpg");
			FileInputStream inputStream = new FileInputStream(file);
			byte[] data = new byte[(int) file.length()];
			int length = inputStream.read(data);
			inputStream.close();

			response.setContentType("image/jpeg");
			response.setHeader("Pragma", "No-cache");// tell browser not to
														// cache this content
			response.setHeader("Cache-Control", "no-cache");
			response.setHeader("Set-Cookie", "name=value; HttpOnly");// set
																		// httponly
																		// to
																		// avoid
																		// Xss
																		// attack
			response.setDateHeader("Expire", 0);

			OutputStream stream = response.getOutputStream();
			stream.write(data);
			stream.flush();
			stream.close();
		} else {
			List fileNames = new ArrayList();

			for (int i = 0; i < array.length; i++) {
				fileName = array[i].getName();
			}

			File file = new File(path + "\\" + fileName);
			FileInputStream inputStream = new FileInputStream(file);
			byte[] data = new byte[(int) file.length()];
			int length = inputStream.read(data);
			inputStream.close();

			response.setContentType("image/jpeg");
			response.setHeader("Pragma", "No-cache");// tell browser not to
														// cache this content
			response.setHeader("Cache-Control", "no-cache");
			response.setHeader("Set-Cookie", "name=value; HttpOnly");// set
																		// httponly
																		// to
																		// avoid
																		// Xss
																		// attack
			response.setDateHeader("Expire", 0);

			OutputStream stream = response.getOutputStream();
			stream.write(data);
			stream.flush();
			stream.close();
		}
	}

	@RequestMapping(value = "/uploadToS3")
	@ResponseBody
	public ResponseEntity<String> uploadToS3(final HttpServletRequest request)
			throws AmazonServiceException, AmazonClientException, Exception {
		String userName = request.getParameter("userName");
		String op = request.getParameter("op");

		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());

		if (multipartResolver.isMultipart(request)) {

			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;

			Iterator iter = multiRequest.getFileNames();

			while (iter.hasNext()) {

				MultipartFile file = multiRequest.getFile(iter.next().toString());
				if (file != null) {

					String path = "C:\\UCM\\tmp\\" + userName;
					File targetFile = new File(path, file.getOriginalFilename());

					if (!targetFile.exists()) {
						targetFile.mkdirs();
					}

					System.out.println("local path:" + path);

					try {
						file.transferTo(targetFile);
						if ("logo".equals(op)) {
							deleteExistingLogo(userName);
							S3Client.getInstance().uploadFileToBucket(new File(path, targetFile.getName()),
									op + "/" + userName + "/logo.jpg");
						} else if ("work file".equals(op)) {
							String workDate = request.getParameter("workDate");
							String workName = request.getParameter("workName");
							S3Client.getInstance().uploadFileToBucket(new File(path, targetFile.getName()),
									op + "/" + userName + "/" + workDate + " - " + workName + "/" + targetFile.getName());
						}

						targetFile.delete();
					} catch (IllegalStateException | IOException e) {
						e.printStackTrace();
					}
				}

			}

		}

		return new ResponseEntity<String>("uploaded", HttpStatus.OK);
	}

	private void deleteExistingLogo(String userName) throws AmazonServiceException, SdkClientException, Exception {
		S3Client.getInstance().deleteObjectsWithPrefix("logo/" + userName);
	}

	@RequestMapping(value = "/LogoFromS3/{userName}", method = RequestMethod.GET)
	public void getLogo(@PathVariable("userName") String userName, HttpServletRequest request,
			HttpServletResponse response) throws AmazonServiceException, SdkClientException, Exception {

		String path = userName + "/logo.jpg";

		InputStream is = S3Client.getInstance().getObjects(path);

		byte[] byt = new byte[10240];
		int len = 0;
		FileOutputStream fileOutputStream = null;
		File file = new File("C:\\UCM\\tmp\\tmp.jpg");
		fileOutputStream = new FileOutputStream(file);
		while ((len = is.read(byt)) != -1) {
			fileOutputStream.write(byt, 0, len);
		}
		fileOutputStream.close();

		FileInputStream inputStream = new FileInputStream(file);
		byte[] data = new byte[(int) file.length()];
		int length = inputStream.read(data);
		inputStream.close();
		file.delete();

		response.setContentType("image/jpeg");
		response.setHeader("Pragma", "No-cache");// tell browser not to
													// cache this content
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Set-Cookie", "name=value; HttpOnly");// set
																	// httponly
																	// to
																	// avoid
																	// Xss
																	// attack
		response.setDateHeader("Expire", 0);

		OutputStream stream = response.getOutputStream();
		stream.write(data);
		stream.flush();
		stream.close();
	}

	@RequestMapping(value = "/FileFromS3", method = RequestMethod.GET)
	public void getFile(HttpServletRequest request, HttpServletResponse response)
			throws AmazonServiceException, SdkClientException, Exception {

		String key = request.getParameter("key");

		InputStream is = S3Client.getInstance().getObjects(key);

		byte[] byt = new byte[10240];
		int len = 0;
		FileOutputStream fileOutputStream = null;
		File file = new File("C:\\UCM\\tmp\\tmp.jpg");
		fileOutputStream = new FileOutputStream(file);
		while ((len = is.read(byt)) != -1) {
			fileOutputStream.write(byt, 0, len);
		}
		fileOutputStream.close();

		FileInputStream inputStream = new FileInputStream(file);
		byte[] data = new byte[(int) file.length()];
		int length = inputStream.read(data);
		inputStream.close();
		file.delete();

		response.setContentType("image/jpeg");
		response.setHeader("Pragma", "No-cache");// tell browser not to
													// cache this content
		response.setHeader("Cache-Control", "no-cache");
		response.setHeader("Set-Cookie", "name=value; HttpOnly");// set
																	// httponly
																	// to
																	// avoid
																	// Xss
																	// attack
		response.setDateHeader("Expire", 0);

		OutputStream stream = response.getOutputStream();
		stream.write(data);
		stream.flush();
		stream.close();
	}

}
