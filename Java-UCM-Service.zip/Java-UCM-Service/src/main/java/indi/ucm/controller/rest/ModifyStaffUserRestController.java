package indi.ucm.controller.rest;

import javax.servlet.http.HttpServletRequest;

import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.StaffUserBaseInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ModifyStaffUserRestController {
	@Autowired
	MasterUserListDao masterUserListDao;
	
	@Autowired
	StaffUserDao staffUserDao;
	
	
	
	@RequestMapping(value = "/ModifyStaffUser", method = RequestMethod.POST)
	public ResponseEntity<String> modifyCustomerAccount(
			final HttpServletRequest request) {
		// store data from request
		String businessId = request.getParameter("businessId");
		String userName = request.getParameter("userName");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
        try{
        	updateStaffUserInfo(request, masterUserId);
        }catch(Exception e){
        	return new ResponseEntity<String>("Modify staff User fail",
    				HttpStatus.OK);
        }

		return new ResponseEntity<String>("Modify staff User Successfully",
				HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deleteStaffUser", method = RequestMethod.POST)
	public ResponseEntity<String> deleteStaffUser(
			final HttpServletRequest request) {
		// store data from request
		String userName = request.getParameter("userName");
		int staffUserID = Integer.parseInt(request.getParameter("staffUserId"));
		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		try{
			staffUserDao.deleteStaffUser(staffUserID, masterUserId);
		}catch(Exception e){
			e.printStackTrace();
			
			return new ResponseEntity<String>("Delete staff User faild",
					HttpStatus.OK);
			
		}		
		return new ResponseEntity<String>("Delete staff User Successfully",
				HttpStatus.OK);
	}
	
	
	private void updateStaffUserInfo(HttpServletRequest request,int masterUserId){
		StaffUserBaseInfo  staffUserBaseInfo = new  StaffUserBaseInfo();
		
		staffUserBaseInfo.setFirstName(request.getParameter("firstName"));
		staffUserBaseInfo.setLastName(request.getParameter("lastName"));
		staffUserBaseInfo.seteMailAddress(request.getParameter("eMailAddress"));
		staffUserBaseInfo.setMobilePhone(request.getParameter("phoneNumber"));
		staffUserBaseInfo.setOtherPhone(request.getParameter("otherPhone"));
		staffUserBaseInfo.setEnable2FactorAuthenticationLogin(Integer.parseInt(request.getParameter("enable2FactorAuthenticationLogin")));
		staffUserBaseInfo.setSendPasscodeToDeviceId(Integer.parseInt(request.getParameter("sendPasscodeToDeviceId")));
		staffUserBaseInfo.setJobTitle(request.getParameter("jobTitle"));
		staffUserBaseInfo.setBusinessDepartmentId(Integer.parseInt(request.getParameter("businessDepartmentId")));
		staffUserBaseInfo.setWorkTimeZone(Integer.parseInt(request.getParameter("workTimeZone")));
		staffUserBaseInfo.setWorkEmail(request.getParameter("workEmail"));
		staffUserBaseInfo.setOfficePhone(request.getParameter("officePhone"));
		staffUserBaseInfo.setOfficeAddressStreet(request.getParameter("officeAddressStreet"));
		staffUserBaseInfo.setOfficeAddressCity(request.getParameter("officeAddressCity"));
		staffUserBaseInfo.setOfficeAddressStateProvince(request.getParameter("officeAddressStateProvince"));
		staffUserBaseInfo.setOfficeAddressZipCode(request.getParameter("officeAddressZipCode"));
		staffUserBaseInfo.setOfficeAddressCountry(Integer.parseInt(request.getParameter("officeAddressCountry")));
		staffUserBaseInfo.setUserNote(request.getParameter("userNote"));
		staffUserBaseInfo.setEnableAccess(Integer.parseInt(request.getParameter("enableAccess")));		
		staffUserBaseInfo.setStaffUserId(Integer.parseInt(request.getParameter("staffUserId")));
		
		staffUserDao.modifyStaffUser(staffUserBaseInfo, masterUserId);
	}
}
