package indi.ucm.controller.rest;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.MasterUserList;
import indi.ucm.jdbc.entry.StaffUser;
import indi.ucm.security.common.EncryptionDecryption;

@RestController
public class LogInRestController {
	// Service which will do all data retrieval/manipulation work
	@Autowired
	MasterUserDao masterUserDao;
	@Autowired
	MasterUserListDao masterUserListDao;
	@Autowired
	StaffUserDao staffUserDao;

	// -------------------master user login API-----------------------
	@RequestMapping(value = "/LogIn", method = RequestMethod.POST)
	public ResponseEntity<String> signUpMasterUser(final HttpServletRequest request) {
		// verify login request
		Boolean isAuthenticated = authenticateRequest(request);
		if (isAuthenticated) {
			return new ResponseEntity<String>("Authenticated", HttpStatus.OK);
		} else {
			return new ResponseEntity<String>("Failed Authentication", HttpStatus.UNAUTHORIZED);
		}
	}

	/**
	 * verify Login request
	 * 
	 * @param request
	 * @return
	 */
	private Boolean authenticateRequest(final HttpServletRequest request) {

		String identity = request.getParameter("identity");
		if ("mu".equals(identity)) {
			return authenticateMasterUser(request);
		} else if ("su".equals(identity)) {
			return authenticateStaffUser(request);
		}

		return false;
	}

	private Boolean authenticateStaffUser(HttpServletRequest request) {

		int masterUserBusinessId = Integer.parseInt(request.getParameter("masterUserBusinessId"));
		MasterUserList mul = this.masterUserListDao.getMasterUserListByBusiness(masterUserBusinessId);
		if (mul != null) {
			int masterUserId = mul.getMasterUserId();
			String staffUserName = request.getParameter("userName");
			StaffUser su = staffUserDao.getStaffUserByName(staffUserName, masterUserId);
			if (su != null) {
				String userName = request.getParameter("userName");
				String password = request.getParameter("hashedPassword");
				if (su != null && userName != null && password != null && userName.equals(su.getUsername())
						&& password.equals(EncryptionDecryption.decryptStr(su.getHashedPassword()))) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	private boolean authenticateMasterUser(HttpServletRequest request) {
		MasterUserList mul = this.masterUserListDao.getMasterUserListByName(request.getParameter("userName"));
		if (mul != null) {
			MasterUser mu = this.masterUserDao.getMasterUser(mul.getMasterUserId());
			String userName = request.getParameter("userName");
			String password = request.getParameter("hashedPassword");
			if (mu != null && userName != null && password != null && userName.equals(mu.getUerName())
					&& password.equals(EncryptionDecryption.decryptStr(mu.getHashedPassword()))) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}
