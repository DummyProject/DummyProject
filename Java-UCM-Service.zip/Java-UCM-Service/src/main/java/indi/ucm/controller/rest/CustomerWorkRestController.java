package indi.ucm.controller.rest;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerBusinessDao;
import indi.ucm.jdbc.dao.CustomerInvoiceStatusDao;
import indi.ucm.jdbc.dao.CustomerWorkBillingRateDao;
import indi.ucm.jdbc.dao.CustomerWorkDao;
import indi.ucm.jdbc.dao.CustomerWorkStatusDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.dao.WorkLocationTypeDao;
import indi.ucm.jdbc.dao.WorkReminderNotifyTimeDao;
import indi.ucm.jdbc.dao.WorkRepeatIntervalDao;
import indi.ucm.jdbc.dao.WorkTimeDurationDao;
import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.entry.CustomerBusiness;
import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.StaffUserBaseInfo;
import indi.ucm.jdbc.entry.WorkBookItem;
import indi.ucm.security.common.GenerateRandomIdHelper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@RestController
public class CustomerWorkRestController {
	
	@Autowired
	CustomerWorkDao customerWorkDao;
	@Autowired
	MasterUserListDao masterUserListDao;
	@Autowired
	CustomerWorkStatusDao customerWorkStatusDao;
	@Autowired
	WorkRepeatIntervalDao workRepeatIntervalDao;
	@Autowired
	WorkTimeDurationDao workTimeDurationDao;
	@Autowired
	CustomerWorkBillingRateDao customerWorkBillingRateDao; 
	@Autowired
	CustomerInvoiceStatusDao customerInvoiceStatusDao;
	@Autowired
	WorkReminderNotifyTimeDao workReminderNotifyTimeDao;
	@Autowired
	WorkLocationTypeDao workLocationTypeDao;
	@Autowired
	CustomerAccountDao customerAccountDao;
	@Autowired
	StaffUserDao staffUserDao;
	@Autowired
	MasterUserDao masterUserDao;
	@Autowired
	CustomerBusinessDao customerBusinessDao;
	
	@RequestMapping(value = "/CreateNewWork", method = RequestMethod.POST)
	public ResponseEntity<String> createNewWork(final HttpServletRequest request){
		String userName = request.getParameter("userName");
		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		
		try {
			String workJsonData = request.getParameter("workJsonData");
			CustomerWork customerWork;
			String daterange; 
			Type listType = new TypeToken<ArrayList<CustomerWork>>(){}.getType();
			Gson gson = new Gson();
			List<CustomerWork>  workList = (List<CustomerWork>) gson.fromJson(workJsonData, listType);

			for(int i = 0;i<workList.size();i++){
				customerWork =  workList.get(i);
				daterange = customerWork.getDateRange();
				//hard code staff user...
				customerWork.setAssignedStaffUser(123456);
				customerWork.setScheduleStartDate(daterange.substring(0,10));
				customerWork.setScheduleStartTime(daterange.substring(11,16));
				customerWork.setScheduleEndDate(daterange.substring(19,29));
				customerWork.setScheduleEndTime(daterange.substring(30));
				customerWorkDao.createCustomerWork(customerWork, masterUserId);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Create new Work fail",HttpStatus.OK);
		}
		return new ResponseEntity<String>("Create new Work Successfully",HttpStatus.OK);
	}	
	
	@RequestMapping(value = "/deleteWork", method = RequestMethod.POST)
	public ResponseEntity<String> deleteWork(final HttpServletRequest request){
		String userName = request.getParameter("userName");
		String businessId = request.getParameter("businessId");
		String workId = request.getParameter("workId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		try{
			customerWorkDao.deleteWork(workId, masterUserId);
		}catch(Exception e){
			e.printStackTrace();
			return new ResponseEntity<String>("Delete Work Faild",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Delete Work Successfully",HttpStatus.OK);
	}
	
	
	@RequestMapping(value = "/getWorkDetail", method = RequestMethod.POST)
	public ResponseEntity<CustomerWork> getWorkDetail(final HttpServletRequest request){
		String userName = request.getParameter("userName");
		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		
		int customerWorkID = Integer.parseInt(request.getParameter("customerWorkID"));
		CustomerWork  customerWork=this.customerWorkDao.getWorkByID(customerWorkID, masterUserId);
		
		String notifyCustomerMethod = customerWork.getWorkReminderNotifyCustomerMethod();
		if(notifyCustomerMethod.equals("1")){
			customerWork.setWorkReminderNotifyCustomerMethod("001");
		}else if(notifyCustomerMethod.equals("10")){
			customerWork.setWorkReminderNotifyCustomerMethod("010");
		}else if(notifyCustomerMethod.equals("11")){
			customerWork.setWorkReminderNotifyCustomerMethod("011");
		}
		
		String  notifyStaffMethod = customerWork.getWorkReminderNotifyStaffMethod();
		if(notifyStaffMethod.equals("1")){
			customerWork.setWorkReminderNotifyStaffMethod("001");
		}else if(notifyStaffMethod.equals("10")){
			customerWork.setWorkReminderNotifyStaffMethod("010");
		}else if(notifyStaffMethod.equals("11")){
			customerWork.setWorkReminderNotifyStaffMethod("011");
		}
		
		return new ResponseEntity<CustomerWork>(customerWork,HttpStatus.OK);
	}	
	
	@RequestMapping(value = "/ModifyWork", method = RequestMethod.POST)
	public ResponseEntity<String> modifyCustomerWork(
			final HttpServletRequest request) {
		// store data from request
		String userName = request.getParameter("userName");
		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);

		try {
			CustomerWork customerWork = stroeWorkInfo(request, masterUserId);
			this.customerWorkDao.modifyWork(customerWork,masterUserId);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Modify Customer work Faild",
					HttpStatus.OK);
		}

		return new ResponseEntity<String>("Modify staff User Successfully",
				HttpStatus.OK);
	}
	
	private CustomerWork stroeWorkInfo(final HttpServletRequest request,final int masterUserId){
		int customerWorkId;
		if(request.getParameter("workId") == null){
			customerWorkId = generateCustomerWorkId(masterUserId);
		}else{
			customerWorkId = Integer.parseInt(request.getParameter("workId"));
		}
		 	
		//parse date time
		String daterange = request.getParameter("daterange");
        String scheduleStartDate =  daterange.substring(0,10);
        String scheduleStartTime =  daterange.substring(11,16);
        String scheduleEndDate =  daterange.substring(19,29);
        String scheduleEndTime =  daterange.substring(30);
		
		
		CustomerWork customerWork = new CustomerWork();
		customerWork.setCustomerWorkId(customerWorkId);
		customerWork.setWorkName(request.getParameter("workName"));
		customerWork.setCustomerId(Integer.parseInt(request.getParameter("customerId")));
		customerWork.setWorkStatus(Integer.parseInt(request.getParameter("workStatus")));
		//hard code  AssignedStaffUser, is not used in customer work
		customerWork.setAssignedStaffUser(123456);
		customerWork.setScheduleStartDate(scheduleStartDate);
		customerWork.setScheduleEndDate(scheduleEndDate);	
		customerWork.setScheduleStartTime(scheduleStartTime);
		customerWork.setScheduleEndTime(scheduleEndTime);		
		customerWork.setWorkRepeatInterval(Integer.parseInt(request.getParameter("workRepeatInterval")));
		customerWork.setWorkTimeDuration(Integer.parseInt(request.getParameter("workTimeDuration")));
		customerWork.setWorkLocationType(Integer.parseInt(request.getParameter("workLocationType")));
		customerWork.setWorkDescription(request.getParameter("workDescription"));
		customerWork.setWorkBillable(Integer.parseInt(request.getParameter("workBillable")));
		customerWork.setWorkBillingRate(Integer.parseInt(request.getParameter("workBillingRate")));
		customerWork.setBillingCurrencyId(1); // hard code, defalut USD
		customerWork.setWorkReminderNotifyStaff(Integer.parseInt(request.getParameter("workReminderNotifyStaff")));
		customerWork.setWorkReminderNotifyStaffTime(Integer.parseInt(request.getParameter("workReminderNotifyStaffTime")));
		customerWork.setWorkReminderNotifyStaffMethod(request.getParameter("workReminderNotifyStaffMethod"));
		customerWork.setWorkReminderNotifyCustomer(Integer.parseInt(request.getParameter("workReminderNotifyCustomer")));
		customerWork.setWorkReminderNotifyCustomerTime(Integer.parseInt(request.getParameter("workReminderNotifyCustomerTime")));
		customerWork.setWorkReminderNotifyCustomerMethod(request.getParameter("workReminderNotifyCustomerMethod"));
		customerWork.setWorkReminderMessage(request.getParameter("workReminderMessage"));
		return  customerWork;
	}
	
	@RequestMapping(value = "/getAllWorkLocationType/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllWorkLocationType(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId) {
		
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allWorkRepeatInterval = this.workLocationTypeDao.getAllWorkLocationType(masterUserId);
		return new ResponseEntity<List>(allWorkRepeatInterval, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getAllWorkRepeatInterval/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllWorkRepeatInterval(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId) {
		
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allWorkRepeatInterval = this.workRepeatIntervalDao.getAllWorkRepeatInterval(masterUserId);
		return new ResponseEntity<List>(allWorkRepeatInterval, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getAllCustomerWorkStatus/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllCustomerWorkStatus(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId) {
		
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allCustomerWorkStatus = this.customerWorkStatusDao.getAllCustomerWorkStatus(masterUserId);

		return new ResponseEntity<List>(allCustomerWorkStatus, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getAllWorkTimeDuration/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllWorkTimeDuration(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId){
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allWorkTimeDuration = this.workTimeDurationDao.getAllWorkTimeDuration(masterUserId);

		return new ResponseEntity<List>(allWorkTimeDuration, HttpStatus.OK);
	}

	@RequestMapping(value = "/getAllWorkBillingRate/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllWorkBillingRate(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId){
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allWorkTimeDuration = this.customerWorkBillingRateDao.getAllWorkBillingRate(masterUserId);

		return new ResponseEntity<List>(allWorkTimeDuration, HttpStatus.OK);
	}
	

	@RequestMapping(value = "/getAllInvoiceStatus/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllInvoiceStatus(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId){
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allWorkTimeDuration = this.customerInvoiceStatusDao.getAllInvoiceStatus(masterUserId);

		return new ResponseEntity<List>(allWorkTimeDuration, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getAllWorkReminderNotifyTime/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllWorkReminderNotifyTime(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId){
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allWorkReminderNotifyTime = this.workReminderNotifyTimeDao.getAllWorkReminderNotifyTime(masterUserId);

		return new ResponseEntity<List>(allWorkReminderNotifyTime, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getAllWorkItems/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllWorkItems(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId){
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		int staffID = -1;
		if(businessId!=null && businessId.length()>1){
			staffID  = staffUserDao.getStaffUserByName(userName, masterUserId).getStaffUserId();
		}
		List<CustomerWork> customerWorks = this.customerWorkDao.getAllWorkItems(masterUserId,staffID);
		
		List<WorkBookItem>  workBookItems = new ArrayList<WorkBookItem>();
		StaffUserBaseInfo staffUserBaseInfo;
    	for(int i = 0;i< customerWorks.size();i++){
    		int workStatusID = customerWorks.get(i).getWorkStatus();
    		String workStatus = customerWorkStatusDao.getStatusByID(workStatusID,masterUserId);
    		String assignedStaffUser= "";
    		//get assignedStaffUser from customer_account table
    		long customerId = customerWorks.get(i).getCustomerId();
    		int assignedStaffId = customerAccountDao.getCustomerAccount(customerId, masterUserId).getAssignedStaffUser();
    		if(masterUserId == assignedStaffId){
    			MasterUser masterUser = masterUserDao.getMasterUser(assignedStaffId);
        		if(masterUser!= null){
        			assignedStaffUser = masterUser.getFirstName()+" "+masterUser.getLastName();
        		}
    		}else{
    			staffUserBaseInfo =staffUserDao.getStaffUser(assignedStaffId, masterUserId);
        		if(staffUserBaseInfo!=null){
        			assignedStaffUser =staffUserBaseInfo.getUserName();
        		}
    		}
    		 		
    		String client= "";
    		CustomerAccount  customerAccount = customerAccountDao.getCustomerAccount(customerWorks.get(i).getCustomerId(), masterUserId);
    		if(customerAccount != null){
    			if(customerAccount.getCustomerAccountType() == 1){
        			client = customerAccount.getFirstName() +" "+customerAccount.getLastName();
        		}else{
        			CustomerBusiness customerBusiness =customerBusinessDao.getCustomerBusinessByBusinessId(customerAccount.getCustomerBusinessId(), masterUserId); 
        			client = customerBusiness.getBusinessName();
        		}
    		}
    		
    		int workTimeDurationID = customerWorks.get(i).getWorkTimeDuration();
    		String workTimeDuration = workTimeDurationDao.getworkTimeDurationByID(workTimeDurationID,masterUserId);
    		
    		String workBillable = customerWorks.get(i).getWorkBillable() == 1? "yes" : "no" ;
    		String workLocationType =workLocationTypeDao.getLocationTypeByID(
    				customerWorks.get(i).getWorkLocationType(),masterUserId);
    		
    		
    		WorkBookItem workBookItem = new WorkBookItem();
    		workBookItem.setCustomerWorkId(customerWorks.get(i).getCustomerWorkId());
    		workBookItem.setWorkName(customerWorks.get(i).getWorkName());
    		workBookItem.setWorkStatus(workStatus);
    		workBookItem.setAssignedStaffUser(assignedStaffUser);
    		workBookItem.setDatetime(customerWorks.get(i).getScheduleStartDate());
    		
    		
    		workBookItem.setWorkTimeDuration(workTimeDuration);
    		workBookItem.setWorkLocationType(workLocationType);
    		workBookItem.setClient(client);
    		workBookItem.setWorkReminderMessage(customerWorks.get(i).getWorkReminderMessage());
    		workBookItem.setWorkBillable(workBillable);
    		workBookItem.setWorkBillingRate("N/A");
    		
    		workBookItems.add(workBookItem);
    	}

		return new ResponseEntity<List>(workBookItems, HttpStatus.OK);
	}
	
	private int generateCustomerWorkId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		int customerWorkID = 0;
		boolean isUnique = false;
		while (!isUnique) {
			customerWorkID = GenerateRandomIdHelper
					.generateRandomNumber(8);
			isUnique = isWorkUniqueId(customerWorkID, masterUserId);
		}
		return customerWorkID;
	}
	
	private boolean isWorkUniqueId(final int customerWorkID,
			final int masterUserId) {
		CustomerWork customerWork = this.customerWorkDao.getWorkByID(
				customerWorkID, masterUserId);
		if (customerWork == null) {
			return true;
		} else {
			return false;
		}
	}
}
