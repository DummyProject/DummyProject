package indi.ucm.controller.rest;

import indi.ucm.jdbc.dao.CustomerAccountDao;
import indi.ucm.jdbc.dao.CustomerBusinessDao;
import indi.ucm.jdbc.dao.MasterUserDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.dao.StaffUserDao;
import indi.ucm.jdbc.entry.CustomerAccount;
import indi.ucm.jdbc.entry.CustomerAccountItem;
import indi.ucm.jdbc.entry.CustomerBusiness;
import indi.ucm.jdbc.entry.CustomerInfo;
import indi.ucm.jdbc.entry.MasterUser;
import indi.ucm.jdbc.entry.StaffUserBaseInfo;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ModifyCustomerRestController {
	@Autowired
	MasterUserListDao masterUserListDao;
	@Autowired
	CustomerAccountDao customerAccountDao;
	@Autowired
	CustomerBusinessDao customerBusinessDao;
	@Autowired
	StaffUserDao staffUserDao;
	@Autowired
	MasterUserDao masterUserDao;

	// -------------------Retrieve clients---------------
	@RequestMapping(value = "/clients/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getClients(
			@PathVariable("userName") final String userName,@PathVariable("businessId") final String businessId) {
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		int staffId = -1;
		if(businessId!=null && businessId.length() >1){
			staffId = staffUserDao.getStaffUserByName(userName, masterUserId).getStaffUserId();
		}
		List<CustomerAccount> cas = customerAccountDao.getCustomerAccounts(masterUserId,staffId);

		if (cas.isEmpty()) {
			return new ResponseEntity<List>(cas, HttpStatus.OK);
		} else {
			List cis = new ArrayList();

			for (int i = 0; i < cas.size(); i++) {
				CustomerInfo ci = new CustomerInfo();
				CustomerAccount ca = (CustomerAccount) cas.get(i);
				if (ca.getCustomerAccountType() == 1) {
					ci.setBusinessName("");
					ci.setFirstName(ca.getFirstName());
					ci.setLastName(ca.getLastName());
				}
				;
				if (ca.getCustomerAccountType() == 2) {
					CustomerBusiness cb = customerBusinessDao
							.getCustomerBusinessByBusinessId(
									ca.getCustomerBusinessId(), masterUserId);
					ci.setBusinessName(cb.getBusinessName());
					ci.setFirstName("");
					ci.setLastName("");
				}
				;
				ci.setCustomerId(ca.getCustomerId());
				ci.setCustomerBusinessId(ca.getCustomerBusinessId());
				ci.setCustomerAccountType(ca.getCustomerAccountType());
				ci.setCustomerAccountStatus(ca.getCustomerAccountStatus());
				ci.setAssignedStaffUser(ca.getAssignedStaffUser());
				ci.setcFirstName(ca.getcFirstName());
				ci.setcLastName(ca.getcLastName());
				ci.setEmailAddress(ca.getEmailAddress());
				ci.setMobilePhone(ca.getMobilePhone());
				ci.setMailingAddressStreet(ca.getMailingAddressStreet());
				ci.setMailingAddressCity(ca.getMailingAddressCity());
				ci.setMailingAddressStateProvince(ca
						.getMailingAddressStateProvince());
				ci.setMailingAddressZipCode(ca.getMailingAddressZipCode());
				ci.setMailingAddressCountry(ca.getMailingAddressCountry());
				ci.setBillingAddressStreet(ca.getBillingAddressStreet());
				ci.setBillingAddressCity(ca.getBillingAddressCity());
				ci.setBillingAddressStateProvince(ca
						.getBillingAddressStateProvince());
				ci.setBillingAddressZipCode(ca.getBillingAddressZipCode());
				ci.setBillingAddressCountry(ca.getBillingAddressCountry());
				ci.setCustomerNote(ca.getCustomerNote());
				ci.setEmailGroup(ca.getEmailGroup());
				if (ca.getNotificationPreference() == 10) {
					ci.setNotificationPreference("010");
				} else if (ca.getNotificationPreference() == 1) {
					ci.setNotificationPreference("001");
				} else {
					ci.setNotificationPreference(String.valueOf(ca
							.getNotificationPreference()));
				}
				ci.setEnableClientPortal(ca.getEnableClientPortal());
				cis.add(ci);
			}
			return new ResponseEntity<List>(cis, HttpStatus.OK);
		}
	}
	

	@RequestMapping(value = "/clientsBook/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getClientsBook(
			@PathVariable("userName") final String userName,@PathVariable("businessId") final String businessId) {
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		int staffId = -1;
		if(businessId!=null && businessId.length() >1){
			staffId = staffUserDao.getStaffUserByName(userName, masterUserId).getStaffUserId();
		}
		List<CustomerAccount> cas = customerAccountDao.getCustomerAccounts(masterUserId,staffId);

		if (cas.isEmpty()) {
			return new ResponseEntity<List>(cas, HttpStatus.OK);
		} else {
			List cis = new ArrayList();

			for (int i = 0; i < cas.size(); i++) {
				CustomerAccountItem ci = new CustomerAccountItem();
				CustomerAccount ca = (CustomerAccount) cas.get(i);
						
				ci.setCustomerId(ca.getCustomerId());
				ci.setCustomerBusinessId(ca.getCustomerBusinessId());
				ci.setCustomerAccountType(ca.getCustomerAccountType());
				ci.setCustomerAccountStatus(ca.getCustomerAccountStatus());
				
				
				String assignedStaffUser= "";
	    		
	    		if(masterUserId == ca.getAssignedStaffUser()){
	    			MasterUser masterUser = masterUserDao.getMasterUser(ca.getAssignedStaffUser());
	        		if(masterUser!= null){
	        			assignedStaffUser = masterUser.getFirstName()+" "+masterUser.getLastName();
	        		}
	    		}else{
	    			StaffUserBaseInfo staffUserBaseInfo =staffUserDao.getStaffUser(ca.getAssignedStaffUser(), masterUserId);
	        		if(staffUserBaseInfo!=null){
	        			assignedStaffUser =staffUserBaseInfo.getUserName();
	        		}
	    		}
				
	    		ci.setAssignedStaffUser(assignedStaffUser);
				ci.setcFirstName(ca.getcFirstName());
				ci.setcLastName(ca.getcLastName());
				if (ca.getCustomerAccountType() == 1) {
					ci.setBusinessName("");
					ci.setFirstName(ca.getFirstName());
					ci.setLastName(ca.getLastName());
				}
				;
				if (ca.getCustomerAccountType() == 2) {
					CustomerBusiness cb = customerBusinessDao
							.getCustomerBusinessByBusinessId(
									ca.getCustomerBusinessId(), masterUserId);
					ci.setBusinessName(cb.getBusinessName());
					ci.setFirstName("");
					ci.setLastName("");
				}
				;
				ci.setEmailAddress(ca.getEmailAddress());
				ci.setMobilePhone(ca.getMobilePhone());
				
				cis.add(ci);
			}

			return new ResponseEntity<List>(cis, HttpStatus.OK);
		}
	}

	// -------------------modify a customer account-----------------------
	@RequestMapping(value = "/ModifyCustomerAccount", method = RequestMethod.POST)
	public ResponseEntity<String> modifyCustomerAccount(
			final HttpServletRequest request) {
		// store data from request
		String userName = request.getParameter("userName");
		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);

		updateCustomerAccountInfo(request, masterUserId);

		return new ResponseEntity<String>("Modify client Successfully",
				HttpStatus.OK);
	}

	// -------------------delete a customer account-----------------------
	@RequestMapping(value = "/DeleteClient", method = RequestMethod.POST)
	public ResponseEntity<String> deleteCustomerAccount(
			final HttpServletRequest request) {
		
		String userName = request.getParameter("userName");
		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		int customerId = Integer.parseInt(request.getParameter("customerId"));

		customerAccountDao.deleteCustomerAccount(customerId, masterUserId);
		customerBusinessDao.deleteCustomerBusiness(customerId, masterUserId);

		return new ResponseEntity<String>("delete client Successfully",
				HttpStatus.OK);
	}

	private void updateCustomerAccountInfo(HttpServletRequest request,
			int masterUserId) {
		CustomerAccount customerAccount = new CustomerAccount();
		customerAccount.setCustomerId(Integer.parseInt(request
				.getParameter("customerId")));
		int customerAccountType = Integer.parseInt(request
				.getParameter("customerAccountType"));
		customerAccount.setCustomerAccountType(customerAccountType);
		switch (customerAccountType) {
		case 1: {
			customerAccount.setFirstName(request.getParameter("firstName"));
			customerAccount.setLastName(request.getParameter("lastName"));
		}
			break;
		case 2: {
			CustomerBusiness customerBusiness = new CustomerBusiness();
			customerBusiness.setBusinessName(request
					.getParameter("businessName"));
			customerBusiness.setCustomerId(Integer.parseInt(request
					.getParameter("customerId")));
			customerBusinessDao.updateCustomerBusiness(customerBusiness,
					masterUserId);
		}
			break;
		}
		customerAccount.setCustomerAccountStatus(Integer.parseInt(request
				.getParameter("customerAccountStatus")));
		customerAccount.setAssignedStaffUser(Integer.parseInt(request
				.getParameter("assignedStaffUser")));
		customerAccount.setcFirstName(request.getParameter("cFirstName"));
		customerAccount.setcLastName(request.getParameter("cLastName"));
		customerAccount.setEmailAddress(request.getParameter("emailAddress"));
		customerAccount.setMobilePhone(request.getParameter("mobilePhone"));
		customerAccount.setMailingAddressStreet(request
				.getParameter("mailingAddressStreet"));
		customerAccount.setMailingAddressCity(request
				.getParameter("mailingAddressCity"));
		customerAccount.setMailingAddressStateProvince(request
				.getParameter("mailingAddressStateProvince"));
		customerAccount.setMailingAddressZipCode(request
				.getParameter("mailingAddressZipCode"));
		customerAccount.setMailingAddressCountry(Integer.parseInt(request
				.getParameter("mailingAddressCountry")));
		customerAccount.setBillingAddressStreet(request
				.getParameter("billingAddressStreet"));
		customerAccount.setBillingAddressCity(request
				.getParameter("billingAddressCity"));
		customerAccount.setBillingAddressStateProvince(request
				.getParameter("billingAddressStateProvince"));
		customerAccount.setBillingAddressZipCode(request
				.getParameter("billingAddressZipCode"));
		customerAccount.setBillingAddressCountry(Integer.parseInt(request
				.getParameter("billingAddressCountry")));
		customerAccount.setCustomerNote(request.getParameter("customerNote"));
		customerAccount.setEmailGroup(Integer.parseInt(request
				.getParameter("emailGroup")));
		customerAccount.setNotificationPreference(Integer.parseInt(request
				.getParameter("notificationPreference")));
		customerAccount.setEnableClientPortal(Integer.parseInt(request
				.getParameter("enableClientPortal")));

		customerAccountDao.modifyCustomerAccount(customerAccount, masterUserId);
	}
}
