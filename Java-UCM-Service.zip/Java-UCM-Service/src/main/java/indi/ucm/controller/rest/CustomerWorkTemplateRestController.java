package indi.ucm.controller.rest;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;

import indi.ucm.jdbc.dao.CustomerWorkTemplateDao;
import indi.ucm.jdbc.dao.MasterUserListDao;
import indi.ucm.jdbc.entry.CustomerWork;
import indi.ucm.jdbc.entry.CustomerWorkTemplate;
import indi.ucm.security.common.GenerateRandomIdHelper;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

@RestController
public class CustomerWorkTemplateRestController {
	@Autowired
	MasterUserListDao masterUserListDao;
	@Autowired
	CustomerWorkTemplateDao customerWorkTemplateDao;
	
	private static Logger logger = Logger.getLogger(CustomerWorkTemplateRestController.class);  
	
	@RequestMapping(value = "/createWorkTemplate", method = RequestMethod.POST)
	public ResponseEntity<String> createWorkTemplate(final HttpServletRequest request){
		String userName = request.getParameter("userName");

		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		try {
			String templateJsonData = request.getParameter("templateJsonData");
			logger.info(templateJsonData);
			CustomerWorkTemplate templateItem;
	
			String templateName = request.getParameter("templateName");
			Type listType = new TypeToken<ArrayList<CustomerWorkTemplate>>(){}.getType();
			Gson gson = new Gson();
			int workTemplateId = generateWorkTemplateId(masterUserId);
			List<CustomerWorkTemplate>  template = (List<CustomerWorkTemplate>) gson.fromJson(templateJsonData, listType);

			for(int i = 0;i<template.size();i++){
				templateItem =  template.get(i);
				templateItem.setTemplateName(templateName);
				templateItem.setCustomerWorkTemplateId(workTemplateId);
				templateItem.setTemplateSectionId(i+1);
					
				customerWorkTemplateDao.createCustomerWorkTemplate(templateItem, masterUserId);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<String>("Create Work Template fail",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Create Work Template Successfully",HttpStatus.OK);
	}
	
	@RequestMapping(value = "/getAllTemplates/{userName}/{businessId}", method = RequestMethod.GET)
	public ResponseEntity<List> getAllTemplates(@PathVariable("userName") final String userName,
			@PathVariable("businessId") final String businessId){
		
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		List allTemplates = customerWorkTemplateDao.getAllWorkTemplates(masterUserId);

		return new ResponseEntity<List>(allTemplates, HttpStatus.OK);
		
	}
	
	@RequestMapping(value = "/getTemplateDetail", method = RequestMethod.POST)
	public ResponseEntity<List> getAllTemplates(final HttpServletRequest request){
		String userName = request.getParameter("userName");
		String templateName = request.getParameter("templateName");
		String businessId = request.getParameter("businessId");
		int masterUserId = masterUserListDao.getMasterId(userName, businessId);
		HashMap header = new HashMap();
		
		List templateDetail = customerWorkTemplateDao.getTemplateDetail(templateName,masterUserId);
		int workNum = templateDetail.size();
		header.put("workNum", workNum);
		templateDetail.add(0, header);	
		
		return new ResponseEntity<List>(templateDetail, HttpStatus.OK);
		
	}
	
	private int generateWorkTemplateId(final int masterUserId) {
		// generate a 8 digit number as Master User ID
		int workTemplateID = 0;
		boolean isUnique = false;
		while (!isUnique) {
			workTemplateID = GenerateRandomIdHelper
					.generateRandomNumber(8);
			isUnique = isWorkUniqueId(workTemplateID, masterUserId);
		}
		return workTemplateID;
	}
	
	//TODO test List<CustomerWorkTemplate>
	private boolean isWorkUniqueId(final int workTemplateID,
			final int masterUserId) {
		List<CustomerWorkTemplate> workTemplate = this.customerWorkTemplateDao.getWorkTemplateByID(
				workTemplateID, masterUserId);
		if (workTemplate.size() == 0) {
			return true;
		} else {
			return false;
		}
	}
}
