package jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class TestMapper implements RowMapper<Test>{

	public Test mapRow(ResultSet rs, int i) throws SQLException {
		Test test = new Test();
        test.setIdP(rs.getInt("Id_P"));
        test.setFirstName(rs.getString("FirstName"));
        test.setLastName(rs.getString("LastName"));
        test.setAddress(rs.getString("Address"));
        test.setCity(rs.getString("City"));
        return test;
    }



}
